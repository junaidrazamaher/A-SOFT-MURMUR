    // Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAYu4mDZ8BEvkrLuaq5pDo5tifxYc3Fp9w",
  authDomain: "junaidmultimediatask.firebaseapp.com",
  projectId: "junaidmultimediatask",
  storageBucket: "junaidmultimediatask.appspot.com",
  messagingSenderId: "114025702371",
  appId: "1:114025702371:web:132da0bec16aa7611636d6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
