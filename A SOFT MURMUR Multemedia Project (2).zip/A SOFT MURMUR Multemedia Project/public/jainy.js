(function(i, s, o, g, r, a, m) {
    i['GoogleAnalyticsObject'] = r;
    i[r] = i[r] || function() {
        (i[r].q = i[r].q || []).push(arguments)
    }, i[r].l = 1 * new Date();
    a = s.createElement(o),
        m = s.getElementsByTagName(o)[0];
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m)
})(window, document, 'script', '../www.google-analytics.com/analytics.js', 'ga');
ga('create', 'UA-42700626-2', 'asoftmurmur.com');
ga('send', 'pageview');




! function(t) {
    function e(i) {
        if (n[i]) return n[i].exports;
        var o = n[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return t[i].call(o.exports, o, o.exports, e), o.l = !0, o.exports
    }
    var n = {};
    e.m = t, e.c = n, e.i = function(t) {
        return t
    }, e.d = function(t, n, i) {
        e.o(t, n) || Object.defineProperty(t, n, {
            configurable: !1,
            enumerable: !0,
            get: i
        })
    }, e.n = function(t) {
        var n = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return e.d(n, "a", n), n
    }, e.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, e.p = "index.html", e(e.s = 52)
}([function(t, e, n) {
    "use strict";

    function i(t, e) {
        var n, i, o, r, a = M;
        for (r = arguments.length; r-- > 2;) x.push(arguments[r]);
        for (e && null != e.children && (x.length || x.push(e.children), delete e.children); x.length;)
            if ((i = x.pop()) && void 0 !== i.pop)
                for (r = i.length; r--;) x.push(i[r]);
            else "boolean" == typeof i && (i = null), (o = "function" != typeof t) && (null == i ? i = "" : "number" == typeof i ? i += "" : "string" != typeof i && (o = !1)), o && n ? a[a.length - 1] += i : a === M ? a = [i] : a.push(i), n = o;
        var s = new O;
        return s.nodeName = t, s.children = a, s.attributes = null == e ? void 0 : e, s.key = null == e ? void 0 : e.key, void 0 !== P.vnode && P.vnode(s), s
    }

    function o(t, e) {
        for (var n in e) t[n] = e[n];
        return t
    }

    function r(t, e) {
        return i(t.nodeName, o(o({}, t.attributes), e), arguments.length > 2 ? [].slice.call(arguments, 2) : t.children)
    }

    function a(t) {
        !t._dirty && (t._dirty = !0) && 1 == D.push(t) && (P.debounceRendering || L)(s)
    }

    function s() {
        var t, e = D;
        for (D = []; t = e.pop();) t._dirty && N(t)
    }

    function u(t, e, n) {
        return "string" == typeof e || "number" == typeof e ? void 0 !== t.splitText : "string" == typeof e.nodeName ? !t._componentConstructor && c(t, e.nodeName) : n || t._componentConstructor === e.nodeName
    }

    function c(t, e) {
        return t.normalizedNodeName === e || t.nodeName.toLowerCase() === e.toLowerCase()
    }

    function l(t) {
        var e = o({}, t.attributes);
        e.children = t.children;
        var n = t.nodeName.defaultProps;
        if (void 0 !== n)
            for (var i in n) void 0 === e[i] && (e[i] = n[i]);
        return e
    }

    function h(t, e) {
        var n = e ? document.createElementNS("http://www.w3.org/2000/svg", t) : document.createElement(t);
        return n.normalizedNodeName = t, n
    }

    function f(t) {
        var e = t.parentNode;
        e && e.removeChild(t)
    }

    function p(t, e, n, i, o) {
        if ("className" === e && (e = "class"), "key" === e);
        else if ("ref" === e) n && n(null), i && i(t);
        else if ("class" !== e || o)
            if ("style" === e) {
                if (i && "string" != typeof i && "string" != typeof n || (t.style.cssText = i || ""), i && "object" == typeof i) {
                    if ("string" != typeof n)
                        for (var r in n) r in i || (t.style[r] = "");
                    for (var r in i) t.style[r] = "number" == typeof i[r] && !1 === j.test(r) ? i[r] + "px" : i[r]
                }
            } else if ("dangerouslySetInnerHTML" === e) i && (t.innerHTML = i.__html || "");
        else if ("o" == e[0] && "n" == e[1]) {
            var a = e !== (e = e.replace(/Capture$/, ""));
            e = e.toLowerCase().substring(2), i ? n || t.addEventListener(e, d, a) : t.removeEventListener(e, d, a), (t._listeners || (t._listeners = {}))[e] = i
        } else if ("list" !== e && "type" !== e && !o && e in t) {
            try {
                t[e] = null == i ? "" : i
            } catch (t) {}
            null != i && !1 !== i || "spellcheck" == e || t.removeAttribute(e)
        } else {
            var s = o && e !== (e = e.replace(/^xlink:?/, ""));
            null == i || !1 === i ? s ? t.removeAttributeNS("http://www.w3.org/1999/xlink", e.toLowerCase()) : t.removeAttribute(e) : "function" != typeof i && (s ? t.setAttributeNS("http://www.w3.org/1999/xlink", e.toLowerCase(), i) : t.setAttribute(e, i))
        } else t.className = i || ""
    }

    function d(t) {
        return this._listeners[t.type](P.event && P.event(t) || t)
    }

    function m() {
        for (var t; t = R.pop();) P.afterMount && P.afterMount(t), t.componentDidMount && t.componentDidMount()
    }

    function v(t, e, n, i, o, r) {
        U++ || (V = null != o && void 0 !== o.ownerSVGElement, F = null != t && !("__preactattr_" in t));
        var a = g(t, e, n, i, r);
        return o && a.parentNode !== o && o.appendChild(a), --U || (F = !1, r || m()), a
    }

    function g(t, e, n, i, o) {
        var r = t,
            a = V;
        if (null != e && "boolean" != typeof e || (e = ""), "string" == typeof e || "number" == typeof e) return t && void 0 !== t.splitText && t.parentNode && (!t._component || o) ? t.nodeValue != e && (t.nodeValue = e) : (r = document.createTextNode(e), t && (t.parentNode && t.parentNode.replaceChild(r, t), b(t, !0))), r.__preactattr_ = !0, r;
        var s = e.nodeName;
        if ("function" == typeof s) return k(t, e, n, i);
        if (V = "svg" === s || "foreignObject" !== s && V, s += "", (!t || !c(t, s)) && (r = h(s, V), t)) {
            for (; t.firstChild;) r.appendChild(t.firstChild);
            t.parentNode && t.parentNode.replaceChild(r, t), b(t, !0)
        }
        var u = r.firstChild,
            l = r.__preactattr_,
            f = e.children;
        if (null == l) {
            l = r.__preactattr_ = {};
            for (var p = r.attributes, d = p.length; d--;) l[p[d].name] = p[d].value
        }
        return !F && f && 1 === f.length && "string" == typeof f[0] && null != u && void 0 !== u.splitText && null == u.nextSibling ? u.nodeValue != f[0] && (u.nodeValue = f[0]) : (f && f.length || null != u) && y(r, f, n, i, F || null != l.dangerouslySetInnerHTML), _(r, e.attributes, l), V = a, r
    }

    function y(t, e, n, i, o) {
        var r, a, s, c, l, h = t.childNodes,
            p = [],
            d = {},
            m = 0,
            v = 0,
            y = h.length,
            w = 0,
            _ = e ? e.length : 0;
        if (0 !== y)
            for (var S = 0; y > S; S++) {
                var I = h[S],
                    T = I.__preactattr_,
                    N = _ && T ? I._component ? I._component.__key : T.key : null;
                null != N ? (m++, d[N] = I) : (T || (void 0 !== I.splitText ? !o || I.nodeValue.trim() : o)) && (p[w++] = I)
            }
        if (0 !== _)
            for (var S = 0; _ > S; S++) {
                c = e[S], l = null;
                var N = c.key;
                if (null != N) m && void 0 !== d[N] && (l = d[N], d[N] = void 0, m--);
                else if (w > v)
                    for (r = v; w > r; r++)
                        if (void 0 !== p[r] && u(a = p[r], c, o)) {
                            l = a, p[r] = void 0, r === w - 1 && w--, r === v && v++;
                            break
                        } l = g(l, c, n, i), s = h[S], l && l !== t && l !== s && (null == s ? t.appendChild(l) : l === s.nextSibling ? f(s) : t.insertBefore(l, s))
            }
        if (m)
            for (var S in d) void 0 !== d[S] && b(d[S], !1);
        for (; w >= v;) void 0 !== (l = p[w--]) && b(l, !1)
    }

    function b(t, e) {
        var n = t._component;
        n ? E(n) : (null != t.__preactattr_ && t.__preactattr_.ref && t.__preactattr_.ref(null), !1 !== e && null != t.__preactattr_ || f(t), w(t))
    }

    function w(t) {
        for (t = t.lastChild; t;) {
            var e = t.previousSibling;
            b(t, !0), t = e
        }
    }

    function _(t, e, n) {
        var i;
        for (i in n) e && null != e[i] || null == n[i] || p(t, i, n[i], n[i] = void 0, V);
        for (i in e) "children" === i || "innerHTML" === i || i in n && e[i] === ("value" === i || "checked" === i ? t[i] : n[i]) || p(t, i, n[i], n[i] = e[i], V)
    }

    function S(t, e, n) {
        var i, o = B.length;
        for (t.prototype && t.prototype.render ? (i = new t(e, n), C.call(i, e, n)) : (i = new C(e, n), i.constructor = t, i.render = I); o--;)
            if (B[o].constructor === t) return i.nextBase = B[o].nextBase, B.splice(o, 1), i;
        return i
    }

    function I(t, e, n) {
        return this.constructor(t, n)
    }

    function T(t, e, n, i, o) {
        t._disable || (t._disable = !0, t.__ref = e.ref, t.__key = e.key, delete e.ref, delete e.key, void 0 === t.constructor.getDerivedStateFromProps && (!t.base || o ? t.componentWillMount && t.componentWillMount() : t.componentWillReceiveProps && t.componentWillReceiveProps(e, i)), i && i !== t.context && (t.prevContext || (t.prevContext = t.context), t.context = i), t.prevProps || (t.prevProps = t.props), t.props = e, t._disable = !1, 0 !== n && (1 !== n && !1 === P.syncComponentUpdates && t.base ? a(t) : N(t, 1, o)), t.__ref && t.__ref(t))
    }

    function N(t, e, n, i) {
        if (!t._disable) {
            var r, a, s, u = t.props,
                c = t.state,
                h = t.context,
                f = t.prevProps || u,
                p = t.prevState || c,
                d = t.prevContext || h,
                g = t.base,
                y = t.nextBase,
                w = g || y,
                _ = t._component,
                I = !1,
                k = d;
            if (t.constructor.getDerivedStateFromProps && (c = o(o({}, c), t.constructor.getDerivedStateFromProps(u, c)), t.state = c), g && (t.props = f, t.state = p, t.context = d, 2 !== e && t.shouldComponentUpdate && !1 === t.shouldComponentUpdate(u, c, h) ? I = !0 : t.componentWillUpdate && t.componentWillUpdate(u, c, h), t.props = u, t.state = c, t.context = h), t.prevProps = t.prevState = t.prevContext = t.nextBase = null, t._dirty = !1, !I) {
                r = t.render(u, c, h), t.getChildContext && (h = o(o({}, h), t.getChildContext())), g && t.getSnapshotBeforeUpdate && (k = t.getSnapshotBeforeUpdate(f, p));
                var C, A, O = r && r.nodeName;
                if ("function" == typeof O) {
                    var x = l(r);
                    a = _, a && a.constructor === O && x.key == a.__key ? T(a, x, 1, h, !1) : (C = a, t._component = a = S(O, x, h), a.nextBase = a.nextBase || y, a._parentComponent = t, T(a, x, 0, h, !1), N(a, 1, n, !0)), A = a.base
                } else s = w, C = _, C && (s = t._component = null), (w || 1 === e) && (s && (s._component = null), A = v(s, r, h, n || !g, w && w.parentNode, !0));
                if (w && A !== w && a !== _) {
                    var M = w.parentNode;
                    M && A !== M && (M.replaceChild(A, w), C || (w._component = null, b(w, !1)))
                }
                if (C && E(C), t.base = A, A && !i) {
                    for (var L = t, j = t; j = j._parentComponent;)(L = j).base = A;
                    A._component = L, A._componentConstructor = L.constructor
                }
            }
            for (!g || n ? R.unshift(t) : I || (t.componentDidUpdate && t.componentDidUpdate(f, p, k), P.afterUpdate && P.afterUpdate(t)); t._renderCallbacks.length;) t._renderCallbacks.pop().call(t);
            U || i || m()
        }
    }

    function k(t, e, n, i) {
        for (var o = t && t._component, r = o, a = t, s = o && t._componentConstructor === e.nodeName, u = s, c = l(e); o && !u && (o = o._parentComponent);) u = o.constructor === e.nodeName;
        return o && u && (!i || o._component) ? (T(o, c, 3, n, i), t = o.base) : (r && !s && (E(r), t = a = null), o = S(e.nodeName, c, n), t && !o.nextBase && (o.nextBase = t, a = null), T(o, c, 1, n, i), t = o.base, a && t !== a && (a._component = null, b(a, !1))), t
    }

    function E(t) {
        P.beforeUnmount && P.beforeUnmount(t);
        var e = t.base;
        t._disable = !0, t.componentWillUnmount && t.componentWillUnmount(), t.base = null;
        var n = t._component;
        n ? E(n) : e && (e.__preactattr_ && e.__preactattr_.ref && e.__preactattr_.ref(null), t.nextBase = e, f(e), B.push(t), w(e)), t.__ref && t.__ref(null)
    }

    function C(t, e) {
        this._dirty = !0, this.context = e, this.props = t, this.state = this.state || {}, this._renderCallbacks = []
    }

    function A(t, e, n) {
        return v(n, t, {}, !1, e, !1)
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), n.d(e, "h", function() {
        return i
    }), n.d(e, "createElement", function() {
        return i
    }), n.d(e, "cloneElement", function() {
        return r
    }), n.d(e, "Component", function() {
        return C
    }), n.d(e, "render", function() {
        return A
    }), n.d(e, "rerender", function() {
        return s
    }), n.d(e, "options", function() {
        return P
    });
    var O = function() {},
        P = {},
        x = [],
        M = [],
        L = "function" == typeof Promise ? Promise.resolve().then.bind(Promise.resolve()) : setTimeout,
        j = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i,
        D = [],
        R = [],
        U = 0,
        V = !1,
        F = !1,
        B = [];
    o(C.prototype, {
        setState: function(t, e) {
            this.prevState || (this.prevState = this.state), this.state = o(o({}, this.state), "function" == typeof t ? t(this.state, this.props) : t), e && this._renderCallbacks.push(e), a(this)
        },
        forceUpdate: function(t) {
            t && this._renderCallbacks.push(t), N(this, 2)
        },
        render: function() {}
    }), e.default = {
        h: i,
        createElement: i,
        cloneElement: r,
        Component: C,
        render: A,
        rerender: s,
        options: P
    }
}, function(t, e, n) {
    "use strict";
    var i = n(9),
        o = {};
    Object.keys(i.soundList).forEach(function(t) {
        var e = i.soundList[t];
        e.pro || (o[t] = e)
    }), t.exports = o
}, function(t, e) {
    "use strict";
    e.__esModule = !0;
    var n = (e.DEBUG = !1, e.CACHE_BUSTING_ON = !1),
        i = e.USE_BETA = !1;
    e.getPrefix = function(t, e, n) {
        if ("DEV" === window.ENV) return n ? "/assets/audio/ios-audio/" : "/assets/audio/";
        var o = i ? "privatebeta.asoftmurmur.com" : "asoftmurmur.com",
            r = e ? t.glueSubdomain : t.subdomain;
        return "https://st" + (r = r || t.label.length % 3 + 1) + "." + o + "/assets/p/content/" + t.key + "/"
    }, e.getSuffix = function() {
        return n && window && window.SOUND_VERSION ? "?sv=" + window.SOUND_VERSION : ""
    }
}, function(t, e, n) {
    "use strict";

    function i(t, e) {
        function n() {
            this.constructor = t
        }
        T(t, e), t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n)
    }

    function o(t, e) {
        var n = {};
        for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && 0 > e.indexOf(i) && (n[i] = t[i]);
        if (null != t && "function" == typeof Object.getOwnPropertySymbols)
            for (var o = 0, i = Object.getOwnPropertySymbols(t); i.length > o; o++) 0 > e.indexOf(i[o]) && Object.prototype.propertyIsEnumerable.call(t, i[o]) && (n[i[o]] = t[i[o]]);
        return n
    }

    function r(t, e, n, i) {
        var o, r = arguments.length,
            a = 3 > r ? e : null === i ? i = Object.getOwnPropertyDescriptor(e, n) : i;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, i);
        else
            for (var s = t.length - 1; s >= 0; s--)(o = t[s]) && (a = (3 > r ? o(a) : r > 3 ? o(e, n, a) : o(e, n)) || a);
        return r > 3 && a && Object.defineProperty(e, n, a), a
    }

    function a(t, e) {
        return function(n, i) {
            e(n, i, t)
        }
    }

    function s(t, e) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(t, e)
    }

    function u(t, e, n, i) {
        function o(t) {
            return t instanceof n ? t : new n(function(e) {
                e(t)
            })
        }
        return new(n || (n = Promise))(function(n, r) {
            function a(t) {
                try {
                    u(i.next(t))
                } catch (t) {
                    r(t)
                }
            }

            function s(t) {
                try {
                    u(i.throw(t))
                } catch (t) {
                    r(t)
                }
            }

            function u(t) {
                t.done ? n(t.value) : o(t.value).then(a, s)
            }
            u((i = i.apply(t, e || [])).next())
        })
    }

    function c(t, e) {
        function n(t) {
            return function(e) {
                return i([t, e])
            }
        }

        function i(n) {
            if (!o) {
                for (; u;) try {
                    if (o = 1, r && (a = 2 & n[0] ? r.return : n[0] ? r.throw || ((a = r.return) && a.call(r), 0) : r.next) && !(a = a.call(r, n[1])).done) return a;
                    switch (r = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                        case 0:
                        case 1:
                            a = n;
                            break;
                        case 4:
                            return u.label++, {
                                value: n[1],
                                done: !1
                            };
                        case 5:
                            u.label++, r = n[1], n = [0];
                            continue;
                        case 7:
                            n = u.ops.pop(), u.trys.pop();
                            continue;
                        default:
                            if (a = u.trys, !(a = a.length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                u = 0;
                                continue
                            }
                            if (3 === n[0] && (!a || n[1] > a[0] && a[3] > n[1])) {
                                u.label = n[1];
                                break
                            }
                            if (6 === n[0] && a[1] > u.label) {
                                u.label = a[1], a = n;
                                break
                            }
                            if (a && a[2] > u.label) {
                                u.label = a[2], u.ops.push(n);
                                break
                            }
                            a[2] && u.ops.pop(), u.trys.pop();
                            continue
                    }
                    n = e.call(t, u)
                } catch (t) {
                    n = [6, t], r = 0
                } finally {
                    o = a = 0
                }
                if (5 & n[0]) throw n[1];
                return {
                    value: n[0] ? n[1] : void 0,
                    done: !0
                }
            }
        }
        var o, r, a, s, u = {
            label: 0,
            sent: function() {
                if (1 & a[0]) throw a[1];
                return a[1]
            },
            trys: [],
            ops: []
        };
        return s = {
            next: n(0),
            throw: n(1),
            return: n(2)
        }, "function" == typeof Symbol && (s[Symbol.iterator] = function() {
            return this
        }), s
    }

    function l(t, e) {
        for (var n in t) e.hasOwnProperty(n) || (e[n] = t[n])
    }

    function h(t) {
        var e = "function" == typeof Symbol && Symbol.iterator,
            n = e && t[e],
            i = 0;
        return n ? n.call(t) : t && "number" == typeof t.length ? {
            next: function() {
                return t && i >= t.length && (t = void 0), {
                    value: t && t[i++],
                    done: !t
                }
            }
        } : void 0
    }

    function f(t, e) {
        var n = "function" == typeof Symbol && t[Symbol.iterator];
        if (!n) return t;
        var i, o, r = n.call(t),
            a = [];
        try {
            for (;
                (void 0 === e || e-- > 0) && !(i = r.next()).done;) a.push(i.value)
        } catch (t) {
            o = {
                error: t
            }
        } finally {
            try {
                i && !i.done && (n = r.return) && n.call(r)
            } finally {
                if (o) throw o.error
            }
        }
        return a
    }

    function p() {
        for (var t = [], e = 0; arguments.length > e; e++) t = t.concat(f(arguments[e]));
        return t
    }

    function d() {
        for (var t = 0, e = 0, n = arguments.length; n > e; e++) t += arguments[e].length;
        for (var i = Array(t), o = 0, e = 0; n > e; e++)
            for (var r = arguments[e], a = 0, s = r.length; s > a; a++, o++) i[o] = r[a];
        return i
    }

    function m(t) {
        return this instanceof m ? (this.v = t, this) : new m(t)
    }

    function v(t, e, n) {
        function i(t) {
            l[t] && (c[t] = function(e) {
                return new Promise(function(n, i) {
                    h.push([t, e, n, i]) > 1 || o(t, e)
                })
            })
        }

        function o(t, e) {
            try {
                r(l[t](e))
            } catch (t) {
                u(h[0][3], t)
            }
        }

        function r(t) {
            t.value instanceof m ? Promise.resolve(t.value.v).then(a, s) : u(h[0][2], t)
        }

        function a(t) {
            o("next", t)
        }

        function s(t) {
            o("throw", t)
        }

        function u(t, e) {
            t(e), h.shift(), h.length && o(h[0][0], h[0][1])
        }
        if (Symbol.asyncIterator) {
            var c, l = n.apply(t, e || []),
                h = [];
            return c = {}, i("next"), i("throw"), i("return"), c[Symbol.asyncIterator] = function() {
                return this
            }, c
        }
    }

    function g(t) {
        function e(e, o) {
            n[e] = t[e] ? function(n) {
                return (i = !i) ? {
                    value: m(t[e](n)),
                    done: "return" === e
                } : o ? o(n) : n
            } : o
        }
        var n, i;
        return n = {}, e("next"), e("throw", function(t) {
            throw t
        }), e("return"), n[Symbol.iterator] = function() {
            return this
        }, n
    }

    function y(t) {
        function e(e) {
            i[e] = t[e] && function(i) {
                return new Promise(function(o, r) {
                    i = t[e](i), n(o, r, i.done, i.value)
                })
            }
        }

        function n(t, e, n, i) {
            Promise.resolve(i).then(function(e) {
                t({
                    value: e,
                    done: n
                })
            }, e)
        }
        if (Symbol.asyncIterator) {
            var i, o = t[Symbol.asyncIterator];
            return o ? o.call(t) : (t = "function" == typeof h ? h(t) : t[Symbol.iterator](), i = {}, e("next"), e("throw"), e("return"), i[Symbol.asyncIterator] = function() {
                return this
            }, i)
        }
    }

    function b(t, e) {
        return Object.defineProperty ? Object.defineProperty(t, "raw", {
            value: e
        }) : t.raw = e, t
    }

    function w(t) {
        if (t && t.__esModule) return t;
        var e = {};
        if (null != t)
            for (var n in t) Object.hasOwnProperty.call(t, n) && (e[n] = t[n]);
        return e.default = t, e
    }

    function _(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function S(t, e) {
        if (e.has(t)) return e.get(t)
    }

    function I(t, e, n) {
        if (e.has(t)) return e.set(t, n), n
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.__extends = i, n.d(e, "__assign", function() {
        return N
    }), e.__rest = o, e.__decorate = r, e.__param = a, e.__metadata = s, e.__awaiter = u, e.__generator = c, e.__exportStar = l, e.__values = h, e.__read = f, e.__spread = p, e.__spreadArrays = d, e.__await = m, e.__asyncGenerator = v, e.__asyncDelegator = g, e.__asyncValues = y, e.__makeTemplateObject = b, e.__importStar = w, e.__importDefault = _, e.__classPrivateFieldGet = S, e.__classPrivateFieldSet = I;
    var T = function(t, e) {
            return (T = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(t, e) {
                    t.__proto__ = e
                } || function(t, e) {
                    for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
                })(t, e)
        },
        N = function() {
            return N = Object.assign || function(t) {
                for (var e, n = 1, i = arguments.length; i > n; n++) {
                    e = arguments[n];
                    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
                }
                return t
            }, N.apply(this, arguments)
        }
}, function(t, e, n) {
    "use strict";

    function i(t) {
        function e(t) {
            delete d[t]
        }

        function n(t) {
            if (t = t || m, !c.contains(d, t)) throw p.create("no-app", {
                appName: t
            });
            return d[t]
        }

        function i(e, n) {
            void 0 === n && (n = {}), ("object" != typeof n || null === n) && (n = {
                name: n
            });
            var i = n;
            void 0 === i.name && (i.name = m);
            var o = i.name;
            if ("string" != typeof o || !o) throw p.create("bad-app-name", {
                appName: o + ""
            });
            if (c.contains(d, o)) throw p.create("duplicate-app", {
                appName: o
            });
            var r = new t(e, i, w);
            return d[o] = r, r
        }

        function o() {
            return Object.keys(d).map(function(t) {
                return d[t]
            })
        }

        function r(e) {
            var i, o, r = e.name;
            if (y.has(r)) return g.debug("There were multiple attempts to register component " + r + "."), "PUBLIC" === e.type ? w[r] : null;
            if (y.set(r, e), "PUBLIC" === e.type) {
                var a = function(t) {
                    if (void 0 === t && (t = n()), "function" != typeof t[r]) throw p.create("invalid-app-argument", {
                        appName: r
                    });
                    return t[r]()
                };
                void 0 !== e.serviceProps && c.deepExtend(a, e.serviceProps), w[r] = a, t.prototype[r] = function() {
                    for (var t = [], n = 0; arguments.length > n; n++) t[n] = arguments[n];
                    return this._getService.bind(this, r).apply(this, e.multipleInstances ? t : [])
                }
            }
            try {
                for (var s = u.__values(Object.keys(d)), l = s.next(); !l.done; l = s.next()) d[l.value]._addComponent(e)
            } catch (t) {
                i = {
                    error: t
                }
            } finally {
                try {
                    l && !l.done && (o = s.return) && o.call(s)
                } finally {
                    if (i) throw i.error
                }
            }
            return "PUBLIC" === e.type ? w[r] : null
        }

        function a(t, e, n) {
            var i, o = null !== (i = v[t]) && void 0 !== i ? i : t;
            n && (o += "-" + n);
            var a = o.match(/\s|\//),
                s = e.match(/\s|\//);
            if (a || s) {
                var u = ['Unable to register library "' + o + '" with version "' + e + '":'];
                return a && u.push('library name "' + o + '" contains illegal characters (whitespace or "/")'), a && s && u.push("and"), s && u.push('version name "' + e + '" contains illegal characters (whitespace or "/")'), void g.warn(u.join(" "))
            }
            r(new l.Component(o + "-version", function() {
                return {
                    library: o,
                    version: e
                }
            }, "VERSION"))
        }

        function s(t, e) {
            if (null !== t && "function" != typeof t) throw p.create("invalid-log-argument", {
                appName: name
            });
            h.setUserLogHandler(t, e)
        }

        function f(t, e) {
            return "serverAuth" === e ? null : e
        }
        var d = {},
            y = new Map,
            w = {
                __esModule: !0,
                initializeApp: i,
                app: n,
                registerVersion: a,
                setLogLevel: h.setLogLevel,
                onLog: s,
                apps: null,
                SDK_VERSION: b,
                INTERNAL: {
                    registerComponent: r,
                    removeApp: e,
                    components: y,
                    useAsService: f
                }
            };
        return w.default = w, Object.defineProperty(w, "apps", {
            get: o
        }), n.App = t, w
    }

    function o() {
        function t(t) {
            c.deepExtend(e, t)
        }
        var e = i(y);
        return e.INTERNAL = u.__assign(u.__assign({}, e.INTERNAL), {
            createFirebaseNamespace: o,
            extendNamespace: t,
            createSubscribe: c.createSubscribe,
            ErrorFactory: c.ErrorFactory,
            deepExtend: c.deepExtend
        }), e
    }

    function r(t) {
        var e = t.getComponent();
        return "VERSION" === (null === e || void 0 === e ? void 0 : e.type)
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var a, s, u = n(3),
        c = n(5),
        l = n(17),
        h = n(18),
        f = (a = {}, a["no-app"] = "No Firebase App '{$appName}' has been created - call Firebase App.initializeApp()", a["bad-app-name"] = "Illegal App name: '{$appName}", a["duplicate-app"] = "Firebase App named '{$appName}' already exists", a["app-deleted"] = "Firebase App named '{$appName}' already deleted", a["invalid-app-argument"] = "firebase.{$appName}() takes either no argument or a Firebase App instance.", a["invalid-log-argument"] = "First argument to `onLog` must be null or a function.", a),
        p = new c.ErrorFactory("app", "Firebase", f),
        d = "@firebase/app",
        m = "[DEFAULT]",
        v = (s = {}, s[d] = "fire-core", s["@firebase/analytics"] = "fire-analytics", s["@firebase/auth"] = "fire-auth", s["@firebase/database"] = "fire-rtdb", s["@firebase/functions"] = "fire-fn", s["@firebase/installations"] = "fire-iid", s["@firebase/messaging"] = "fire-fcm", s["@firebase/performance"] = "fire-perf", s["@firebase/remote-config"] = "fire-rc", s["@firebase/storage"] = "fire-gcs", s["@firebase/firestore"] = "fire-fst", s["fire-js"] = "fire-js", s["firebase-wrapper"] = "fire-js-all", s),
        g = new h.Logger("@firebase/app"),
        y = function() {
            function t(t, e, n) {
                var i, o, r = this;
                this.firebase_ = n, this.isDeleted_ = !1, this.name_ = e.name, this.automaticDataCollectionEnabled_ = e.automaticDataCollectionEnabled || !1, this.options_ = c.deepCopy(t), this.container = new l.ComponentContainer(e.name), this._addComponent(new l.Component("app", function() {
                    return r
                }, "PUBLIC"));
                try {
                    for (var a = u.__values(this.firebase_.INTERNAL.components.values()), s = a.next(); !s.done; s = a.next()) this._addComponent(s.value)
                } catch (t) {
                    i = {
                        error: t
                    }
                } finally {
                    try {
                        s && !s.done && (o = a.return) && o.call(a)
                    } finally {
                        if (i) throw i.error
                    }
                }
            }
            return Object.defineProperty(t.prototype, "automaticDataCollectionEnabled", {
                get: function() {
                    return this.checkDestroyed_(), this.automaticDataCollectionEnabled_
                },
                set: function(t) {
                    this.checkDestroyed_(), this.automaticDataCollectionEnabled_ = t
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "name", {
                get: function() {
                    return this.checkDestroyed_(), this.name_
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "options", {
                get: function() {
                    return this.checkDestroyed_(), this.options_
                },
                enumerable: !0,
                configurable: !0
            }), t.prototype.delete = function() {
                var t = this;
                return new Promise(function(e) {
                    t.checkDestroyed_(), e()
                }).then(function() {
                    return t.firebase_.INTERNAL.removeApp(t.name_), Promise.all(t.container.getProviders().map(function(t) {
                        return t.delete()
                    }))
                }).then(function() {
                    t.isDeleted_ = !0
                })
            }, t.prototype._getService = function(t, e) {
                return void 0 === e && (e = m), this.checkDestroyed_(), this.container.getProvider(t).getImmediate({
                    identifier: e
                })
            }, t.prototype._removeServiceInstance = function(t, e) {
                void 0 === e && (e = m), this.container.getProvider(t).clearInstance(e)
            }, t.prototype._addComponent = function(t) {
                try {
                    this.container.addComponent(t)
                } catch (e) {
                    g.debug("Component " + t.name + " failed to register with FirebaseApp " + this.name, e)
                }
            }, t.prototype._addOrOverwriteComponent = function(t) {
                this.container.addOrOverwriteComponent(t)
            }, t.prototype.checkDestroyed_ = function() {
                if (this.isDeleted_) throw p.create("app-deleted", {
                    appName: this.name_
                })
            }, t
        }(),
        b = "7.14.5",
        w = o(),
        _ = function() {
            function t(t) {
                this.container = t
            }
            return t.prototype.getPlatformInfoString = function() {
                return this.container.getProviders().map(function(t) {
                    if (r(t)) {
                        var e = t.getImmediate();
                        return e.library + "/" + e.version
                    }
                    return null
                }).filter(function(t) {
                    return t
                }).join(" ")
            }, t
        }();
    if (c.isBrowser() && void 0 !== self.firebase) {
        g.warn("\n    Warning: Firebase is already defined in the global scope. Please make sure\n    Firebase library is only loaded once.\n  ");
        var S = self.firebase.SDK_VERSION;
        S && S.indexOf("LITE") >= 0 && g.warn("\n    Warning: You are trying to load Firebase while using Firebase Performance standalone script.\n    You should load Firebase Performance with this instance of Firebase to avoid loading duplicate code.\n    ")
    }
    var I = w.initializeApp;
    w.initializeApp = function() {
        for (var t = [], e = 0; arguments.length > e; e++) t[e] = arguments[e];
        return c.isNode() && g.warn('\n      Warning: This is a browser-targeted Firebase bundle but it appears it is being\n      run in a Node environment.  If running in a Node environment, make sure you\n      are using the bundle specified by the "main" field in package.json.\n      \n      If you are using Webpack, you can specify "main" as the first item in\n      "resolve.mainFields":\n      https://webpack.js.org/configuration/resolve/#resolvemainfields\n      \n      If using Rollup, use the rollup-plugin-node-resolve plugin and specify "main"\n      as the first item in "mainFields", e.g. [\'main\', \'module\'].\n      https://github.com/rollup/rollup-plugin-node-resolve\n      '), I.apply(void 0, t)
    };
    var T = w;
    ! function(t, e) {
        t.INTERNAL.registerComponent(new l.Component("platform-logger", function(t) {
            return new _(t)
        }, "PRIVATE")), t.registerVersion(d, "0.6.4", void 0), t.registerVersion("fire-js", "")
    }(T), e.default = T, e.firebase = T
}, function(t, e, n) {
    "use strict";
    (function(t) {
        function i(t) {
            return o(void 0, t)
        }

        function o(t, e) {
            if (!(e instanceof Object)) return e;
            switch (e.constructor) {
                case Date:
                    var n = e;
                    return new Date(n.getTime());
                case Object:
                    void 0 === t && (t = {});
                    break;
                case Array:
                    t = [];
                    break;
                default:
                    return e
            }
            for (var i in e) e.hasOwnProperty(i) && (t[i] = o(t[i], e[i]));
            return t
        }

        function r() {
            return "undefined" != typeof navigator && "string" == typeof navigator.userAgent ? navigator.userAgent : ""
        }

        function a() {
            return "undefined" != typeof window && !!(window.cordova || window.phonegap || window.PhoneGap) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(r())
        }

        function s() {
            try {
                return "[object process]" === Object.prototype.toString.call(t.process)
            } catch (t) {
                return !1
            }
        }

        function u() {
            return "object" == typeof self && self.self === self
        }

        function c() {
            var t = "object" == typeof chrome ? chrome.runtime : "object" == typeof browser ? browser.runtime : void 0;
            return "object" == typeof t && void 0 !== t.id
        }

        function l() {
            return "object" == typeof navigator && "ReactNative" === navigator.product
        }

        function h() {
            return r().indexOf("Electron/index.html") >= 0
        }

        function f() {
            var t = r();
            return t.indexOf("MSIE ") >= 0 || t.indexOf("Trident/index.html") >= 0
        }

        function p() {
            return r().indexOf("MSAppHost/index.html") >= 0
        }

        function d() {
            return !0 === M.NODE_CLIENT || !0 === M.NODE_ADMIN
        }

        function m(t, e) {
            return t.replace(K, function(t, n) {
                var i = e[n];
                return null != i ? "" + i : "<" + n + "?>"
            })
        }

        function v(t) {
            return JSON.parse(t)
        }

        function g(t) {
            return JSON.stringify(t)
        }

        function y(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }

        function b(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e) ? t[e] : void 0
        }

        function w(t) {
            for (var e in t)
                if (Object.prototype.hasOwnProperty.call(t, e)) return !1;
            return !0
        }

        function _(t, e, n) {
            var i = {};
            for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (i[o] = e.call(n, t[o], o, t));
            return i
        }

        function S(t) {
            for (var e = [], n = 0, i = Object.entries(t); i.length > n; n++) {
                var o = i[n],
                    r = o[0],
                    a = o[1];
                ! function(t, n) {
                    Array.isArray(n) ? n.forEach(function(n) {
                        e.push(encodeURIComponent(t) + "=" + encodeURIComponent(n))
                    }) : e.push(encodeURIComponent(t) + "=" + encodeURIComponent(n))
                }(r, a)
            }
            return e.length ? "&" + e.join("&") : ""
        }

        function I(t) {
            var e = {};
            return t.replace(/^\?/, "").split("&").forEach(function(t) {
                if (t) {
                    var n = t.split("=");
                    e[n[0]] = n[1]
                }
            }), e
        }

        function T(t, e) {
            var n = new Z(t, e);
            return n.subscribe.bind(n)
        }

        function N(t, e) {
            return function() {
                for (var n = [], i = 0; arguments.length > i; i++) n[i] = arguments[i];
                Promise.resolve(!0).then(function() {
                    t.apply(void 0, n)
                }).catch(function(t) {
                    e && e(t)
                })
            }
        }

        function k(t, e) {
            if ("object" != typeof t || null === t) return !1;
            for (var n = 0, i = e; i.length > n; n++) {
                var o = i[n];
                if (o in t && "function" == typeof t[o]) return !0
            }
            return !1
        }

        function E() {}

        function C(t, e, n) {
            var i = "";
            switch (e) {
                case 1:
                    i = n ? "first" : "First";
                    break;
                case 2:
                    i = n ? "second" : "Second";
                    break;
                case 3:
                    i = n ? "third" : "Third";
                    break;
                case 4:
                    i = n ? "fourth" : "Fourth";
                    break;
                default:
                    throw Error("errorPrefix called with argumentNumber > 4.  Need to update it?")
            }
            var o = t + " failed: ";
            return o += i + " argument "
        }

        function A(t, e, n, i) {
            if ((!i || n) && "string" != typeof n) throw Error(C(t, e, i) + "must be a valid firebase namespace.")
        }

        function O(t, e, n, i) {
            if ((!i || n) && "function" != typeof n) throw Error(C(t, e, i) + "must be a valid function.")
        }

        function P(t, e, n, i) {
            if ((!i || n) && ("object" != typeof n || null === n)) throw Error(C(t, e, i) + "must be a valid context object.")
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var x = n(3),
            M = {
                NODE_CLIENT: !1,
                NODE_ADMIN: !1,
                SDK_VERSION: "${JSCORE_VERSION}"
            },
            L = function(t, e) {
                if (!t) throw j(e)
            },
            j = function(t) {
                return Error("Firebase Database (" + M.SDK_VERSION + ") INTERNAL ASSERT FAILED: " + t)
            },
            D = function(t) {
                for (var e = [], n = 0, i = 0; t.length > i; i++) {
                    var o = t.charCodeAt(i);
                    128 > o ? e[n++] = o : 2048 > o ? (e[n++] = o >> 6 | 192, e[n++] = 63 & o | 128) : 55296 == (64512 & o) && t.length > i + 1 && 56320 == (64512 & t.charCodeAt(i + 1)) ? (o = 65536 + ((1023 & o) << 10) + (1023 & t.charCodeAt(++i)), e[n++] = o >> 18 | 240, e[n++] = o >> 12 & 63 | 128, e[n++] = o >> 6 & 63 | 128, e[n++] = 63 & o | 128) : (e[n++] = o >> 12 | 224, e[n++] = o >> 6 & 63 | 128, e[n++] = 63 & o | 128)
                }
                return e
            },
            R = function(t) {
                for (var e = [], n = 0, i = 0; t.length > n;) {
                    var o = t[n++];
                    if (128 > o) e[i++] = String.fromCharCode(o);
                    else if (o > 191 && 224 > o) {
                        var r = t[n++];
                        e[i++] = String.fromCharCode((31 & o) << 6 | 63 & r)
                    } else if (o > 239 && 365 > o) {
                        var r = t[n++],
                            a = t[n++],
                            s = t[n++],
                            u = ((7 & o) << 18 | (63 & r) << 12 | (63 & a) << 6 | 63 & s) - 65536;
                        e[i++] = String.fromCharCode(55296 + (u >> 10)), e[i++] = String.fromCharCode(56320 + (1023 & u))
                    } else {
                        var r = t[n++],
                            a = t[n++];
                        e[i++] = String.fromCharCode((15 & o) << 12 | (63 & r) << 6 | 63 & a)
                    }
                }
                return e.join("")
            },
            U = {
                byteToCharMap_: null,
                charToByteMap_: null,
                byteToCharMapWebSafe_: null,
                charToByteMapWebSafe_: null,
                ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
                get ENCODED_VALS() {
                    return this.ENCODED_VALS_BASE + "+/="
                },
                get ENCODED_VALS_WEBSAFE() {
                    return this.ENCODED_VALS_BASE + "-_."
                },
                HAS_NATIVE_SUPPORT: "function" == typeof atob,
                encodeByteArray: function(t, e) {
                    if (!Array.isArray(t)) throw Error("encodeByteArray takes an array as a parameter");
                    this.init_();
                    for (var n = e ? this.byteToCharMapWebSafe_ : this.byteToCharMap_, i = [], o = 0; t.length > o; o += 3) {
                        var r = t[o],
                            a = t.length > o + 1,
                            s = a ? t[o + 1] : 0,
                            u = t.length > o + 2,
                            c = u ? t[o + 2] : 0,
                            l = r >> 2,
                            h = (3 & r) << 4 | s >> 4,
                            f = (15 & s) << 2 | c >> 6,
                            p = 63 & c;
                        u || (p = 64, a || (f = 64)), i.push(n[l], n[h], n[f], n[p])
                    }
                    return i.join("")
                },
                encodeString: function(t, e) {
                    return this.HAS_NATIVE_SUPPORT && !e ? btoa(t) : this.encodeByteArray(D(t), e)
                },
                decodeString: function(t, e) {
                    return this.HAS_NATIVE_SUPPORT && !e ? atob(t) : R(this.decodeStringToByteArray(t, e))
                },
                decodeStringToByteArray: function(t, e) {
                    this.init_();
                    for (var n = e ? this.charToByteMapWebSafe_ : this.charToByteMap_, i = [], o = 0; t.length > o;) {
                        var r = n[t.charAt(o++)],
                            a = t.length > o,
                            s = a ? n[t.charAt(o)] : 0;
                        ++o;
                        var u = t.length > o,
                            c = u ? n[t.charAt(o)] : 64;
                        ++o;
                        var l = t.length > o,
                            h = l ? n[t.charAt(o)] : 64;
                        if (++o, null == r || null == s || null == c || null == h) throw Error();
                        i.push(r << 2 | s >> 4), 64 !== c && (i.push(s << 4 & 240 | c >> 2), 64 !== h && i.push(c << 6 & 192 | h))
                    }
                    return i
                },
                init_: function() {
                    if (!this.byteToCharMap_) {
                        this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
                        for (var t = 0; this.ENCODED_VALS.length > t; t++) this.byteToCharMap_[t] = this.ENCODED_VALS.charAt(t), this.charToByteMap_[this.byteToCharMap_[t]] = t, this.byteToCharMapWebSafe_[t] = this.ENCODED_VALS_WEBSAFE.charAt(t), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]] = t, this.ENCODED_VALS_BASE.length > t || (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)] = t, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)] = t)
                    }
                }
            },
            V = function(t) {
                var e = D(t);
                return U.encodeByteArray(e, !0)
            },
            F = function(t) {
                try {
                    return U.decodeString(t, !0)
                } catch (t) {}
                return null
            },
            B = function() {
                function t() {
                    var t = this;
                    this.reject = function() {}, this.resolve = function() {}, this.promise = new Promise(function(e, n) {
                        t.resolve = e, t.reject = n
                    })
                }
                return t.prototype.wrapCallback = function(t) {
                    var e = this;
                    return function(n, i) {
                        n ? e.reject(n) : e.resolve(i), "function" == typeof t && (e.promise.catch(function() {}), 1 === t.length ? t(n) : t(n, i))
                    }
                }, t
            }(),
            H = "FirebaseError",
            G = function(t) {
                function e(n, i) {
                    var o = t.call(this, i) || this;
                    return o.code = n, o.name = H, Object.setPrototypeOf(o, e.prototype), Error.captureStackTrace && Error.captureStackTrace(o, W.prototype.create), o
                }
                return x.__extends(e, t), e
            }(Error),
            W = function() {
                function t(t, e, n) {
                    this.service = t, this.serviceName = e, this.errors = n
                }
                return t.prototype.create = function(t) {
                    for (var e = [], n = 1; arguments.length > n; n++) e[n - 1] = arguments[n];
                    for (var i = e[0] || {}, o = this.service + "/" + t, r = this.errors[t], a = r ? m(r, i) : "Error", s = this.serviceName + ": " + a + " (" + o + ").", u = new G(o, s), c = 0, l = Object.keys(i); l.length > c; c++) {
                        var h = l[c];
                        "_" !== h.slice(-1) && (u[h] = i[h])
                    }
                    return u
                }, t
            }(),
            K = /\{\$([^}]+)}/g,
            q = function(t) {
                var e = {},
                    n = {},
                    i = {},
                    o = "";
                try {
                    var r = t.split(".");
                    e = v(F(r[0]) || ""), n = v(F(r[1]) || ""), o = r[2], i = n.d || {}, delete n.d
                } catch (t) {}
                return {
                    header: e,
                    claims: n,
                    data: i,
                    signature: o
                }
            },
            z = function(t) {
                var e = q(t).claims,
                    n = Math.floor((new Date).getTime() / 1e3),
                    i = 0,
                    o = 0;
                return "object" == typeof e && (e.hasOwnProperty("nbf") ? i = e.nbf : e.hasOwnProperty("iat") && (i = e.iat), o = e.hasOwnProperty("exp") ? e.exp : i + 86400), !(!n || !i || !o || i > n || n > o)
            },
            X = function(t) {
                var e = q(t).claims;
                return "object" == typeof e && e.hasOwnProperty("iat") ? e.iat : null
            },
            J = function(t) {
                var e = q(t),
                    n = e.claims;
                return !!n && "object" == typeof n && n.hasOwnProperty("iat")
            },
            Y = function(t) {
                var e = q(t).claims;
                return "object" == typeof e && !0 === e.admin
            },
            $ = function() {
                function t() {
                    this.chain_ = [], this.buf_ = [], this.W_ = [], this.pad_ = [], this.inbuf_ = 0, this.total_ = 0, this.blockSize = 64, this.pad_[0] = 128;
                    for (var t = 1; this.blockSize > t; ++t) this.pad_[t] = 0;
                    this.reset()
                }
                return t.prototype.reset = function() {
                    this.chain_[0] = 1732584193, this.chain_[1] = 4023233417, this.chain_[2] = 2562383102, this.chain_[3] = 271733878, this.chain_[4] = 3285377520, this.inbuf_ = 0, this.total_ = 0
                }, t.prototype.compress_ = function(t, e) {
                    e || (e = 0);
                    var n = this.W_;
                    if ("string" == typeof t)
                        for (var i = 0; 16 > i; i++) n[i] = t.charCodeAt(e) << 24 | t.charCodeAt(e + 1) << 16 | t.charCodeAt(e + 2) << 8 | t.charCodeAt(e + 3), e += 4;
                    else
                        for (var i = 0; 16 > i; i++) n[i] = t[e] << 24 | t[e + 1] << 16 | t[e + 2] << 8 | t[e + 3], e += 4;
                    for (var i = 16; 80 > i; i++) {
                        var o = n[i - 3] ^ n[i - 8] ^ n[i - 14] ^ n[i - 16];
                        n[i] = 4294967295 & (o << 1 | o >>> 31)
                    }
                    for (var r, a, s = this.chain_[0], u = this.chain_[1], c = this.chain_[2], l = this.chain_[3], h = this.chain_[4], i = 0; 80 > i; i++) {
                        40 > i ? 20 > i ? (r = l ^ u & (c ^ l), a = 1518500249) : (r = u ^ c ^ l, a = 1859775393) : 60 > i ? (r = u & c | l & (u | c), a = 2400959708) : (r = u ^ c ^ l, a = 3395469782);
                        var o = (s << 5 | s >>> 27) + r + h + a + n[i] & 4294967295;
                        h = l, l = c, c = 4294967295 & (u << 30 | u >>> 2), u = s, s = o
                    }
                    this.chain_[0] = this.chain_[0] + s & 4294967295, this.chain_[1] = this.chain_[1] + u & 4294967295, this.chain_[2] = this.chain_[2] + c & 4294967295, this.chain_[3] = this.chain_[3] + l & 4294967295, this.chain_[4] = this.chain_[4] + h & 4294967295
                }, t.prototype.update = function(t, e) {
                    if (null != t) {
                        void 0 === e && (e = t.length);
                        for (var n = e - this.blockSize, i = 0, o = this.buf_, r = this.inbuf_; e > i;) {
                            if (0 === r)
                                for (; n >= i;) this.compress_(t, i), i += this.blockSize;
                            if ("string" == typeof t) {
                                for (; e > i;)
                                    if (o[r] = t.charCodeAt(i), ++r, ++i, r === this.blockSize) {
                                        this.compress_(o), r = 0;
                                        break
                                    }
                            } else
                                for (; e > i;)
                                    if (o[r] = t[i], ++r, ++i, r === this.blockSize) {
                                        this.compress_(o), r = 0;
                                        break
                                    }
                        }
                        this.inbuf_ = r, this.total_ += e
                    }
                }, t.prototype.digest = function() {
                    var t = [],
                        e = 8 * this.total_;
                    56 > this.inbuf_ ? this.update(this.pad_, 56 - this.inbuf_) : this.update(this.pad_, this.blockSize - (this.inbuf_ - 56));
                    for (var n = this.blockSize - 1; n >= 56; n--) this.buf_[n] = 255 & e, e /= 256;
                    this.compress_(this.buf_);
                    for (var i = 0, n = 0; 5 > n; n++)
                        for (var o = 24; o >= 0; o -= 8) t[i] = this.chain_[n] >> o & 255, ++i;
                    return t
                }, t
            }(),
            Z = function() {
                function t(t, e) {
                    var n = this;
                    this.observers = [], this.unsubscribes = [], this.observerCount = 0, this.task = Promise.resolve(), this.finalized = !1, this.onNoObservers = e, this.task.then(function() {
                        t(n)
                    }).catch(function(t) {
                        n.error(t)
                    })
                }
                return t.prototype.next = function(t) {
                    this.forEachObserver(function(e) {
                        e.next(t)
                    })
                }, t.prototype.error = function(t) {
                    this.forEachObserver(function(e) {
                        e.error(t)
                    }), this.close(t)
                }, t.prototype.complete = function() {
                    this.forEachObserver(function(t) {
                        t.complete()
                    }), this.close()
                }, t.prototype.subscribe = function(t, e, n) {
                    var i, o = this;
                    if (void 0 === t && void 0 === e && void 0 === n) throw Error("Missing Observer.");
                    i = k(t, ["next", "error", "complete"]) ? t : {
                        next: t,
                        error: e,
                        complete: n
                    }, void 0 === i.next && (i.next = E), void 0 === i.error && (i.error = E), void 0 === i.complete && (i.complete = E);
                    var r = this.unsubscribeOne.bind(this, this.observers.length);
                    return this.finalized && this.task.then(function() {
                        try {
                            o.finalError ? i.error(o.finalError) : i.complete()
                        } catch (t) {}
                    }), this.observers.push(i), r
                }, t.prototype.unsubscribeOne = function(t) {
                    void 0 !== this.observers && void 0 !== this.observers[t] && (delete this.observers[t], 0 == (this.observerCount -= 1) && void 0 !== this.onNoObservers && this.onNoObservers(this))
                }, t.prototype.forEachObserver = function(t) {
                    if (!this.finalized)
                        for (var e = 0; this.observers.length > e; e++) this.sendOne(e, t)
                }, t.prototype.sendOne = function(t, e) {
                    var n = this;
                    this.task.then(function() {
                        if (void 0 !== n.observers && void 0 !== n.observers[t]) try {
                            e(n.observers[t])
                        } catch (t) {
                            "undefined" != typeof console && console
                        }
                    })
                }, t.prototype.close = function(t) {
                    var e = this;
                    this.finalized || (this.finalized = !0, void 0 !== t && (this.finalError = t), this.task.then(function() {
                        e.observers = void 0, e.onNoObservers = void 0
                    }))
                }, t
            }(),
            Q = function(t, e, n, i) {
                var o;
                if (e > i ? o = "at least " + e : i > n && (o = 0 === n ? "none" : "no more than " + n), o) {
                    var r = t + " failed: Was called with " + i + (1 === i ? " argument." : " arguments.") + " Expects " + o + ".";
                    throw Error(r)
                }
            },
            tt = function(t) {
                for (var e = [], n = 0, i = 0; t.length > i; i++) {
                    var o = t.charCodeAt(i);
                    if (o >= 55296 && 56319 >= o) {
                        var r = o - 55296;
                        i++, L(t.length > i, "Surrogate pair missing trail surrogate."), o = 65536 + (r << 10) + (t.charCodeAt(i) - 56320)
                    }
                    128 > o ? e[n++] = o : 2048 > o ? (e[n++] = o >> 6 | 192, e[n++] = 63 & o | 128) : 65536 > o ? (e[n++] = o >> 12 | 224, e[n++] = o >> 6 & 63 | 128, e[n++] = 63 & o | 128) : (e[n++] = o >> 18 | 240, e[n++] = o >> 12 & 63 | 128, e[n++] = o >> 6 & 63 | 128, e[n++] = 63 & o | 128)
                }
                return e
            },
            et = function(t) {
                for (var e = 0, n = 0; t.length > n; n++) {
                    var i = t.charCodeAt(n);
                    128 > i ? e++ : 2048 > i ? e += 2 : 55296 > i || i > 56319 ? e += 3 : (e += 4, n++)
                }
                return e
            };
        e.CONSTANTS = M, e.Deferred = B, e.ErrorFactory = W, e.FirebaseError = G, e.Sha1 = $, e.assert = L, e.assertionError = j, e.async = N, e.base64 = U, e.base64Decode = F, e.base64Encode = V, e.contains = y, e.createSubscribe = T, e.decode = q, e.deepCopy = i, e.deepExtend = o, e.errorPrefix = C, e.getUA = r, e.isAdmin = Y, e.isBrowser = u, e.isBrowserExtension = c, e.isElectron = h, e.isEmpty = w, e.isIE = f, e.isMobileCordova = a, e.isNode = s, e.isNodeSdk = d, e.isReactNative = l, e.isUWP = p, e.isValidFormat = J, e.isValidTimestamp = z, e.issuedAtTime = X, e.jsonEval = v, e.map = _, e.querystring = S, e.querystringDecode = I, e.safeGet = b, e.stringLength = et, e.stringToByteArray = tt, e.stringify = g, e.validateArgCount = Q, e.validateCallback = O, e.validateContextObject = P, e.validateNamespace = A
    }).call(e, n(12))
}, function(t, e, n) {
    "use strict";
    var i = n(9),
        o = {};
    Object.keys(i.soundList).forEach(function(t) {
        var e = i.soundList[t];
        e.pro && (o[t] = e)
    }), t.exports = o
}, function(t, e, n) {
    "use strict";

    function i(t) {
        var e = RegExp("[?&]" + t + "=([^&]*)").exec(window.location.search);
        return e && decodeURIComponent(e[1].replace(/\+/g, " "))
    }
    e.__esModule = !0;
    var o = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        r = n(1),
        a = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        }(r),
        s = function(t) {
            var e = i("v");
            if (!e) return t;
            if ("00000000000000000000" === e) return t;
            var n = o({}, t),
                r = function(t) {
                    return parseInt(t, 16) / 100
                },
                a = e.match(/.{1,2}/g).map(function(t) {
                    return r(t)
                });
            return Object.keys(n).forEach(function(e) {
                var i = o({}, t[e]);
                if (null != i.volumeStringOrder) {
                    var r = a[i.volumeStringOrder];
                    0 > r || r > 1 || (i.volume = r, n[e] = i)
                }
            }), n
        },
        u = function(t, e) {
            var n = i("m"),
                r = i("v");
            if (!n) return r ? s(t) : t;
            try {
                for (var u = [], c = 0; n.length > c; c += 5) u.push(n.substring(c, c + 5));
                var l = !0,
                    h = {};
                if (u.forEach(function(t) {
                        var n = t.substring(0, 3),
                            i = t.substring(3, 5),
                            r = +i / 100,
                            a = Object.keys(e).filter(function(t) {
                                return e[t].shortcode === n
                            }),
                            s = e[a];
                        s.pro && (l = !1), h[s.key] = o({}, s, {
                            volume: r
                        })
                    }), l) {
                    var f = o({}, a.default);
                    f.rain = o({}, f.rain, {
                        volume: 0
                    }), f.thunder = o({}, f.thunder, {
                        volume: 0
                    }), h = o({}, f, h)
                }
                return h
            } catch (e) {
                return t
            }
        };
    e.default = function(t) {
        var e = {},
            n = i("autoplay");
        n = n ? parseInt(n, 10) : 0, e.isPlaying = !!n;
        var o = u(t.sounds, t.library);
        o && (e.sounds = o), e.token = i("token");
        var r = i("utm_source"),
            a = i("utm_campaign"),
            s = void 0;
        return r && a ? s = "&utm_source=" + r + "&utm_campaign=" + a : r ? s = "&utm_source=" + r : a && (s = "&utm_campaign=" + a), s && (e.utmCampaign = a, e.utmSubstring = s), i("waitingForLicense") && (e.waitingForLicense = !0), e
    }
}, function(t, e, n) {
    "use strict";
    e.__esModule = !0;
    var i = n(0),
        o = function(t) {
            var e = "" + t;
            return 1 === e.length && (e = "0" + e), e
        };
    e.default = function(t) {
        var e = void 0,
            n = void 0,
            r = void 0,
            a = void 0;
        return e = t % 60, t -= e, a = t / 60, n = a % 60, a -= n, r = a / 60, (0, i.h)("span", null, (0, i.h)("span", {
            className: "time hours"
        }, o(r).substring(0, 1)), (0, i.h)("span", {
            className: "time hours"
        }, o(r).substring(1, 2)), (0, i.h)("span", {
            className: "colon"
        }, ":"), (0, i.h)("span", {
            className: "time minutes"
        }, o(n).substring(0, 1)), (0, i.h)("span", {
            className: "time minutes"
        }, o(n).substring(1, 2)), (0, i.h)("span", {
            className: "colon"
        }, ":"), (0, i.h)("span", {
            className: "time seconds"
        }, o(e).substring(0, 1)), (0, i.h)("span", {
            className: "time seconds"
        }, o(e).substring(1, 2)))
    }
}, function(t) {
    "use strict";
    var e = ["rain", "thunder", "waves", "wind", "fire", "birds", "crickets", "people", "sbowl", "whitenoise", "aircon", "fanhigh", "fanlow", "city", "chimesmetal", "stream", "raintinroof", "raintrees", "raincabin", "waterfall", "cicadas", "brownnoise", "pinknoise"],
        n = {
            rain: "Rain",
            thunder: "Thunder",
            waves: "Waves",
            wind: "Wind",
            fire: "Fire",
            birds: "Birds",
            crickets: "Crickets",
            people: "Coffee shop",
            sbowl: "Singing Bowl",
            whitenoise: "White noise",
            aircon: "Air conditioning",
            fanhigh: "Fan on high",
            fanlow: "Fan on low",
            city: "City",
            chimesmetal: "Metal chimes",
            stream: "Stream",
            raintinroof: "Rain on tin roof",
            raintrees: "Rain on trees",
            raincabin: "Rain on cabin",
            waterfall: "Waterfall",
            cicadas: "Cicadas",
            brownnoise: "Brown noise",
            pinknoise: "Pink noise"
        },
        i = {
            rain: "rno",
            thunder: "thn",
            waves: "wve",
            wind: "wnd",
            fire: "fre",
            birds: "brd",
            crickets: "crk",
            people: "pep",
            sbowl: "sbo",
            whitenoise: "wno",
            aircon: "arc",
            fanhigh: "fnh",
            fanlow: "fnl",
            city: "cit",
            chimesmetal: "chm",
            stream: "str",
            raintinroof: "rnr",
            raintrees: "rnt",
            raincabin: "rnc",
            waterfall: "wtr",
            cicadas: "cic",
            brownnoise: "brn",
            pinknoise: "pnk"
        },
        o = {
            rain: !0,
            thunder: !0,
            waves: !0,
            wind: !0,
            fire: !0,
            birds: !0,
            crickets: !0,
            people: !0,
            sbowl: !0,
            whitenoise: !0,
            aircon: !1,
            fanhigh: !1,
            fanlow: !1,
            city: !1,
            chimesmetal: !1,
            stream: !1,
            raintinroof: !1,
            raintrees: !1,
            raincabin: !1,
            waterfall: !1,
            cicadas: !1,
            brownnoise: !1,
            pinknoise: !1
        },
        r = {
            rain: 0,
            thunder: 1,
            waves: 3,
            wind: 9,
            fire: 2,
            birds: 4,
            crickets: 6,
            people: 5,
            sbowl: 7,
            whitenoise: 8,
            aircon: 100,
            fanhigh: 100,
            fanlow: 100,
            city: 100,
            chimesmetal: 100,
            stream: 100,
            raintinroof: 100,
            raintrees: 100,
            raincabin: 100,
            waterfall: 100,
            cicadas: 100,
            brownnoise: 100,
            pinknoise: 100
        },
        a = {
            rain: 1,
            thunder: 2,
            waves: 3,
            wind: 4,
            fire: 5,
            birds: 6,
            crickets: 7,
            people: 8,
            sbowl: 9,
            whitenoise: 10,
            aircon: 21,
            fanhigh: 20,
            fanlow: 19,
            city: 18,
            chimesmetal: 17,
            stream: 14,
            raintinroof: 12,
            raintrees: 11,
            raincabin: 13,
            waterfall: 15,
            cicadas: 16,
            brownnoise: 99,
            pinknoise: 100
        },
        s = {
            rain: ["downpour", "shower", "drizzle"],
            thunder: ["lightning", "storm", "rumble"],
            waves: ["waves", "swimming", "high tide"],
            wind: ["breeze", "gale", "strong gusts"],
            fire: ["fire"],
            birds: ["birdsong", "songbirds"],
            crickets: ["crickets", "chirping"],
            people: ["murmur", "conversation"],
            sbowl: ["meditation"],
            whitenoise: ["white noise", "static", "untuned radio"],
            aircon: ["air conditioning", "hum"],
            fanhigh: ["fan"],
            fanlow: ["fan"],
            city: ["murmur", "rumble,"],
            chimesmetal: ["wind chimes", "tinkling,"],
            stream: ["burble"],
            raintinroof: ["downpour", "shower", "drizzle"],
            raintrees: ["downpour", "shower", "drizzle"],
            raincabin: ["downpour", "shower", "drizzle"],
            waterfall: ["waterfall"],
            cicadas: ["drone", "buzzing", "cicadas"],
            brownnoise: ["white noise", "static", "untuned radio"],
            pinknoise: ["white noise", "static", "untuned radio"]
        },
        u = {
            rain: ["wet", "damp", "rainy"],
            thunder: ["stormy", "turbulent"],
            waves: ["surging", "stormy", "choppy"],
            wind: ["windswept", "wild", "airy"],
            fire: ["cozy", "snug"],
            birds: ["early", "lively"],
            crickets: ["early", "solitary", "chirping"],
            people: ["ambient"],
            sbowl: ["peaceful", "mellow", "relaxing"],
            whitenoise: ["humming"],
            aircon: ["humid", "warm", "hot", "sunny"],
            fanhigh: ["humid", "warm", "hot", "sunny"],
            fanlow: ["humid", "warm", "hot", "sunny"],
            city: ["busy"],
            chimesmetal: ["breezy", "gusty", "windswept"],
            stream: ["bubbling", "streaming", "flowing"],
            raintinroof: ["wet", "damp", "rainy"],
            raintrees: ["wet", "damp", "rainy"],
            raincabin: ["wet", "damp", "rainy"],
            waterfall: ["bubbling", "streaming", "flowing"],
            cicadas: ["hot", "peaceful", "buzzing"],
            brownnoise: ["humming"],
            pinknoise: ["humming"]
        },
        c = {
            rain: ["the valley", "the hillside", "the plains", "the forest", "Glen Shiel"],
            thunder: ["the cabin"],
            waves: ["the beach", "the lake", "the seaside", "the ocean", "the river", "the rock pool", "Balnahard"],
            wind: ["my tent", "the mountain top", "Cairn Toul"],
            fire: ["the inn", "the campfire", "the bonfire"],
            birds: ["the woods", "the park"],
            crickets: ["the meadow", "the prairie", "the wild grass", "the pasture"],
            people: ["the coffee shop", "the café", "the tearoom"],
            sbowl: ["the temple", "the mountains", "Kyoto"],
            whitenoise: ["the power lines"],
            aircon: ["the hotel", "home", "my house"],
            fanhigh: ["the hotel", "home", "my house"],
            fanlow: ["the hotel", "home", "my house"],
            city: ["the city", , "Ginza", "the thirty-sixth floor"],
            chimesmetal: ["the garden", "the front porch"],
            stream: ["the stream", "the river", "the brook", "the burn"],
            raintinroof: ["the boathouse", "the shed"],
            raintrees: ["the wet forest", "the dripping branches"],
            raincabin: ["the cabin", "the cottage"],
            waterfall: ["the waterfall", "Five Fingers"],
            cicadas: ["the pines", "the meadow", "the trees", "the tall grass"],
            brownnoise: ["the dunes"],
            pinknoise: ["the river bend"]
        },
        l = function(t) {
            var e = {},
                n = !0;
            return Object.keys(t).forEach(function(i) {
                e[t[i]] && (n = !1), e[t[i]] = !0
            }), n
        };
    t.exports = {
        soundList: function() {
            if (!l(i)) throw Error("non-unique shortcodes detected");
            var t = {};
            return e.forEach(function(e) {
                t[e] = {
                    id: e
                }, t[e].key = e, t[e].shortcode = i[e], t[e].pro = !o[e], t[e].label = n[e], t[e].sortKey = a[e], t[e].nouns = s[e], t[e].adjectives = u[e], t[e].places = c[e], t[e].volumeStringOrder = r[e], t[e].volume = "rain" === e ? .6 : "thunder" === e ? .3 : 0
            }), t
        }()
    }
}, function(t, e) {
    "use strict";
    e.__esModule = !0, e.default = function(t) {
        try {
            if (URLSearchParams && window.location && history && history.replaceState) {
                var e = new URL(window.html),
                    n = new URLSearchParams(e.search);
                if (!n.get(t)) return;
                n.delete(t);
                var i = ("" + n).length ? "?" : "";
                history.replaceState("", "", "" + window.location.pathname + i + n)
            }
        } catch (t) {
            return
        }
    }
}, function(t, e, n) {
    "use strict";
    var i = function(t) {
        return t && "object" == typeof t && "default" in t ? t.default : t
    }(n(4));
    i.registerVersion("firebase", "7.14.6", "app"), t.exports = i
}, function(t) {
    var e;
    e = function() {
        return this
    }();
    try {
        e = e || Function("return this")() || (0, eval)("this")
    } catch (t) {
        "object" == typeof window && (e = window)
    }
    t.exports = e
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function o(t, e) {}

    function r(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function a(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var s = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        u = n(0),
        c = n(23),
        l = i(c),
        h = n(47),
        f = i(h),
        p = n(26),
        d = i(p),
        m = n(28),
        v = (i(m), n(31)),
        g = i(v),
        y = n(37),
        b = i(y),
        w = n(44),
        _ = i(w),
        S = n(24),
        I = i(S),
        T = n(22),
        N = i(T),
        k = n(30),
        E = i(k),
        C = n(49),
        A = i(C),
        O = n(21),
        P = i(O),
        x = n(32),
        M = (i(x), n(50)),
        L = i(M),
        j = n(51),
        D = i(j),
        R = n(46),
        U = i(R),
        V = n(48),
        F = i(V),
        B = n(6),
        H = i(B),
        G = n(1),
        W = i(G),
        K = n(57),
        q = i(K),
        z = n(59),
        X = i(z),
        J = n(7),
        Y = i(J),
        $ = n(10),
        Z = i($),
        Q = n(54),
        tt = i(Q),
        et = n(58),
        nt = i(et),
        it = n(11),
        ot = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
            return e.default = t, e
        }(it);
    n(16);
    var rt = n(19);
    window.ENV = "PROD", window.IOS = /(iPad|iPhone|iPod)/g.test(navigator.userAgent), window.SOUND_VERSION = "1.01";
    var at = navigator.userAgent.includes("Node.html") || navigator.userAgent.includes("jsdom"),
        st = 2500,
        ut = ot.auth;
    n(20), n(89);
    var ct = function(t) {
        return t > .02 ? t : 0
    };
    e.default = function(t) {
        function e() {
            o(this, e);
            var n = r(this, t.call(this));
            return n.getUpdatedUser = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                    e = function() {
                        n.setState({
                            showToast: "pro_timeout",
                            waitingForLicense: !1
                        })
                    },
                    i = function() {
                        try {
                            ut().currentUser.reload()
                        } catch (t) {}
                    },
                    o = function() {
                        t > 10 ? e() : (i(), setTimeout(function() {
                            return n.getUpdatedUser(t + 1)
                        }, st))
                    };
                n.state.user || o();
                var r = JSON.parse(ut().currentUser.displayName || "{}");
                r.p ? (n.activatePro(r.expires), n._setState({
                    showToast: "welcome"
                })) : o()
            }, n.activatePro = function(t, e) {
                n._setState({
                    library: s({}, n.state.availableSounds),
                    pro: !0,
                    proExpires: t,
                    proLastChecked: Date.now(),
                    proFirstLoad: e,
                    waitingForLicense: !1
                })
            }, n.deactivatePro = function() {
                n._setState({
                    library: s({}, W.default),
                    pro: !1,
                    proExpires: null,
                    proLastChecked: null,
                    proFirstLoad: null
                })
            }, n.promptForEmail = function() {
                n._setState({
                    upgradeDialog: 4
                })
            }, n.toggleAccountView = function() {
                n.toggleModal("accountView")
            }, n.toggleModal = function(t) {
                if (n.state.modal === t) return n._setState({
                    modal: null
                });
                n._setState({
                    modal: t
                })
            }, n.signOut = function() {
                ut().signOut().then(function() {
                    return n._setState({
                        modal: null,
                        user: null
                    }, n.deactivatePro)
                }).catch(function() {})
            }, n.getModal = function() {
                return "accountView" === n.state.modal ? (0, u.h)(P.default, {
                    user: n.state.user,
                    onSignOut: n.signOut,
                    onCancel: n.toggleAccountView,
                    upgradeToPro: function() {
                        return n._setState({
                            upgradeDialog: 1,
                            modal: null
                        })
                    }
                }) : null
            }, n.getToast = function() {
                return n.state.showToast ? (0, u.h)(F.default, {
                    variety: n.state.showToast,
                    onClose: function() {
                        return n._setState({
                            showToast: null
                        })
                    }
                }) : null
            }, n.hideSiteDescription = function() {
                n._setState({
                    hideSiteDescription: !0
                })
            }, n.state = {}, n._setState = n._setState.bind(n), n.changeGlobalVolume = n.changeGlobalVolume.bind(n), n.togglePlay = n.togglePlay.bind(n), n.hideAppLinks = n.hideAppLinks.bind(n), n.updateSoundVolume = n.updateSoundVolume.bind(n), n.onTapSoundImage = n.onTapSoundImage.bind(n), n.handleTimerStart = n.handleTimerStart.bind(n), n.handleTimerCancel = n.handleTimerCancel.bind(n), n.handleAddMix = n.handleAddMix.bind(n), n.handleLoadMix = n.handleLoadMix.bind(n), n.handleDeleteMix = n.handleDeleteMix.bind(n), n.toggleMeander = n.toggleMeander.bind(n), n.toggleReset = n.toggleReset.bind(n), n.onTouchStart = n.onTouchStart.bind(n), n.onTouchEnd = n.onTouchEnd.bind(n), n.handleToggleSoundActive = n.handleToggleSoundActive.bind(n), n.handleStopActivity = n.handleStopActivity.bind(n), n.handleClearAllSounds = n.handleClearAllSounds.bind(n), n.activatePro = n.activatePro.bind(n), n.showProHelp = n.showProHelp.bind(n), n
        }
        return a(e, t), e.prototype.componentWillMount = function() {
            var t = this,
                e = s({}, q.default),
                n = nt.default.get();
            n && (e = s({}, e, n)), delete e.waitingForLicense;
            var i = (0, Y.default)(e);
            e = s({}, e, i), e.waitingForLicense && ((0, Z.default)("waitingForLicense"), setTimeout(this.getUpdatedUser, st)), e.pro && delete e.waitingForLicense, delete e.token, delete e.modal, at || ((0, rt.setFirebaseAuthStateChangedListener)(ut, function() {
                return t.state
            }, this._setState, this.activatePro, this.deactivatePro), (0, rt.checkFirebaseEmailLink)(ut, e, this._setState, this.promptForEmail)), this._setState(e)
        }, e.prototype.componentWillUpdate = function(t, e) {
            var n = this,
                i = !(!this.state.timer.isActive && !this.state.meander.isActive),
                o = !(!e.timer.isActive || this.state.timer.isActive),
                r = !(!e.meander.isActive || this.state.meander.isActive);
            !o && !r || i || (this.lastScheduled = Date.now(), this.timer = function() {
                var t = (0, X.default)(s({}, n.state));
                if (t.timer.isActive || t.meander.isActive) {
                    var e = 1e3 - (Date.now() - n.lastScheduled),
                        i = 1e3 + e;
                    n.lastScheduled = Date.now(), setTimeout(n.timer, i)
                }
                n._setState(t, null, !0)
            }, setTimeout(this.timer, 1e3));
            var a = !(!e.timer.isActive && !e.meander.isActive);
            i && !a && clearTimeout(this.timer), !this.state.proFirstLoad && e.proFirstLoad && this.showProHelp()
        }, e.prototype._setState = function(t, e, n) {
            var i = this;
            this.state.stateToReset && !n && (t.stateToReset = null), this.setState(t, function() {
                nt.default.set(i.state), e && e()
            })
        }, e.prototype.showProHelp = function() {
            var t = this,
                e = function() {
                    t.state.proFirstLoad && t._setState({
                        proFirstLoad: !1
                    })
                };
            setTimeout(e, 5e3)
        }, e.prototype.changeGlobalVolume = function(t) {
            this._setState({
                globalVolume: t
            })
        }, e.prototype.togglePlay = function() {
            this.state.isPlaying ? this._setState({
                isPlaying: !1,
                meander: {
                    isActive: !1,
                    sounds: null
                }
            }) : this._setState({
                isPlaying: !0
            })
        }, e.prototype.hideAppLinks = function() {
            this._setState({
                appLinksHidden: !0
            })
        }, e.prototype.handleClearAllSounds = function() {
            this._setState({
                sounds: 0 === Object.keys(this.state.sounds).length ? s({}, W.default) : {},
                forceUpdateIndex: this.state.forceUpdateIndex + 1 || 1
            }), this.handleStopActivity()
        }, e.prototype.handleToggleSoundActive = function(t) {
            var e = s({}, this.state.sounds);
            this.state.sounds[t] ? delete e[t] : e[t] = s({}, this.state.library[t]), this._setState({
                sounds: e,
                forceUpdateIndex: this.state.forceUpdateIndex + 1 || 1
            }), this.handleStopActivity()
        }, e.prototype.handleStopActivity = function() {
            this.state.isPlaying && this.togglePlay(), this.state.timer.isActive && this.handleTimerCancel(), this.state.meander.isActive && this._setState({
                meander: {
                    isActive: !1,
                    sounds: null
                }
            })
        }, e.prototype.handleTimerStart = function(t) {
            var e = this,
                n = {},
                i = t.mode,
                o = {
                    isActive: !0,
                    secondsLeft: t.secondsLeft,
                    mode: i
                };
            if ("fade" === i) {
                if ("current" === t.origin);
                else if ("silence" === t.origin) {
                    var r = {};
                    Object.keys(this.state.sounds).map(function(t) {
                        return s({}, e.state.sounds[t])
                    }).map(function(t) {
                        return t.volume = 0, t
                    }).forEach(function(t) {
                        r[t.key] = t
                    }), n.sounds = r, n.forceUpdateIndex = this.state.forceUpdateIndex + 1 || 1
                } else if (t.origin.indexOf("mix:") > -1) {
                    var a = t.origin.replace("mix:", "");
                    n.sounds = s({}, this.state.savedMixes[a].sounds)
                }
                var u = {};
                if (Object.keys(this.state.sounds).forEach(function(n) {
                        if (u[n] = s({}, e.state.sounds[n]), delete u[n].volume, "current" === t.destination) u[n].volume = e.state.sounds[n] ? e.state.sounds[n].volume : 0;
                        else if ("silence" === t.destination) u[n].volume = 0;
                        else if (t.destination.indexOf("mix:") > -1) {
                            var i = t.destination.replace("mix:", ""),
                                o = e.state.savedMixes[i];
                            u[n].volume = o.sounds[n] ? o.sounds[n].volume : 0
                        }
                    }), "current" === t.destination) o.destinationMessage = "Fade in will finish in";
                else if ("silence" === t.destination) o.destinationMessage = "Fade out will finish in";
                else if (t.destination.indexOf("mix:") > -1) {
                    var c = t.destination.replace("mix:", ""),
                        l = this.state.savedMixes[c].name;
                    o.destinationMessage = 'Fade to "' + l + '" will finish in'
                }
                o.destination = u
            }
            var h = this.state.isPlaying;
            "stop" !== i && "fade" !== i || (h = !0), "start" === i && (h = !1), n.timer = o, n.isPlaying = h, n.forceUpdateIndex = this.state.forceUpdateIndex + 1 || 1, this._setState(n)
        }, e.prototype.handleTimerCancel = function() {
            this._setState({
                timer: {
                    isActive: !1
                }
            })
        }, e.prototype.updateSoundVolume = function(t, e, n) {
            var i = s({}, this.state.sounds[t]);
            i.volume = ct(e);
            var o = {};
            o[i.key] = i;
            var r = s({}, this.state.sounds, o),
                a = n ? this.state.forceUpdateIndex + 1 : this.state.forceUpdateIndex,
                u = {
                    sounds: r,
                    forceUpdateIndex: a
                };
            if (this.state.meander.isActive) {
                var c = s({}, this.state.meander);
                c.sounds = s({}, c.sounds), c.sounds[t].baseVolume = e, c.sounds[t].tickOffset = this.state.meander.tickCount, u.meander = c
            }
            this._setState(u)
        }, e.prototype.onTapSoundImage = function(t) {
            var e = this.state.sounds[t].volume,
                n = window && window.IOS,
                i = void 0;
            i = n ? e > .02 ? 0 : 1 : .3 > e ? .34 : .6 > e ? .64 : .98 > e ? 1 : 0, this.updateSoundVolume(t, i, !0)
        }, e.prototype.handleAddMix = function(t) {
            var e = (0, tt.default)(),
                n = s({}, this.state.savedMixes);
            n[e] = {
                name: t,
                id: e,
                sounds: s({}, this.state.sounds)
            }, this._setState({
                savedMixes: n
            })
        }, e.prototype.handleDeleteMix = function(t) {
            var e = s({}, this.state.savedMixes);
            delete e[t], this._setState({
                savedMixes: e
            })
        }, e.prototype.handleLoadMix = function(t, e) {
            this._setState({
                sounds: e ? s({}, e) : this.state.savedMixes[t].sounds,
                isPlaying: !0,
                forceUpdateIndex: this.state.forceUpdateIndex + 1 || 1,
                meander: s({}, this.state.meander, {
                    sounds: null
                })
            })
        }, e.prototype.toggleMeander = function() {
            var t = this;
            if (this.state.meander.isActive) this._setState({
                meander: {
                    isActive: !1,
                    sounds: null
                }
            });
            else {
                var e = {
                        isActive: !0,
                        sounds: null
                    },
                    n = {
                        meander: e
                    };
                this.state.usedMeanderBefore || (n.showMeanderHelpText = !0, n.usedMeanderBefore = !0, setTimeout(function() {
                    t.setState({
                        showMeanderHelpText: !1
                    })
                }, 5e3)), this._setState(n)
            }
        }, e.prototype.toggleReset = function() {
            var t = this;
            if (this.state.stateToReset) {
                var e = s({}, this.state.stateToReset);
                e.stateToReset = null, e.forceUpdateIndex = this.state.forceUpdateIndex + 1 || 1, this._setState(e)
            } else {
                var n = {};
                Object.keys(this.state.sounds).forEach(function(e) {
                    var i = s({}, t.state.sounds[e]);
                    i.volume = 0, n[e] = i
                });
                var i = s({}, this.state),
                    o = s({}, this.state, {
                        sounds: n
                    }, {
                        timer: s({}, q.default.timer)
                    }, {
                        meander: s({}, q.default.meander)
                    }, {
                        globalVolume: q.default.globalVolume
                    });
                Object.keys(o.sounds).forEach(function(t) {
                    return o.sounds[t].volume = 0
                }), o.stateToReset = i, o.forceUpdateIndex = this.state.forceUpdateIndex + 1 || 1, this._setState(o)
            }
        }, e.prototype.onTouchStart = function() {
            this.setState({
                touchInProgress: !0
            })
        }, e.prototype.onTouchEnd = function() {
            this.setState({
                touchInProgress: !1
            })
        }, e.prototype.render = function() {
            var t = this;
            return (0, u.h)("div", {
                id: "App",
                className: window.IOS ? "ios" : ""
            }, (0, u.h)(l.default, null), (0, u.h)(d.default, {
                volume: this.state.globalVolume,
                onChangeVolume: this.changeGlobalVolume,
                toggleLoginView: function() {
                    return t._setState({
                        upgradeDialog: -2
                    })
                },
                toggleAccountView: this.toggleAccountView,
                user: this.state.user
            }), this.state.waitingForLicense ? (0, u.h)(L.default, {
                onClose: function() {
                    return t._setState({
                        waitingForLicense: !1
                    })
                }
            }) : null, this.state.waitingForLogin ? (0, u.h)(D.default, {
                onClose: function() {
                    return t._setState({
                        waitingForLogin: !1
                    })
                }
            }) : null, this.getModal(), this.getToast(), (0, u.h)(f.default, null), (0, u.h)(g.default, {
                isPlaying: this.state.isPlaying,
                togglePlay: this.togglePlay,
                toggleMeander: this.toggleMeander,
                toggleReset: this.toggleReset,
                canRestore: !!this.state.stateToReset,
                meanderActive: this.state.meander.isActive,
                showMeanderHelpText: this.state.showMeanderHelpText
            }), (0, u.h)(b.default, {
                pro: this.state.pro,
                sounds: this.state.sounds,
                library: this.state.library,
                timer: s({}, this.state.timer),
                timerStart: this.handleTimerStart,
                timerCancel: this.handleTimerCancel,
                savedTimer: this.state.savedTimer,
                mixes: this.state.savedMixes,
                onAddMix: this.handleAddMix,
                onLoadMix: this.handleLoadMix,
                onDeleteMix: this.handleDeleteMix,
                onToggleSoundActive: this.handleToggleSoundActive,
                handleClearAllSounds: this.handleClearAllSounds,
                handleStopActivity: this.handleStopActivity,
                usedSoundManagerBefore: this.state.usedSoundManagerBefore,
                onOpenSoundManager: function() {
                    return t._setState({
                        usedSoundManagerBefore: !0
                    })
                }
            }), (0, u.h)(N.default, {
                hideAppLinks: this.hideAppLinks,
                hidden: this.state.appLinksHidden,
                utmSubstring: this.state.utmSubstring,
                utmCampaign: this.state.utmCampaign
            }), (0, u.h)(_.default, {
                globalVolume: this.state.globalVolume,
                isPlaying: this.state.isPlaying,
                sounds: this.state.sounds,
                updateSoundVolume: this.updateSoundVolume,
                onTapSoundImage: this.onTapSoundImage,
                forceUpdateIndex: this.state.forceUpdateIndex,
                onTouchStart: this.onTouchStart,
                onTouchEnd: this.onTouchEnd,
                meanderActive: this.state.meander.isActive
            }), this.state.pro ? null : (0, u.h)(E.default, {
                onStart: function() {
                    return t.setState({
                        upgradeDialog: 1
                    })
                }
            }), this.state.upgradeDialog ? (0, u.h)(A.default, {
                stage: this.state.upgradeDialog,
                onDismiss: function() {
                    return t._setState({
                        upgradeDialog: null
                    })
                },
                onSetStage: function(e) {
                    return t._setState({
                        upgradeDialog: e
                    })
                },
                onSetEmail: function(e) {
                    t._setState({
                        emailPendingVerification: e
                    })
                },
                extraSounds: H.default,
                user: this.state.user,
                firebaseAuth: ut,
                finishEmailPrompt: function(e) {
                    (0, rt.checkFirebaseEmailLink)(ut, t.state, t._setState, t.promptForEmail, e)
                }
            }) : null, (0, u.h)(I.default, {
                showAppLinks: this.state.appLinksHidden
            }), this.state.hideSiteDescription ? null : (0, u.h)(U.default, {
                onHide: this.hideSiteDescription
            }))
        }, e
    }(u.Component)
}, function() {}, function() {}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
            value: !0
        }),
        function(t) {
            var e = n(4),
                i = n.n(e);
            (function() {
                function e(t) {
                    var e = 0;
                    return function() {
                        return t.length > e ? {
                            done: !1,
                            value: t[e++]
                        } : {
                            done: !0
                        }
                    }
                }

                function n(t) {
                    var n = "undefined" != typeof Symbol && Symbol.iterator && t[Symbol.iterator];
                    return n ? n.call(t) : {
                        next: e(t)
                    }
                }

                function o() {}

                function r(t) {
                    var e = typeof t;
                    if ("object" == e) {
                        if (!t) return "null";
                        if (t instanceof Array) return "array";
                        if (t instanceof Object) return e;
                        var n = Object.prototype.toString.call(t);
                        if ("[object Window]" == n) return "object";
                        if ("[object Array]" == n || "number" == typeof t.length && void 0 !== t.splice && void 0 !== t.propertyIsEnumerable && !t.propertyIsEnumerable("splice")) return "array";
                        if ("[object Function]" == n || void 0 !== t.call && void 0 !== t.propertyIsEnumerable && !t.propertyIsEnumerable("call")) return "function"
                    } else if ("function" == e && void 0 === t.call) return "object";
                    return e
                }

                function a(t) {
                    var e = r(t);
                    return "array" == e || "object" == e && "number" == typeof t.length
                }

                function s(t) {
                    return "function" == r(t)
                }

                function u(t) {
                    var e = typeof t;
                    return "object" == e && null != t || "function" == e
                }

                function c(t) {
                    return Object.prototype.hasOwnProperty.call(t, Cc) && t[Cc] || (t[Cc] = ++Ac)
                }

                function l(t) {
                    return t.call.apply(t.bind, arguments)
                }

                function h(t, e) {
                    if (!t) throw Error();
                    if (arguments.length > 2) {
                        var n = Array.prototype.slice.call(arguments, 2);
                        return function() {
                            var i = Array.prototype.slice.call(arguments);
                            return Array.prototype.unshift.apply(i, n), t.apply(e, i)
                        }
                    }
                    return function() {
                        return t.apply(e, arguments)
                    }
                }

                function f() {
                    return f = Function.prototype.bind && -1 != ("" + Function.prototype.bind).indexOf("native code") ? l : h, f.apply(null, arguments)
                }

                function p(t) {
                    var e = Array.prototype.slice.call(arguments, 1);
                    return function() {
                        var n = e.slice();
                        return n.push.apply(n, arguments), t.apply(this, n)
                    }
                }

                function d(t, e) {
                    function n() {}
                    n.prototype = e.prototype, t.Za = e.prototype, t.prototype = new n, t.prototype.constructor = t
                }

                function m(t, e, n) {
                    this.code = xc + t, this.message = e || Mc[t] || "", this.a = n || null
                }

                function v(t) {
                    var e = t && t.code;
                    return e ? new m(e.substring(xc.length), t.message, t.serverResponse) : null
                }

                function g(t) {
                    for (var e in Lc)
                        if (Lc[e].id === t) return t = Lc[e], {
                            firebaseEndpoint: t.Ra,
                            secureTokenEndpoint: t.Xa,
                            identityPlatformEndpoint: t.Ua
                        };
                    return null
                }

                function y(t) {
                    if (!t) return !1;
                    try {
                        return !!t.$goog_Thenable
                    } catch (t) {
                        return !1
                    }
                }

                function b(t) {
                    if (Error.captureStackTrace) Error.captureStackTrace(this, b);
                    else {
                        var e = Error().stack;
                        e && (this.stack = e)
                    }
                    t && (this.message = t + "")
                }

                function w(t, e) {
                    t = t.split("%s");
                    for (var n = "", i = t.length - 1, o = 0; i > o; o++) n += t[o] + (e.length > o ? e[o] : "%s");
                    b.call(this, n + t[i])
                }

                function _(t) {
                    throw new w("Failure" + (t ? ": " + t : ""), Array.prototype.slice.call(arguments, 1))
                }

                function S(t, e) {
                    this.c = t, this.f = e, this.b = 0, this.a = null
                }

                function I(t, e) {
                    t.f(e), 100 > t.b && (t.b++, e.next = t.a, t.a = e)
                }

                function T() {
                    this.b = this.a = null
                }

                function N() {
                    var t = Cl,
                        e = null;
                    return t.a && (e = t.a, t.a = t.a.next, t.a || (t.b = null), e.next = null), e
                }

                function k() {
                    this.next = this.b = this.a = null
                }

                function E(t, e) {
                    for (var n = "string" == typeof t ? t.split("") : t, i = t.length - 1; i >= 0; --i) i in n && e.call(void 0, n[i], i, t)
                }

                function C(t) {
                    t: {
                        for (var e = ho, n = t.length, i = "string" == typeof t ? t.split("") : t, o = 0; n > o; o++)
                            if (o in i && e.call(void 0, i[o], o, t)) {
                                e = o;
                                break t
                            } e = -1
                    }
                    return 0 > e ? null : "string" == typeof t ? t.charAt(e) : t[e]
                }

                function A(t, e) {
                    return Rc(t, e) >= 0
                }

                function O(t, e) {
                    e = Rc(t, e);
                    var n;
                    return (n = e >= 0) && Array.prototype.splice.call(t, e, 1), n
                }

                function P(t, e) {
                    var n = 0;
                    E(t, function(i, o) {
                        e.call(void 0, i, o, t) && 1 == Array.prototype.splice.call(t, o, 1).length && n++
                    })
                }

                function x() {
                    return Array.prototype.concat.apply([], arguments)
                }

                function M(t) {
                    var e = t.length;
                    if (e > 0) {
                        for (var n = Array(e), i = 0; e > i; i++) n[i] = t[i];
                        return n
                    }
                    return []
                }

                function L(t, e) {
                    return -1 != t.indexOf(e)
                }

                function j(t, e) {
                    return e > t ? -1 : t > e ? 1 : 0
                }

                function D(t) {
                    return L(Dc, t)
                }

                function R(t, e) {
                    for (var n in t) e.call(void 0, t[n], n, t)
                }

                function U(t) {
                    for (var e in t) return !1;
                    return !0
                }

                function V(t) {
                    var e, n = {};
                    for (e in t) n[e] = t[e];
                    return n
                }

                function F(t) {
                    for (var e, n, i = 1; arguments.length > i; i++) {
                        n = arguments[i];
                        for (e in n) t[e] = n[e];
                        for (var o = 0; Zc.length > o; o++) e = Zc[o], Object.prototype.hasOwnProperty.call(n, e) && (t[e] = n[e])
                    }
                }

                function B(t, e) {
                    t: {
                        try {
                            var n = t && t.ownerDocument,
                                i = n && (n.defaultView || n.parentWindow);
                            if (i = i || Nc, i.Element && i.Location) {
                                var o = i;
                                break t
                            }
                        } catch (t) {}
                        o = null
                    }
                    if (o && void 0 !== o[e] && (!t || !(t instanceof o[e]) && (t instanceof o.Location || t instanceof o.Element))) {
                        if (u(t)) try {
                            var r = t.constructor.displayName || t.constructor.name || Object.prototype.toString.call(t)
                        } catch (t) {
                            r = "<object could not be stringified>"
                        } else r = void 0 === t ? "undefined" : null === t ? "null" : typeof t;
                        _("Argument is not a %s (or a non-Element, non-Location mock); got: %s", e, r)
                    }
                }

                function H(t, e) {
                    this.a = t === tl && e || "", this.b = Qc
                }

                function G(t) {
                    return t instanceof H && t.constructor === H && t.b === Qc ? t.a : (_("expected object of type Const, got '" + t + "'"), "type_error:Const")
                }

                function W(t, e) {
                    this.a = t === rl && e || "", this.b = ol
                }

                function K(t) {
                    return t instanceof W && t.constructor === W && t.b === ol ? t.a : (_("expected object of type TrustedResourceUrl, got '" + t + "' of type " + r(t)), "type_error:TrustedResourceUrl")
                }

                function q(t, e) {
                    var n = G(t);
                    if (!il.test(n)) throw Error("Invalid TrustedResourceUrl format: " + n);
                    return t = n.replace(nl, function(t, i) {
                        if (!Object.prototype.hasOwnProperty.call(e, i)) throw Error('Found marker, "' + i + '", in format string, "' + n + '", but no valid label mapping found in args: ' + JSON.stringify(e));
                        return t = e[i], t instanceof H ? G(t) : encodeURIComponent(t + "")
                    }), new W(rl, t)
                }

                function z(t, e) {
                    this.a = t === ul && e || "", this.b = sl
                }

                function X(t) {
                    return t instanceof z && t.constructor === z && t.b === sl ? t.a : (_("expected object of type SafeUrl, got '" + t + "' of type " + r(t)), "type_error:SafeUrl")
                }

                function J(t) {
                    return t instanceof z ? t : (t = "object" == typeof t && t.ra ? t.qa() : t + "", al.test(t) || (t = "about:invalid#zClosurez"), new z(ul, t))
                }

                function Y() {
                    this.a = "", this.b = cl
                }

                function $(t) {
                    return t instanceof Y && t.constructor === Y && t.b === cl ? t.a : (_("expected object of type SafeHtml, got '" + t + "' of type " + r(t)), "type_error:SafeHtml")
                }

                function Z(t) {
                    var e = new Y;
                    return e.a = t, e
                }

                function Q(t) {
                    var e = new W(rl, G(el));
                    B(t, "HTMLIFrameElement"), t.src = "" + K(e)
                }

                function tt(t, e) {
                    B(t, "HTMLScriptElement"), t.src = K(e), null === Ec && (e = Nc.document, Ec = (e = e.querySelector && e.querySelector("script[nonce]")) && (e = e.nonce || e.getAttribute("nonce")) && kc.test(e) ? e : ""), (e = Ec) && t.setAttribute("nonce", e)
                }

                function et(t) {
                    for (var e = t.split("%s"), n = "", i = Array.prototype.slice.call(arguments, 1); i.length && e.length > 1;) n += e.shift() + i.shift();
                    return n + e.join("%s")
                }

                function nt(t) {
                    return Jc.test(t) && (-1 != t.indexOf("&") && (t = t.replace(Gc, "&amp;")), -1 != t.indexOf("<") && (t = t.replace(Wc, "&lt;")), -1 != t.indexOf(">") && (t = t.replace(Kc, "&gt;")), -1 != t.indexOf('"') && (t = t.replace(qc, "&quot;")), -1 != t.indexOf("'") && (t = t.replace(zc, "&#39;")), -1 != t.indexOf("\0") && (t = t.replace(Xc, "&#0;"))), t
                }

                function it(t) {
                    return it[" "](t), t
                }

                function ot(t, e) {
                    var n = Sl;
                    return Object.prototype.hasOwnProperty.call(n, t) ? n[t] : n[t] = e(t)
                }

                function rt() {
                    var t = Nc.document;
                    return t ? t.documentMode : void 0
                }

                function at(t) {
                    return ot(t, function() {
                        for (var e = 0, n = Hc(hl + "").split("."), i = Hc(t + "").split("."), o = Math.max(n.length, i.length), r = 0; 0 == e && o > r; r++) {
                            var a = n[r] || "",
                                s = i[r] || "";
                            do {
                                if (a = /(\d*)(\D*)(.*)/.exec(a) || ["", "", "", ""], s = /(\d*)(\D*)(.*)/.exec(s) || ["", "", "", ""], 0 == a[0].length && 0 == s[0].length) break;
                                e = j(0 == a[1].length ? 0 : parseInt(a[1], 10), 0 == s[1].length ? 0 : parseInt(s[1], 10)) || j(0 == a[2].length, 0 == s[2].length) || j(a[2], s[2]), a = a[3], s = s[3]
                            } while (0 == e)
                        }
                        return e >= 0
                    })
                }

                function st(t) {
                    var e = document;
                    return "string" == typeof t ? e.getElementById(t) : t
                }

                function ut(t, e) {
                    R(e, function(e, n) {
                        e && "object" == typeof e && e.ra && (e = e.qa()), "style" == n ? t.style.cssText = e : "class" == n ? t.className = e : "for" == n ? t.htmlFor = e : kl.hasOwnProperty(n) ? t.setAttribute(kl[n], e) : 0 == n.lastIndexOf("aria-", 0) || 0 == n.lastIndexOf("data-", 0) ? t.setAttribute(n, e) : t[n] = e
                    })
                }

                function ct() {
                    var t = arguments,
                        e = document,
                        n = t[0] + "",
                        i = t[1];
                    if (!Nl && i && (i.name || i.type)) {
                        if (n = ["<", n], i.name && n.push(' name="', nt(i.name), '"'), i.type) {
                            n.push(' type="', nt(i.type), '"');
                            var o = {};
                            F(o, i), delete o.type, i = o
                        }
                        n.push(">"), n = n.join("")
                    }
                    return n = ht(e, n), i && ("string" == typeof i ? n.className = i : Array.isArray(i) ? n.className = i.join(" ") : ut(n, i)), t.length > 2 && lt(e, n, t), n
                }

                function lt(t, e, n) {
                    function i(n) {
                        n && e.appendChild("string" == typeof n ? t.createTextNode(n) : n)
                    }
                    for (var o = 2; n.length > o; o++) {
                        var r = n[o];
                        !a(r) || u(r) && r.nodeType > 0 ? i(r) : Uc(ft(r) ? M(r) : r, i)
                    }
                }

                function ht(t, e) {
                    return e += "", "application/xhtml+xml" === t.contentType && (e = e.toLowerCase()), t.createElement(e)
                }

                function ft(t) {
                    if (t && "number" == typeof t.length) {
                        if (u(t)) return "function" == typeof t.item || "string" == typeof t.item;
                        if (s(t)) return "function" == typeof t.item
                    }
                    return !1
                }

                function pt(t) {
                    Nc.setTimeout(function() {
                        throw t
                    }, 0)
                }

                function dt() {
                    var t = Nc.MessageChannel;
                    if (void 0 === t && "undefined" != typeof window && window.postMessage && window.addEventListener && !D("Presto") && (t = function() {
                            var t = ht(document, "IFRAME");
                            t.style.display = "none", Q(t), document.documentElement.appendChild(t);
                            var e = t.contentWindow;
                            t = e.document, t.open(), t.write($(ll)), t.close();
                            var n = "callImmediate" + Math.random(),
                                i = "file:" == e.location.protocol ? "*" : e.location.protocol + "//" + e.location.host;
                            t = f(function(t) {
                                "*" != i && t.origin != i || t.data != n || this.port1.onmessage()
                            }, this), e.addEventListener("message", t, !1), this.port1 = {}, this.port2 = {
                                postMessage: function() {
                                    e.postMessage(n, i)
                                }
                            }
                        }), void 0 !== t && !D("Trident") && !D("MSIE")) {
                        var e = new t,
                            n = {},
                            i = n;
                        return e.port1.onmessage = function() {
                                if (void 0 !== n.next) {
                                    n = n.next;
                                    var t = n.Db;
                                    n.Db = null, t()
                                }
                            },
                            function(t) {
                                i.next = {
                                    Db: t
                                }, i = i.next, e.port2.postMessage(0)
                            }
                    }
                    return function(t) {
                        Nc.setTimeout(t, 0)
                    }
                }

                function mt(t, e) {
                    Tl || vt(), El || (Tl(), El = !0), Cl.add(t, e)
                }

                function vt() {
                    if (Nc.Promise && Nc.Promise.resolve) {
                        var t = Nc.Promise.resolve(void 0);
                        Tl = function() {
                            t.then(gt)
                        }
                    } else Tl = function() {
                        var t = gt;
                        !s(Nc.setImmediate) || Nc.Window && Nc.Window.prototype && !D("Edge") && Nc.Window.prototype.setImmediate == Nc.setImmediate ? (Il || (Il = dt()), Il(t)) : Nc.setImmediate(t)
                    }
                }

                function gt() {
                    for (var t; t = N();) {
                        try {
                            t.a.call(t.b)
                        } catch (t) {
                            pt(t)
                        }
                        I(jc, t)
                    }
                    El = !1
                }

                function yt(t, e) {
                    if (this.a = Al, this.i = void 0, this.f = this.b = this.c = null, this.g = this.h = !1, t != o) try {
                        var n = this;
                        t.call(e, function(t) {
                            At(n, Ol, t)
                        }, function(t) {
                            if (!(t instanceof Rt)) try {
                                if (t instanceof Error) throw t;
                                throw Error("Promise rejected.")
                            } catch (t) {}
                            At(n, Pl, t)
                        })
                    } catch (t) {
                        At(this, Pl, t)
                    }
                }

                function bt() {
                    this.next = this.f = this.b = this.g = this.a = null, this.c = !1
                }

                function wt(t, e, n) {
                    var i = xl.get();
                    return i.g = t, i.b = e, i.f = n, i
                }

                function _t(t) {
                    if (t instanceof yt) return t;
                    var e = new yt(o);
                    return At(e, Ol, t), e
                }

                function St(t) {
                    return new yt(function(e, n) {
                        n(t)
                    })
                }

                function It(t, e, n) {
                    Ot(t, e, n, null) || mt(p(e, t))
                }

                function Tt(t) {
                    return new yt(function(e, n) {
                        var i = t.length,
                            o = [];
                        if (i)
                            for (var r, a = function(t, n) {
                                    i--, o[t] = n, 0 == i && e(o)
                                }, s = function(t) {
                                    n(t)
                                }, u = 0; t.length > u; u++) r = t[u], It(r, p(a, u), s);
                        else e(o)
                    })
                }

                function Nt(t) {
                    return new yt(function(e) {
                        var n = t.length,
                            i = [];
                        if (n)
                            for (var o, r = function(t, o, r) {
                                    n--, i[t] = o ? {
                                        Mb: !0,
                                        value: r
                                    } : {
                                        Mb: !1,
                                        reason: r
                                    }, 0 == n && e(i)
                                }, a = 0; t.length > a; a++) o = t[a], It(o, p(r, a, !0), p(r, a, !1));
                        else e(i)
                    })
                }

                function kt(t, e) {
                    if (t.a == Al)
                        if (t.c) {
                            var n = t.c;
                            if (n.b) {
                                for (var i = 0, o = null, r = null, a = n.b; a && (a.c || (i++, a.a == t && (o = a), !(o && i > 1))); a = a.next) o || (r = a);
                                o && (n.a == Al && 1 == i ? kt(n, e) : (r ? (i = r, i.next == n.f && (n.f = i), i.next = i.next.next) : Mt(n), Lt(n, o, Pl, e)))
                            }
                            t.c = null
                        } else At(t, Pl, e)
                }

                function Et(t, e) {
                    t.b || t.a != Ol && t.a != Pl || xt(t), t.f ? t.f.next = e : t.b = e, t.f = e
                }

                function Ct(t, e, n, i) {
                    var o = wt(null, null, null);
                    return o.a = new yt(function(t, r) {
                        o.g = e ? function(n) {
                            try {
                                var o = e.call(i, n);
                                t(o)
                            } catch (t) {
                                r(t)
                            }
                        } : t, o.b = n ? function(e) {
                            try {
                                var o = n.call(i, e);
                                void 0 === o && e instanceof Rt ? r(e) : t(o)
                            } catch (t) {
                                r(t)
                            }
                        } : r
                    }), o.a.c = t, Et(t, o), o.a
                }

                function At(t, e, n) {
                    t.a == Al && (t === n && (e = Pl, n = new TypeError("Promise cannot resolve to itself")), t.a = 1, Ot(n, t.Yc, t.Zc, t) || (t.i = n, t.a = e, t.c = null, xt(t), e != Pl || n instanceof Rt || Dt(t, n)))
                }

                function Ot(t, e, n, i) {
                    if (t instanceof yt) return Et(t, wt(e || o, n || null, i)), !0;
                    if (y(t)) return t.then(e, n, i), !0;
                    if (u(t)) try {
                        var r = t.then;
                        if (s(r)) return Pt(t, r, e, n, i), !0
                    } catch (t) {
                        return n.call(i, t), !0
                    }
                    return !1
                }

                function Pt(t, e, n, i, o) {
                    function r(t) {
                        s || (s = !0, i.call(o, t))
                    }

                    function a(t) {
                        s || (s = !0, n.call(o, t))
                    }
                    var s = !1;
                    try {
                        e.call(t, a, r)
                    } catch (t) {
                        r(t)
                    }
                }

                function xt(t) {
                    t.h || (t.h = !0, mt(t.ec, t))
                }

                function Mt(t) {
                    var e = null;
                    return t.b && (e = t.b, t.b = e.next, e.next = null), t.b || (t.f = null), e
                }

                function Lt(t, e, n, i) {
                    if (n == Pl && e.b && !e.c)
                        for (; t && t.g; t = t.c) t.g = !1;
                    if (e.a) e.a.c = null, jt(e, n, i);
                    else try {
                        e.c ? e.g.call(e.f) : jt(e, n, i)
                    } catch (t) {
                        Ml.call(null, t)
                    }
                    I(xl, e)
                }

                function jt(t, e, n) {
                    e == Ol ? t.g.call(t.f, n) : t.b && t.b.call(t.f, n)
                }

                function Dt(t, e) {
                    t.g = !0, mt(function() {
                        t.g && Ml.call(null, e)
                    })
                }

                function Rt(t) {
                    b.call(this, t)
                }

                function Ut() {
                    0 != Ll && (jl[c(this)] = this), this.wa = this.wa, this.na = this.na
                }

                function Vt(t) {
                    if (!t.wa && (t.wa = !0, t.Ba(), 0 != Ll)) {
                        var e = c(t);
                        if (0 != Ll && t.na && t.na.length > 0) throw Error(t + " did not empty its onDisposeCallbacks queue. This probably means it overrode dispose() or disposeInternal() without calling the superclass' method.");
                        delete jl[e]
                    }
                }

                function Ft(t, e) {
                    this.type = t, this.b = this.target = e, this.defaultPrevented = !1
                }

                function Bt(t, e) {
                    if (Ft.call(this, t ? t.type : ""), this.relatedTarget = this.b = this.target = null, this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0, this.key = "", this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1, this.pointerId = 0, this.pointerType = "", this.a = null, t) {
                        var n = this.type = t.type,
                            i = t.changedTouches && t.changedTouches.length ? t.changedTouches[0] : null;
                        if (this.target = t.target || t.srcElement, this.b = e, e = t.relatedTarget) {
                            if (vl) {
                                t: {
                                    try {
                                        it(e.nodeName);
                                        var o = !0;
                                        break t
                                    } catch (t) {}
                                    o = !1
                                }
                                o || (e = null)
                            }
                        } else "mouseover" == n ? e = t.fromElement : "mouseout" == n && (e = t.toElement);
                        this.relatedTarget = e, i ? (this.clientX = void 0 !== i.clientX ? i.clientX : i.pageX, this.clientY = void 0 !== i.clientY ? i.clientY : i.pageY, this.screenX = i.screenX || 0, this.screenY = i.screenY || 0) : (this.clientX = void 0 !== t.clientX ? t.clientX : t.pageX, this.clientY = void 0 !== t.clientY ? t.clientY : t.pageY, this.screenX = t.screenX || 0, this.screenY = t.screenY || 0), this.button = t.button, this.key = t.key || "", this.ctrlKey = t.ctrlKey, this.altKey = t.altKey, this.shiftKey = t.shiftKey, this.metaKey = t.metaKey, this.pointerId = t.pointerId || 0, this.pointerType = "string" == typeof t.pointerType ? t.pointerType : Fl[t.pointerType] || "", this.a = t, t.defaultPrevented && this.preventDefault()
                    }
                }

                function Ht(t, e, n, i, o) {
                    this.listener = t, this.proxy = null, this.src = e, this.type = n, this.capture = !!i, this.Ta = o, this.key = ++Hl, this.ua = this.Na = !1
                }

                function Gt(t) {
                    t.ua = !0, t.listener = null, t.proxy = null, t.src = null, t.Ta = null
                }

                function Wt(t) {
                    this.src = t, this.a = {}, this.b = 0
                }

                function Kt(t, e) {
                    var n = e.type;
                    n in t.a && O(t.a[n], e) && (Gt(e), 0 == t.a[n].length && (delete t.a[n], t.b--))
                }

                function qt(t, e, n, i) {
                    for (var o = 0; t.length > o; ++o) {
                        var r = t[o];
                        if (!r.ua && r.listener == e && r.capture == !!n && r.Ta == i) return o
                    }
                    return -1
                }

                function zt(t, e, n, i, o) {
                    if (i && i.once) Yt(t, e, n, i, o);
                    else if (Array.isArray(e))
                        for (var r = 0; e.length > r; r++) zt(t, e[r], n, i, o);
                    else n = oe(n), t && t[Bl] ? ae(t, e, n, u(i) ? !!i.capture : !!i, o) : Xt(t, e, n, !1, i, o)
                }

                function Xt(t, e, n, i, o, r) {
                    if (!e) throw Error("Invalid event type");
                    var a = u(o) ? !!o.capture : !!o,
                        s = ie(t);
                    if (s || (t[Gl] = s = new Wt(t)), n = s.add(e, n, i, a, r), !n.proxy) {
                        if (i = Jt(), n.proxy = i, i.src = t, i.listener = n, t.addEventListener) Vl || (o = a), void 0 === o && (o = !1), t.addEventListener("" + e, i, o);
                        else if (t.attachEvent) t.attachEvent(Qt("" + e), i);
                        else {
                            if (!t.addListener || !t.removeListener) throw Error("addEventListener and attachEvent are unavailable.");
                            t.addListener(i)
                        }
                        Kl++
                    }
                }

                function Jt() {
                    var t = ne,
                        e = Rl ? function(n) {
                            return t.call(e.src, e.listener, n)
                        } : function(n) {
                            if (!(n = t.call(e.src, e.listener, n))) return n
                        };
                    return e
                }

                function Yt(t, e, n, i, o) {
                    if (Array.isArray(e))
                        for (var r = 0; e.length > r; r++) Yt(t, e[r], n, i, o);
                    else n = oe(n), t && t[Bl] ? se(t, e, n, u(i) ? !!i.capture : !!i, o) : Xt(t, e, n, !0, i, o)
                }

                function $t(t, e, n, i, o) {
                    if (Array.isArray(e))
                        for (var r = 0; e.length > r; r++) $t(t, e[r], n, i, o);
                    else i = u(i) ? !!i.capture : !!i, n = oe(n), t && t[Bl] ? (t = t.u, (e += "") in t.a && (r = t.a[e], (n = qt(r, n, i, o)) > -1 && (Gt(r[n]), Array.prototype.splice.call(r, n, 1), 0 == r.length && (delete t.a[e], t.b--)))) : t && (t = ie(t)) && (e = t.a["" + e], t = -1, e && (t = qt(e, n, i, o)), (n = t > -1 ? e[t] : null) && Zt(n))
                }

                function Zt(t) {
                    if ("number" != typeof t && t && !t.ua) {
                        var e = t.src;
                        if (e && e[Bl]) Kt(e.u, t);
                        else {
                            var n = t.type,
                                i = t.proxy;
                            e.removeEventListener ? e.removeEventListener(n, i, t.capture) : e.detachEvent ? e.detachEvent(Qt(n), i) : e.addListener && e.removeListener && e.removeListener(i), Kl--, (n = ie(e)) ? (Kt(n, t), 0 == n.b && (n.src = null, e[Gl] = null)) : Gt(t)
                        }
                    }
                }

                function Qt(t) {
                    return t in Wl ? Wl[t] : Wl[t] = "on" + t
                }

                function te(t, e, n, i) {
                    var o = !0;
                    if ((t = ie(t)) && (e = t.a["" + e]))
                        for (e = e.concat(), t = 0; e.length > t; t++) {
                            var r = e[t];
                            r && r.capture == n && !r.ua && (r = ee(r, i), o = o && !1 !== r)
                        }
                    return o
                }

                function ee(t, e) {
                    var n = t.listener,
                        i = t.Ta || t.src;
                    return t.Na && Zt(t), n.call(i, e)
                }

                function ne(t, e) {
                    if (t.ua) return !0;
                    if (!Rl) {
                        if (!e) t: {
                            e = ["window", "event"];
                            for (var n = Nc, i = 0; e.length > i; i++)
                                if (null == (n = n[e[i]])) {
                                    e = null;
                                    break t
                                } e = n
                        }
                        if (i = e, e = new Bt(i, this), n = !0, i.keyCode >= 0 && void 0 == i.returnValue) {
                            t: {
                                var o = !1;
                                if (0 == i.keyCode) try {
                                    i.keyCode = -1;
                                    break t
                                } catch (t) {
                                    o = !0
                                }(o || void 0 == i.returnValue) && (i.returnValue = !0)
                            }
                            for (i = [], o = e.b; o; o = o.parentNode) i.push(o);
                            for (t = t.type, o = i.length - 1; o >= 0; o--) {
                                e.b = i[o];
                                var r = te(i[o], t, !0, e);
                                n = n && r
                            }
                            for (o = 0; i.length > o; o++) e.b = i[o],
                            r = te(i[o], t, !1, e),
                            n = n && r
                        }
                        return n
                    }
                    return ee(t, new Bt(e, this))
                }

                function ie(t) {
                    return t = t[Gl], t instanceof Wt ? t : null
                }

                function oe(t) {
                    return s(t) ? t : (t[ql] || (t[ql] = function(e) {
                        return t.handleEvent(e)
                    }), t[ql])
                }

                function re() {
                    Ut.call(this), this.u = new Wt(this), this.Yb = this, this.eb = null
                }

                function ae(t, e, n, i, o) {
                    t.u.add(e + "", n, !1, i, o)
                }

                function se(t, e, n, i, o) {
                    t.u.add(e + "", n, !0, i, o)
                }

                function ue(t, e, n, i) {
                    if (!(e = t.u.a[e + ""])) return !0;
                    e = e.concat();
                    for (var o = !0, r = 0; e.length > r; ++r) {
                        var a = e[r];
                        if (a && !a.ua && a.capture == n) {
                            var s = a.listener,
                                u = a.Ta || a.src;
                            a.Na && Kt(t.u, a), o = !1 !== s.call(u, i) && o
                        }
                    }
                    return o && !i.defaultPrevented
                }

                function ce(t, e, n) {
                    if (s(t)) n && (t = f(t, n));
                    else {
                        if (!t || "function" != typeof t.handleEvent) throw Error("Invalid listener argument");
                        t = f(t.handleEvent, t)
                    }
                    return +e > 2147483647 ? -1 : Nc.setTimeout(t, e || 0)
                }

                function le(t) {
                    var e = null;
                    return new yt(function(n, i) {
                        -1 == (e = ce(function() {
                            n(void 0)
                        }, t)) && i(Error("Failed to schedule timer."))
                    }).o(function(t) {
                        throw Nc.clearTimeout(e), t
                    })
                }

                function he(t) {
                    if (t.V && "function" == typeof t.V) return t.V();
                    if ("string" == typeof t) return t.split("");
                    if (a(t)) {
                        for (var e = [], n = t.length, i = 0; n > i; i++) e.push(t[i]);
                        return e
                    }
                    e = [], n = 0;
                    for (i in t) e[n++] = t[i];
                    return e
                }

                function fe(t) {
                    if (t.X && "function" == typeof t.X) return t.X();
                    if (!t.V || "function" != typeof t.V) {
                        if (a(t) || "string" == typeof t) {
                            var e = [];
                            t = t.length;
                            for (var n = 0; t > n; n++) e.push(n);
                            return e
                        }
                        e = [], n = 0;
                        for (var i in t) e[n++] = i;
                        return e
                    }
                }

                function pe(t, e) {
                    if (t.forEach && "function" == typeof t.forEach) t.forEach(e, void 0);
                    else if (a(t) || "string" == typeof t) Uc(t, e, void 0);
                    else
                        for (var n = fe(t), i = he(t), o = i.length, r = 0; o > r; r++) e.call(void 0, i[r], n && n[r], t)
                }

                function de(t) {
                    this.b = {}, this.a = [], this.c = 0;
                    var e = arguments.length;
                    if (e > 1) {
                        if (e % 2) throw Error("Uneven number of arguments");
                        for (var n = 0; e > n; n += 2) this.set(arguments[n], arguments[n + 1])
                    } else if (t)
                        if (t instanceof de)
                            for (e = t.X(), n = 0; e.length > n; n++) this.set(e[n], t.get(e[n]));
                        else
                            for (n in t) this.set(n, t[n])
                }

                function me(t) {
                    if (t.c != t.a.length) {
                        for (var e = 0, n = 0; t.a.length > e;) {
                            var i = t.a[e];
                            ve(t.b, i) && (t.a[n++] = i), e++
                        }
                        t.a.length = n
                    }
                    if (t.c != t.a.length) {
                        var o = {};
                        for (n = e = 0; t.a.length > e;) i = t.a[e], ve(o, i) || (t.a[n++] = i, o[i] = 1), e++;
                        t.a.length = n
                    }
                }

                function ve(t, e) {
                    return Object.prototype.hasOwnProperty.call(t, e)
                }

                function ge(t, e) {
                    if (t) {
                        t = t.split("&");
                        for (var n = 0; t.length > n; n++) {
                            var i = t[n].indexOf("="),
                                o = null;
                            if (i < 0) r = t[n];
                            else {
                                var r = t[n].substring(0, i);
                                o = t[n].substring(i + 1)
                            }
                            e(r, o ? decodeURIComponent(o.replace(/\+/g, " ")) : "")
                        }
                    }
                }

                function ye(t, e) {
                    this.b = this.i = this.f = "", this.l = null, this.g = this.c = "", this.h = !1;
                    var n;
                    t instanceof ye ? (this.h = void 0 !== e ? e : t.h, be(this, t.f), this.i = t.i, this.b = t.b, we(this, t.l), this.c = t.c, _e(this, je(t.a)), this.g = t.g) : t && (n = (t + "").match(zl)) ? (this.h = !!e, be(this, n[1] || "", !0), this.i = ke(n[2] || ""), this.b = ke(n[3] || "", !0), we(this, n[4]), this.c = ke(n[5] || "", !0), _e(this, n[6] || "", !0), this.g = ke(n[7] || "")) : (this.h = !!e, this.a = new Ae(null, this.h))
                }

                function be(t, e, n) {
                    (t.f = n ? ke(e, !0) : e) && (t.f = t.f.replace(/:$/, ""))
                }

                function we(t, e) {
                    if (e) {
                        if (e = +e, isNaN(e) || 0 > e) throw Error("Bad port number " + e);
                        t.l = e
                    } else t.l = null
                }

                function _e(t, e, n) {
                    e instanceof Ae ? (t.a = e, Re(t.a, t.h)) : (n || (e = Ee(e, $l)), t.a = new Ae(e, t.h))
                }

                function Se(t, e, n) {
                    t.a.set(e, n)
                }

                function Ie(t, e) {
                    return t.a.get(e)
                }

                function Te(t) {
                    return t instanceof ye ? new ye(t) : new ye(t, void 0)
                }

                function Ne(t, e) {
                    var n = new ye(null, void 0);
                    return be(n, "https"), t && (n.b = t), e && (n.c = e), n
                }

                function ke(t, e) {
                    return t ? e ? decodeURI(t.replace(/%25/g, "%2525")) : decodeURIComponent(t) : ""
                }

                function Ee(t, e, n) {
                    return "string" == typeof t ? (t = encodeURI(t).replace(e, Ce), n && (t = t.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), t) : null
                }

                function Ce(t) {
                    return t = t.charCodeAt(0), "%" + (t >> 4 & 15).toString(16) + (15 & t).toString(16)
                }

                function Ae(t, e) {
                    this.b = this.a = null, this.c = t || null, this.f = !!e
                }

                function Oe(t) {
                    t.a || (t.a = new de, t.b = 0, t.c && ge(t.c, function(e, n) {
                        t.add(decodeURIComponent(e.replace(/\+/g, " ")), n)
                    }))
                }

                function Pe(t) {
                    var e = fe(t);
                    if (void 0 === e) throw Error("Keys are undefined");
                    var n = new Ae(null, void 0);
                    t = he(t);
                    for (var i = 0; e.length > i; i++) {
                        var o = e[i],
                            r = t[i];
                        Array.isArray(r) ? Le(n, o, r) : n.add(o, r)
                    }
                    return n
                }

                function xe(t, e) {
                    Oe(t), e = De(t, e), ve(t.a.b, e) && (t.c = null, t.b -= t.a.get(e).length, t = t.a, ve(t.b, e) && (delete t.b[e], t.c--, t.a.length > 2 * t.c && me(t)))
                }

                function Me(t, e) {
                    return Oe(t), e = De(t, e), ve(t.a.b, e)
                }

                function Le(t, e, n) {
                    xe(t, e), n.length > 0 && (t.c = null, t.a.set(De(t, e), M(n)), t.b += n.length)
                }

                function je(t) {
                    var e = new Ae;
                    return e.c = t.c, t.a && (e.a = new de(t.a), e.b = t.b), e
                }

                function De(t, e) {
                    return e += "", t.f && (e = e.toLowerCase()), e
                }

                function Re(t, e) {
                    e && !t.f && (Oe(t), t.c = null, t.a.forEach(function(t, e) {
                        var n = e.toLowerCase();
                        e != n && (xe(this, e), Le(this, n, t))
                    }, t)), t.f = e
                }

                function Ue(t) {
                    var e = [];
                    return Fe(new Ve, t, e), e.join("")
                }

                function Ve() {}

                function Fe(t, e, n) {
                    if (null == e) n.push("null");
                    else {
                        if ("object" == typeof e) {
                            if (Array.isArray(e)) {
                                var i = e;
                                e = i.length, n.push("[");
                                for (var o = "", r = 0; e > r; r++) n.push(o), Fe(t, i[r], n), o = ",";
                                return void n.push("]")
                            }
                            if (!(e instanceof String || e instanceof Number || e instanceof Boolean)) {
                                n.push("{"), o = "";
                                for (i in e) Object.prototype.hasOwnProperty.call(e, i) && "function" != typeof(r = e[i]) && (n.push(o), Be(i, n), n.push(":"), Fe(t, r, n), o = ",");
                                return void n.push("}")
                            }
                            e = e.valueOf()
                        }
                        switch (typeof e) {
                            case "string":
                                Be(e, n);
                                break;
                            case "number":
                                n.push(isFinite(e) && !isNaN(e) ? e + "" : "null");
                                break;
                            case "boolean":
                                n.push(e + "");
                                break;
                            case "function":
                                n.push("null");
                                break;
                            default:
                                throw Error("Unknown type: " + typeof e)
                        }
                    }
                }

                function Be(t, e) {
                    e.push('"', t.replace(th, function(t) {
                        var e = Ql[t];
                        return e || (e = "\\u" + (65536 | t.charCodeAt(0)).toString(16).substr(1), Ql[t] = e), e
                    }), '"')
                }

                function He() {
                    var t = un();
                    return pl && !!_l && 11 == _l || /Edge\/\d+/.test(t)
                }

                function Ge() {
                    return Nc.window && Nc.window.location.href || self && self.location && self.location.href || ""
                }

                function We(t, e) {
                    e = e || Nc.window;
                    var n = "about:blank";
                    t && (n = X(J(t))), e.location.href = n
                }

                function Ke(t, e) {
                    var n, i = [];
                    for (n in t) n in e ? typeof t[n] != typeof e[n] ? i.push(n) : "object" == typeof t[n] && null != t[n] && null != e[n] ? Ke(t[n], e[n]).length > 0 && i.push(n) : t[n] !== e[n] && i.push(n) : i.push(n);
                    for (n in e) n in t || i.push(n);
                    return i
                }

                function qe() {
                    var t = un();
                    return (!(t = an(t) != oh ? null : (t = t.match(/\sChrome\/(\d+)/i)) && 2 == t.length ? parseInt(t[1], 10) : null) || t >= 30) && (!pl || !_l || _l > 9)
                }

                function ze(t) {
                    return t = (t || un()).toLowerCase(), !!(t.match(/android/) || t.match(/webos/) || t.match(/iphone|ipad|ipod/) || t.match(/blackberry/) || t.match(/windows phone/) || t.match(/iemobile/))
                }

                function Xe(t) {
                    t = t || Nc.window;
                    try {
                        t.close()
                    } catch (t) {}
                }

                function Je(t, e, n) {
                    var i = "" + Math.floor(1e9 * Math.random());
                    e = e || 500, n = n || 600;
                    var o = (window.screen.availHeight - n) / 2,
                        r = (window.screen.availWidth - e) / 2;
                    e = {
                        width: e,
                        height: n,
                        top: o > 0 ? o : 0,
                        left: r > 0 ? r : 0,
                        location: !0,
                        resizable: !0,
                        statusbar: !0,
                        toolbar: !1
                    }, n = un().toLowerCase(), i && (e.target = i, L(n, "crios/index.html") && (e.target = "_blank")), an(un()) == ih && (t = t || "http://localhost", e.scrollbars = !0), n = t || "", (t = e) || (t = {}), i = window, e = n instanceof z ? n : J(void 0 !== n.href ? n.href : n + ""), n = t.target || n.target, o = [];
                    for (a in t) switch (a) {
                        case "width":
                        case "height":
                        case "top":
                        case "left":
                            o.push(a + "=" + t[a]);
                            break;
                        case "target":
                        case "noopener":
                        case "noreferrer":
                            break;
                        default:
                            o.push(a + "=" + (t[a] ? 1 : 0))
                    }
                    var a = o.join(",");
                    if ((D("iPhone") && !D("iPod") && !D("iPad") || D("iPad") || D("iPod")) && i.navigator && i.navigator.standalone && n && "_self" != n ? (a = ht(document, "A"), B(a, "HTMLAnchorElement"), e instanceof z || e instanceof z || (e = "object" == typeof e && e.ra ? e.qa() : e + "", al.test(e) || (e = "about:invalid#zClosurez"), e = new z(ul, e)), a.href = X(e), a.setAttribute("target", n), t.noreferrer && a.setAttribute("rel", "noreferrer"), t = document.createEvent("MouseEvent"), t.initMouseEvent("click", !0, !0, i, 1), a.dispatchEvent(t), a = {}) : t.noreferrer ? (a = i.open("", n, a), t = X(e), a && (ml && L(t, ";") && (t = "'" + t.replace(/'/g, "%27") + "'"), a.opener = null, t = Z('<meta name="referrer" content="no-referrer"><meta http-equiv="refresh" content="0; url=' + nt(t) + '">'), i = a.document) && (i.write($(t)), i.close())) : (a = i.open(X(e), n, a)) && t.noopener && (a.opener = null), a) try {
                        a.focus()
                    } catch (t) {}
                    return a
                }

                function Ye(t) {
                    return new yt(function(e) {
                        function n() {
                            le(2e3).then(function() {
                                if (t && !t.closed) return n();
                                e()
                            })
                        }
                        return n()
                    })
                }

                function $e() {
                    var t = null;
                    return new yt(function(e) {
                        "complete" == Nc.document.readyState ? e() : (t = function() {
                            e()
                        }, Yt(window, "load", t))
                    }).o(function(e) {
                        throw $t(window, "load", t), e
                    })
                }

                function Ze() {
                    return Qe(void 0) ? $e().then(function() {
                        return new yt(function(t, e) {
                            var n = Nc.document,
                                i = setTimeout(function() {
                                    e(Error("Cordova framework is not ready."))
                                }, 1e3);
                            n.addEventListener("deviceready", function() {
                                clearTimeout(i), t()
                            }, !1)
                        })
                    }) : St(Error("Cordova must run in an Android or iOS file scheme."))
                }

                function Qe(t) {
                    return t = t || un(), !("file:" !== pn() && "ionic:" !== pn() || !t.toLowerCase().match(/iphone|ipad|ipod|android/))
                }

                function tn() {
                    var t = Nc.window;
                    try {
                        return !(!t || t == t.top)
                    } catch (t) {
                        return !1
                    }
                }

                function en() {
                    return void 0 !== Nc.WorkerGlobalScope && "function" == typeof Nc.importScripts
                }

                function nn() {
                    return i.a.INTERNAL.hasOwnProperty("reactNative") ? "ReactNative" : i.a.INTERNAL.hasOwnProperty("node") ? "Node" : en() ? "Worker" : "Browser"
                }

                function on() {
                    var t = nn();
                    return "ReactNative" === t || "Node" === t
                }

                function rn() {
                    for (var t = 50, e = []; t > 0;) e.push("1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(Math.floor(62 * Math.random()))), t--;
                    return e.join("")
                }

                function an(t) {
                    var e = t.toLowerCase();
                    return L(e, "opera/index.html") || L(e, "opr/index.html") || L(e, "opios/index.html") ? "Opera" : L(e, "iemobile") ? "IEMobile" : L(e, "msie") || L(e, "trident/index-2.html") ? "IE" : L(e, "edge/index.html") ? "Edge" : L(e, "firefox/index.html") ? ih : L(e, "silk/index.html") ? "Silk" : L(e, "blackberry") ? "Blackberry" : L(e, "webos") ? "Webos" : !L(e, "safari/index.html") || L(e, "chrome/index.html") || L(e, "crios/index.html") || L(e, "android") ? !L(e, "chrome/index.html") && !L(e, "crios/index.html") || L(e, "edge/index.html") ? L(e, "android") ? "Android" : (t = t.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/)) && 2 == t.length ? t[1] : "Other" : oh : "Safari"
                }

                function sn(t, e) {
                    e = e || [];
                    var n, i = [],
                        o = {};
                    for (n in rh) o[rh[n]] = !0;
                    for (n = 0; e.length > n; n++) void 0 !== o[e[n]] && (delete o[e[n]], i.push(e[n]));
                    return i.sort(), e = i, e.length || (e = ["FirebaseCore-web"]), i = nn(), "Browser" === i ? (o = un(), i = an(o)) : "Worker" === i && (o = un(), i = an(o) + "-" + i), i + "/JsCore/" + t + "/" + e.join(",")
                }

                function un() {
                    return Nc.navigator && Nc.navigator.userAgent || ""
                }

                function cn(t, e) {
                    t = t.split("."), e = e || Nc;
                    for (var n = 0; t.length > n && "object" == typeof e && null != e; n++) e = e[t[n]];
                    return n != t.length && (e = void 0), e
                }

                function ln() {
                    try {
                        var t = Nc.localStorage,
                            e = yn();
                        if (t) return t.setItem(e, "1"), t.removeItem(e), !He() || !!Nc.indexedDB
                    } catch (t) {
                        return en() && !!Nc.indexedDB
                    }
                    return !1
                }

                function hn() {
                    return (fn() || "chrome-extension:" === pn() || Qe()) && !on() && ln() && !en()
                }

                function fn() {
                    return "http:" === pn() || "https:" === pn()
                }

                function pn() {
                    return Nc.location && Nc.location.protocol || null
                }

                function dn(t) {
                    return t = t || un(), !ze(t) && an(t) != ih
                }

                function mn(t) {
                    return void 0 === t ? null : Ue(t)
                }

                function vn(t) {
                    var e, n = {};
                    for (e in t) t.hasOwnProperty(e) && null !== t[e] && void 0 !== t[e] && (n[e] = t[e]);
                    return n
                }

                function gn(t) {
                    if (null !== t) return JSON.parse(t)
                }

                function yn(t) {
                    return t || "" + Math.floor(1e9 * Math.random())
                }

                function bn(t) {
                    return t = t || un(), "Safari" != an(t) && !t.toLowerCase().match(/iphone|ipad|ipod/)
                }

                function wn() {
                    var t = Nc.___jsl;
                    if (t && t.H)
                        for (var e in t.H)
                            if (t.H[e].r = t.H[e].r || [], t.H[e].L = t.H[e].L || [], t.H[e].r = t.H[e].L.concat(), t.CP)
                                for (var n = 0; t.CP.length > n; n++) t.CP[n] = null
                }

                function _n(t, e) {
                    if (t > e) throw Error("Short delay should be less than long delay!");
                    this.a = t, this.c = e, t = un(), e = nn(), this.b = ze(t) || "ReactNative" === e
                }

                function Sn() {
                    var t = Nc.document;
                    return !t || void 0 === t.visibilityState || "visible" == t.visibilityState
                }

                function In() {
                    var t = Nc.document,
                        e = null;
                    return Sn() || !t ? _t() : new yt(function(n) {
                        e = function() {
                            Sn() && (t.removeEventListener("visibilitychange", e, !1), n())
                        }, t.addEventListener("visibilitychange", e, !1)
                    }).o(function(n) {
                        throw t.removeEventListener("visibilitychange", e, !1), n
                    })
                }

                function Tn(t) {
                    try {
                        var e = new Date(parseInt(t, 10));
                        if (!isNaN(e.getTime()) && !/[^0-9]/.test(t)) return e.toUTCString()
                    } catch (t) {}
                    return null
                }

                function Nn() {
                    return !(!cn("fireauth.oauthhelper", Nc) && !cn("fireauth.iframe", Nc))
                }

                function kn() {
                    var t = Nc.navigator;
                    return t && t.serviceWorker && t.serviceWorker.controller || null
                }

                function En() {
                    var t = Nc.navigator;
                    return t && t.serviceWorker ? _t().then(function() {
                        return t.serviceWorker.ready
                    }).then(function(t) {
                        return t.active || null
                    }).o(function() {
                        return null
                    }) : _t(null)
                }

                function Cn(t) {
                    sh[t] || (sh[t] = !0, "undefined" != typeof console && console)
                }

                function An(t, e, n) {
                    ah ? Object.defineProperty(t, e, {
                        configurable: !0,
                        enumerable: !0,
                        value: n
                    }) : t[e] = n
                }

                function On(t, e) {
                    if (e)
                        for (var n in e) e.hasOwnProperty(n) && An(t, n, e[n])
                }

                function Pn(t) {
                    var e = {};
                    return On(e, t), e
                }

                function xn(t) {
                    var e, n = {};
                    for (e in t) t.hasOwnProperty(e) && (n[e] = t[e]);
                    return n
                }

                function Mn(t, e) {
                    if (!e || !e.length) return !0;
                    if (!t) return !1;
                    for (var n = 0; e.length > n; n++) {
                        var i = t[e[n]];
                        if (void 0 === i || null === i || "" === i) return !1
                    }
                    return !0
                }

                function Ln(t) {
                    var e = t;
                    if ("object" == typeof t && null != t) {
                        e = "length" in t ? [] : {};
                        for (var n in t) An(e, n, Ln(t[n]))
                    }
                    return e
                }

                function jn(t) {
                    var e = t && (t[fh] ? "phone" : null);
                    if (!(e && t && t[hh])) throw new m("internal-error", "Internal assert: invalid MultiFactorInfo object");
                    An(this, "uid", t[hh]), An(this, "displayName", t[ch] || null);
                    var n = null;
                    t[lh] && (n = new Date(t[lh]).toUTCString()), An(this, "enrollmentTime", n), An(this, "factorId", e)
                }

                function Dn(t) {
                    try {
                        var e = new Rn(t)
                    } catch (t) {
                        e = null
                    }
                    return e
                }

                function Rn(t) {
                    jn.call(this, t), An(this, "phoneNumber", t[fh])
                }

                function Un(t) {
                    var e = {},
                        n = t[vh],
                        i = t[yh],
                        o = t[bh];
                    if (t = Dn(t[gh]), !o || o != dh && o != mh && !n || o == mh && !i || o == ph && !t) throw Error("Invalid checkActionCode response!");
                    o == mh ? (e[_h] = n || null, e[Ih] = n || null, e[wh] = i) : (e[_h] = i || null, e[Ih] = i || null, e[wh] = n || null), e[Sh] = t || null, An(this, Nh, o), An(this, Th, Ln(e))
                }

                function Vn(t) {
                    t = Te(t);
                    var e = Ie(t, kh) || null,
                        n = Ie(t, Eh) || null,
                        i = Ie(t, Oh) || null;
                    if (i = i ? xh[i] || null : null, !e || !n || !i) throw new m("argument-error", kh + ", " + Eh + "and " + Oh + " are required in a valid action code URL.");
                    On(this, {
                        apiKey: e,
                        operation: i,
                        code: n,
                        continueUrl: Ie(t, Ch) || null,
                        languageCode: Ie(t, Ah) || null,
                        tenantId: Ie(t, Ph) || null
                    })
                }

                function Fn(t) {
                    try {
                        return new Vn(t)
                    } catch (t) {
                        return null
                    }
                }

                function Bn(t) {
                    var e = t[Rh];
                    if (void 0 === e) throw new m("missing-continue-uri");
                    if ("string" != typeof e || "string" == typeof e && !e.length) throw new m("invalid-continue-uri");
                    this.h = e, this.b = this.a = null, this.g = !1;
                    var n = t[Mh];
                    if (n && "object" == typeof n) {
                        e = n[Fh];
                        var i = n[Uh];
                        if (n = n[Vh], "string" == typeof e && e.length) {
                            if (this.a = e, void 0 !== i && "boolean" != typeof i) throw new m("argument-error", Uh + " property must be a boolean when specified.");
                            if (this.g = !!i, void 0 !== n && ("string" != typeof n || "string" == typeof n && !n.length)) throw new m("argument-error", Vh + " property must be a non empty string when specified.");
                            this.b = n || null
                        } else {
                            if (void 0 !== e) throw new m("argument-error", Fh + " property must be a non empty string when specified.");
                            if (void 0 !== i || void 0 !== n) throw new m("missing-android-pkg-name")
                        }
                    } else if (void 0 !== n) throw new m("argument-error", Mh + " property must be a non null object when specified.");
                    if (this.f = null, (e = t[Dh]) && "object" == typeof e) {
                        if ("string" == typeof(e = e[Bh]) && e.length) this.f = e;
                        else if (void 0 !== e) throw new m("argument-error", Bh + " property must be a non empty string when specified.")
                    } else if (void 0 !== e) throw new m("argument-error", Dh + " property must be a non null object when specified.");
                    if (void 0 !== (e = t[jh]) && "boolean" != typeof e) throw new m("argument-error", jh + " property must be a boolean when specified.");
                    if (this.c = !!e, void 0 !== (t = t[Lh]) && ("string" != typeof t || "string" == typeof t && !t.length)) throw new m("argument-error", Lh + " property must be a non empty string when specified.");
                    this.i = t || null
                }

                function Hn(t) {
                    var e = {};
                    e.continueUrl = t.h, e.canHandleCodeInApp = t.c, (e.androidPackageName = t.a) && (e.androidMinimumVersion = t.b, e.androidInstallApp = t.g), e.iOSBundleId = t.f, e.dynamicLinkDomain = t.i;
                    for (var n in e) null === e[n] && delete e[n];
                    return e
                }

                function Gn(t) {
                    return Fc(t, function(t) {
                        return t = t.toString(16), t.length > 1 ? t : "0" + t
                    }).join("")
                }

                function Wn(t) {
                    var e = "";
                    return Kn(t, function(t) {
                        e += String.fromCharCode(t)
                    }), e
                }

                function Kn(t, e) {
                    function n(e) {
                        for (; t.length > i;) {
                            var n = t.charAt(i++),
                                o = Hh[n];
                            if (null != o) return o;
                            if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n)
                        }
                        return e
                    }
                    qn();
                    for (var i = 0;;) {
                        var o = n(-1),
                            r = n(0),
                            a = n(64),
                            s = n(64);
                        if (64 === s && -1 === o) break;
                        e(o << 2 | r >> 4), 64 != a && (e(r << 4 & 240 | a >> 2), 64 != s && e(a << 6 & 192 | s))
                    }
                }

                function qn() {
                    if (!Hh) {
                        Hh = {};
                        for (var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), e = ["+/=", "%2b/index.html", "-_=", "-_.", "-_"], n = 0; 5 > n; n++)
                            for (var i = t.concat(e[n].split("")), o = 0; i.length > o; o++) {
                                var r = i[o];
                                void 0 === Hh[r] && (Hh[r] = o)
                            }
                    }
                }

                function zn(t) {
                    var e = Jn(t);
                    if (!(e && e.sub && e.iss && e.aud && e.exp)) throw Error("Invalid JWT");
                    this.g = t, this.c = e.exp, this.h = e.sub, Oc(), this.a = e.provider_id || e.firebase && e.firebase.sign_in_provider || null, this.f = e.firebase && e.firebase.tenant || null, this.b = !!e.is_anonymous || "anonymous" == this.a
                }

                function Xn(t) {
                    try {
                        return new zn(t)
                    } catch (t) {
                        return null
                    }
                }

                function Jn(t) {
                    if (!t) return null;
                    if (t = t.split("."), 3 != t.length) return null;
                    t = t[1];
                    for (var e = (4 - t.length % 4) % 4, n = 0; e > n; n++) t += ".";
                    try {
                        return JSON.parse(Wn(t))
                    } catch (t) {}
                    return null
                }

                function Yn(t) {
                    for (var e in Kh)
                        if (Kh[e].ea == t) return Kh[e];
                    return null
                }

                function $n(t) {
                    var e = {};
                    e["facebook.com"] = ti, e["google.com"] = ni, e["github.com"] = ei, e["twitter.com"] = ii;
                    var n = t && t[zh];
                    try {
                        if (n) return e[n] ? new e[n](t) : new Qn(t);
                        if (void 0 !== t[qh]) return new Zn(t)
                    } catch (t) {}
                    return null
                }

                function Zn(t) {
                    var e = t[zh];
                    if (!e && t[qh]) {
                        var n = Xn(t[qh]);
                        n && n.a && (e = n.a)
                    }
                    if (!e) throw Error("Invalid additional user info!");
                    "anonymous" != e && "custom" != e || (e = null), n = !1, void 0 !== t.isNewUser ? n = !!t.isNewUser : "identitytoolkit#SignupNewUserResponse" === t.kind && (n = !0), An(this, "providerId", e), An(this, "isNewUser", n)
                }

                function Qn(t) {
                    Zn.call(this, t), t = gn(t.rawUserInfo || "{}"), An(this, "profile", Ln(t || {}))
                }

                function ti(t) {
                    if (Qn.call(this, t), "facebook.com" != this.providerId) throw Error("Invalid provider ID!")
                }

                function ei(t) {
                    if (Qn.call(this, t), "github.com" != this.providerId) throw Error("Invalid provider ID!");
                    An(this, "username", this.profile && this.profile.login || null)
                }

                function ni(t) {
                    if (Qn.call(this, t), "google.com" != this.providerId) throw Error("Invalid provider ID!")
                }

                function ii(t) {
                    if (Qn.call(this, t), "twitter.com" != this.providerId) throw Error("Invalid provider ID!");
                    An(this, "username", t.screenName || null)
                }

                function oi(t) {
                    var e = Te(t),
                        n = Ie(e, "link"),
                        i = Ie(Te(n), "link");
                    return e = Ie(e, "deep_link_id"), Ie(Te(e), "link") || e || i || n || t
                }

                function ri(t, e) {
                    if (!t && !e) throw new m("internal-error", "Internal assert: no raw session string available");
                    if (t && e) throw new m("internal-error", "Internal assert: unable to determine the session type");
                    this.a = t || null, this.b = e || null, this.type = this.a ? Xh : Jh
                }

                function ai() {}

                function si(t, e) {
                    return t.then(function(t) {
                        if (t[df]) {
                            var n = Xn(t[df]);
                            if (!n || e != n.h) throw new m("user-mismatch");
                            return t
                        }
                        throw new m("user-mismatch")
                    }).o(function(t) {
                        throw t && t.code && t.code == xc + "user-not-found" ? new m("user-mismatch") : t
                    })
                }

                function ui(t, e) {
                    if (!e) throw new m("internal-error", "failed to construct a credential");
                    this.a = e, An(this, "providerId", t), An(this, "signInMethod", t)
                }

                function ci(t) {
                    return {
                        pendingToken: t.a,
                        requestUri: "http://localhost"
                    }
                }

                function li(t) {
                    if (t && t.providerId && t.signInMethod && 0 == t.providerId.indexOf("saml.") && t.pendingToken) try {
                        return new ui(t.providerId, t.pendingToken)
                    } catch (t) {}
                    return null
                }

                function hi(t, e, n) {
                    if (this.a = null, e.idToken || e.accessToken) e.idToken && An(this, "idToken", e.idToken), e.accessToken && An(this, "accessToken", e.accessToken), e.nonce && !e.pendingToken && An(this, "nonce", e.nonce), e.pendingToken && (this.a = e.pendingToken);
                    else {
                        if (!e.oauthToken || !e.oauthTokenSecret) throw new m("internal-error", "failed to construct a credential");
                        An(this, "accessToken", e.oauthToken), An(this, "secret", e.oauthTokenSecret)
                    }
                    An(this, "providerId", t), An(this, "signInMethod", n)
                }

                function fi(t) {
                    var e = {};
                    return t.idToken && (e.id_token = t.idToken), t.accessToken && (e.access_token = t.accessToken), t.secret && (e.oauth_token_secret = t.secret), e.providerId = t.providerId, t.nonce && !t.a && (e.nonce = t.nonce), e = {
                        postBody: "" + Pe(e),
                        requestUri: "http://localhost"
                    }, t.a && (delete e.postBody, e.pendingToken = t.a), e
                }

                function pi(t) {
                    if (t && t.providerId && t.signInMethod) {
                        var e = {
                            idToken: t.oauthIdToken,
                            accessToken: t.oauthTokenSecret ? null : t.oauthAccessToken,
                            oauthTokenSecret: t.oauthTokenSecret,
                            oauthToken: t.oauthTokenSecret && t.oauthAccessToken,
                            nonce: t.nonce,
                            pendingToken: t.pendingToken
                        };
                        try {
                            return new hi(t.providerId, e, t.signInMethod)
                        } catch (t) {}
                    }
                    return null
                }

                function di(t, e) {
                    this.Oc = e || [], On(this, {
                        providerId: t,
                        isOAuthProvider: !0
                    }), this.Fb = {}, this.lb = (Yn(t) || {}).Ha || null, this.kb = null
                }

                function mi(t) {
                    if ("string" != typeof t || 0 != t.indexOf("saml.")) throw new m("argument-error", 'SAML provider IDs must be prefixed with "saml."');
                    di.call(this, t, [])
                }

                function vi(t) {
                    di.call(this, t, Wh), this.a = []
                }

                function gi() {
                    vi.call(this, "facebook.com")
                }

                function yi(t) {
                    if (!t) throw new m("argument-error", "credential failed: expected 1 argument (the OAuth access token).");
                    var e = t;
                    return u(t) && (e = t.accessToken), (new gi).credential({
                        accessToken: e
                    })
                }

                function bi() {
                    vi.call(this, "github.com")
                }

                function wi(t) {
                    if (!t) throw new m("argument-error", "credential failed: expected 1 argument (the OAuth access token).");
                    var e = t;
                    return u(t) && (e = t.accessToken), (new bi).credential({
                        accessToken: e
                    })
                }

                function _i() {
                    vi.call(this, "google.com"), this.Aa("profile")
                }

                function Si(t, e) {
                    var n = t;
                    return u(t) && (n = t.idToken, e = t.accessToken), (new _i).credential({
                        idToken: n,
                        accessToken: e
                    })
                }

                function Ii() {
                    di.call(this, "twitter.com", Gh)
                }

                function Ti(t, e) {
                    var n = t;
                    if (u(n) || (n = {
                            oauthToken: t,
                            oauthTokenSecret: e
                        }), !n.oauthToken || !n.oauthTokenSecret) throw new m("argument-error", "credential failed: expected 2 arguments (the OAuth access token and secret).");
                    return new hi("twitter.com", n, "twitter.com")
                }

                function Ni(t, e, n) {
                    this.a = t, this.f = e, An(this, "providerId", "password"), An(this, "signInMethod", n === Ei.EMAIL_LINK_SIGN_IN_METHOD ? Ei.EMAIL_LINK_SIGN_IN_METHOD : Ei.EMAIL_PASSWORD_SIGN_IN_METHOD)
                }

                function ki(t) {
                    return t && t.email && t.password ? new Ni(t.email, t.password, t.signInMethod) : null
                }

                function Ei() {
                    On(this, {
                        providerId: "password",
                        isOAuthProvider: !1
                    })
                }

                function Ci(t, e) {
                    if (!(e = Ai(e))) throw new m("argument-error", "Invalid email link!");
                    return new Ni(t, e.code, Ei.EMAIL_LINK_SIGN_IN_METHOD)
                }

                function Ai(t) {
                    return t = oi(t), (t = Fn(t)) && t.operation === dh ? t : null
                }

                function Oi(t) {
                    if (!(t.bb && t.ab || t.Ja && t.da)) throw new m("internal-error");
                    this.a = t, An(this, "providerId", "phone"), this.ea = "phone", An(this, "signInMethod", "phone")
                }

                function Pi(t) {
                    if (t && "phone" === t.providerId && (t.verificationId && t.verificationCode || t.temporaryProof && t.phoneNumber)) {
                        var e = {};
                        return Uc(["verificationId", "verificationCode", "temporaryProof", "phoneNumber"], function(n) {
                            t[n] && (e[n] = t[n])
                        }), new Oi(e)
                    }
                    return null
                }

                function xi(t) {
                    return t.a.Ja && t.a.da ? {
                        temporaryProof: t.a.Ja,
                        phoneNumber: t.a.da
                    } : {
                        sessionInfo: t.a.bb,
                        code: t.a.ab
                    }
                }

                function Mi(t) {
                    try {
                        this.a = t || i.a.auth()
                    } catch (t) {
                        throw new m("argument-error", "Either an instance of firebase.auth.Auth must be passed as an argument to the firebase.auth.PhoneAuthProvider constructor, or the default firebase App instance must be initialized via firebase.initializeApp().")
                    }
                    On(this, {
                        providerId: "phone",
                        isOAuthProvider: !1
                    })
                }

                function Li(t, e) {
                    if (!t) throw new m("missing-verification-id");
                    if (!e) throw new m("missing-verification-code");
                    return new Oi({
                        bb: t,
                        ab: e
                    })
                }

                function ji(t) {
                    if (t.temporaryProof && t.phoneNumber) return new Oi({
                        Ja: t.temporaryProof,
                        da: t.phoneNumber
                    });
                    var e = t && t.providerId;
                    if (!e || "password" === e) return null;
                    var n = t && t.oauthAccessToken,
                        i = t && t.oauthTokenSecret,
                        o = t && t.nonce,
                        r = t && t.oauthIdToken,
                        a = t && t.pendingToken;
                    try {
                        switch (e) {
                            case "google.com":
                                return Si(r, n);
                            case "facebook.com":
                                return yi(n);
                            case "github.com":
                                return wi(n);
                            case "twitter.com":
                                return Ti(n, i);
                            default:
                                return n || i || r || a ? a ? 0 == e.indexOf("saml.") ? new ui(e, a) : new hi(e, {
                                    pendingToken: a,
                                    idToken: t.oauthIdToken,
                                    accessToken: t.oauthAccessToken
                                }, e) : new vi(e).credential({
                                    idToken: r,
                                    accessToken: n,
                                    rawNonce: o
                                }) : null
                        }
                    } catch (t) {
                        return null
                    }
                }

                function Di(t) {
                    if (!t.isOAuthProvider) throw new m("invalid-oauth-provider")
                }

                function Ri(t, e, n, i, o, r, a) {
                    if (this.c = t, this.b = e || null, this.g = n || null, this.f = i || null, this.i = r || null, this.h = a || null, this.a = o || null, !this.g && !this.a) throw new m("invalid-auth-event");
                    if (this.g && this.a) throw new m("invalid-auth-event");
                    if (this.g && !this.f) throw new m("invalid-auth-event")
                }

                function Ui(t) {
                    return t = t || {}, t.type ? new Ri(t.type, t.eventId, t.urlResponse, t.sessionId, t.error && v(t.error), t.postBody, t.tenantId) : null
                }

                function Vi() {
                    this.b = null, this.a = []
                }

                function Fi(t) {
                    var e = Yh;
                    e.a.push(t), e.b || (e.b = function(t) {
                        for (var n = 0; e.a.length > n; n++) e.a[n](t)
                    }, "function" == typeof(t = cn("universalLinks.subscribe", Nc)) && t(null, e.b))
                }

                function Bi(t) {
                    var e = "unauthorized-domain",
                        n = void 0,
                        i = Te(t);
                    t = i.b, i = i.f, "chrome-extension" == i ? n = et("This chrome extension ID (chrome-extension://%s) is not authorized to run this operation. Add it to the OAuth redirect domains list in the Firebase console -> Auth section ->  method tab.", t) : "http" == i || "https" == i ? n = et("This domain (%s) is not authorized to run this operation. Add it to the OAuth redirect domains list in the Firebase console -> Auth section ->  method tab.", t) : e = "operation-not-supported-in-this-environment", m.call(this, e, n)
                }

                function Hi(t, e, n) {
                    m.call(this, t, n), t = e || {}, t.Gb && An(this, "email", t.Gb), t.da && An(this, "phoneNumber", t.da), t.credential && An(this, "credential", t.credential), t.Wb && An(this, "tenantId", t.Wb)
                }

                function Gi(t) {
                    if (t.code) {
                        var e = t.code || "";
                        0 == e.indexOf(xc) && (e = e.substring(xc.length));
                        var n = {
                            credential: ji(t),
                            Wb: t.tenantId
                        };
                        if (t.email) n.Gb = t.email;
                        else if (t.phoneNumber) n.da = t.phoneNumber;
                        else if (!n.credential) return new m(e, t.message || void 0);
                        return new Hi(e, n, t.message)
                    }
                    return null
                }

                function Wi() {}

                function Ki(t) {
                    return t.c || (t.c = t.b())
                }

                function qi() {}

                function zi(t) {
                    if (!t.f && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
                        for (var e = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], n = 0; 4 > n; n++) {
                            var i = e[n];
                            try {
                                return new ActiveXObject(i), t.f = i
                            } catch (t) {}
                        }
                        throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed")
                    }
                    return t.f
                }

                function Xi() {}

                function Ji() {
                    this.a = new XDomainRequest, this.readyState = 0, this.onreadystatechange = null, this.responseType = this.responseText = this.response = "", this.status = -1, this.statusText = "", this.a.onload = f(this.oc, this), this.a.onerror = f(this.Pb, this), this.a.onprogress = f(this.pc, this), this.a.ontimeout = f(this.tc, this)
                }

                function Yi(t, e) {
                    t.readyState = e, t.onreadystatechange && t.onreadystatechange()
                }

                function $i(t, e, n) {
                    this.reset(t, e, n, void 0, void 0)
                }

                function Zi(t) {
                    this.f = t, this.b = this.c = this.a = null
                }

                function Qi(t, e) {
                    this.name = t, this.value = e
                }

                function to(t) {
                    return t.c ? t.c : t.a ? to(t.a) : (_("Root logger has no level set."), null)
                }

                function eo(t) {
                    rf || (rf = new Zi(""), of [""] = rf, rf.c = ef);
                    var e;
                    if (!(e = of [t])) {
                        e = new Zi(t);
                        var n = t.lastIndexOf("."),
                            i = t.substr(n + 1);
                        n = eo(t.substr(0, n)), n.b || (n.b = {}), n.b[i] = e, e.a = n, of [t] = e
                    }
                    return e
                }

                function no(t, e) {
                    t && t.log(nf, e, void 0)
                }

                function io(t) {
                    this.f = t
                }

                function oo(t) {
                    re.call(this), this.s = t, this.readyState = af, this.status = 0, this.responseType = this.responseText = this.response = this.statusText = "", this.onreadystatechange = null, this.i = new Headers, this.b = null, this.m = "GET", this.g = "", this.a = !1, this.h = eo("goog.net.FetchXmlHttp"), this.l = this.c = this.f = null
                }

                function ro(t) {
                    t.c.read().then(t.nc.bind(t)).catch(t.Sa.bind(t))
                }

                function ao(t, e) {
                    e && t.f && (t.status = t.f.status, t.statusText = t.f.statusText), t.readyState = 4, t.f = null, t.c = null, t.l = null, so(t)
                }

                function so(t) {
                    t.onreadystatechange && t.onreadystatechange.call(t)
                }

                function uo(t) {
                    re.call(this), this.headers = new de, this.D = t || null, this.c = !1, this.B = this.a = null, this.h = this.P = this.l = "", this.f = this.O = this.i = this.N = !1, this.g = 0, this.s = null, this.m = sf, this.w = this.R = !1
                }

                function co(t, e, n, i, o) {
                    if (t.a) throw Error("[goog.net.XhrIo] Object is active with another request=" + t.l + "; newUri=" + e);
                    n = n ? n.toUpperCase() : "GET", t.l = e, t.h = "", t.P = n, t.N = !1, t.c = !0, t.a = t.D ? t.D.a() : $h.a(), t.B = Ki(t.D ? t.D : $h), t.a.onreadystatechange = f(t.Sb, t);
                    try {
                        no(t.b, _o(t, "Opening Xhr")), t.O = !0, t.a.open(n, e + "", !0), t.O = !1
                    } catch (e) {
                        return no(t.b, _o(t, "Error opening Xhr: " + e.message)), void fo(t, e)
                    }
                    e = i || "";
                    var r = new de(t.headers);
                    o && pe(o, function(t, e) {
                        r.set(e, t)
                    }), o = C(r.X()), i = Nc.FormData && e instanceof Nc.FormData, !A(cf, n) || o || i || r.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"), r.forEach(function(t, e) {
                        this.a.setRequestHeader(e, t)
                    }, t), t.m && (t.a.responseType = t.m), "withCredentials" in t.a && t.a.withCredentials !== t.R && (t.a.withCredentials = t.R);
                    try {
                        go(t), t.g > 0 && (t.w = lo(t.a), no(t.b, _o(t, "Will abort after " + t.g + "ms if incomplete, xhr2 " + t.w)), t.w ? (t.a.timeout = t.g, t.a.ontimeout = f(t.Ka, t)) : t.s = ce(t.Ka, t.g, t)), no(t.b, _o(t, "Sending request")), t.i = !0, t.a.send(e), t.i = !1
                    } catch (e) {
                        no(t.b, _o(t, "Send error: " + e.message)), fo(t, e)
                    }
                }

                function lo(t) {
                    return pl && at(9) && "number" == typeof t.timeout && void 0 !== t.ontimeout
                }

                function ho(t) {
                    return "content-type" == t.toLowerCase()
                }

                function fo(t, e) {
                    t.c = !1, t.a && (t.f = !0, t.a.abort(), t.f = !1), t.h = e, po(t), vo(t)
                }

                function po(t) {
                    t.N || (t.N = !0, t.dispatchEvent("complete"), t.dispatchEvent("error"))
                }

                function mo(t) {
                    if (t.c && void 0 !== Tc)
                        if (t.B[1] && 4 == yo(t) && 2 == bo(t)) no(t.b, _o(t, "Local request error detected and ignored"));
                        else if (t.i && 4 == yo(t)) ce(t.Sb, 0, t);
                    else if (t.dispatchEvent("readystatechange"), 4 == yo(t)) {
                        no(t.b, _o(t, "Request complete")), t.c = !1;
                        try {
                            var e = bo(t);
                            t: switch (e) {
                                case 200:
                                case 201:
                                case 202:
                                case 204:
                                case 206:
                                case 304:
                                case 1223:
                                    var n = !0;
                                    break t;
                                default:
                                    n = !1
                            }
                            var i;
                            if (!(i = n)) {
                                var o;
                                if (o = 0 === e) {
                                    var r = (t.l + "").match(zl)[1] || null;
                                    if (!r && Nc.self && Nc.self.location) {
                                        var a = Nc.self.location.protocol;
                                        r = a.substr(0, a.length - 1)
                                    }
                                    o = !uf.test(r ? r.toLowerCase() : "")
                                }
                                i = o
                            }
                            if (i) t.dispatchEvent("complete"), t.dispatchEvent("success");
                            else {
                                try {
                                    var s = yo(t) > 2 ? t.a.statusText : ""
                                } catch (e) {
                                    no(t.b, "Can not get status: " + e.message), s = ""
                                }
                                t.h = s + " [" + bo(t) + "]", po(t)
                            }
                        } finally {
                            vo(t)
                        }
                    }
                }

                function vo(t, e) {
                    if (t.a) {
                        go(t);
                        var n = t.a,
                            i = t.B[0] ? o : null;
                        t.a = null, t.B = null, e || t.dispatchEvent("ready");
                        try {
                            n.onreadystatechange = i
                        } catch (e) {
                            (t = t.b) && t.log(Qh, "Problem encountered resetting onreadystatechange: " + e.message, void 0)
                        }
                    }
                }

                function go(t) {
                    t.a && t.w && (t.a.ontimeout = null), t.s && (Nc.clearTimeout(t.s), t.s = null)
                }

                function yo(t) {
                    return t.a ? t.a.readyState : 0
                }

                function bo(t) {
                    try {
                        return yo(t) > 2 ? t.a.status : -1
                    } catch (t) {
                        return -1
                    }
                }

                function wo(t) {
                    try {
                        return t.a ? t.a.responseText : ""
                    } catch (e) {
                        return no(t.b, "Can not get responseText: " + e.message), ""
                    }
                }

                function _o(t, e) {
                    return e + " [" + t.P + " " + t.l + " " + bo(t) + "]"
                }

                function So(t) {
                    var e = Lo;
                    this.g = [], this.w = e, this.s = t || null, this.f = this.a = !1, this.c = void 0, this.u = this.B = this.i = !1, this.h = 0, this.b = null, this.l = 0
                }

                function Io(t, e, n) {
                    t.a = !0, t.c = n, t.f = !e, Co(t)
                }

                function To(t) {
                    if (t.a) {
                        if (!t.u) throw new Ao(t);
                        t.u = !1
                    }
                }

                function No(t, e) {
                    ko(t, null, e, void 0)
                }

                function ko(t, e, n, i) {
                    t.g.push([e, n, i]), t.a && Co(t)
                }

                function Eo(t) {
                    return Bc(t.g, function(t) {
                        return s(t[1])
                    })
                }

                function Co(t) {
                    if (t.h && t.a && Eo(t)) {
                        var e = t.h,
                            n = lf[e];
                        n && (Nc.clearTimeout(n.a), delete lf[e]), t.h = 0
                    }
                    t.b && (t.b.l--, delete t.b), e = t.c;
                    for (var i = n = !1; t.g.length && !t.i;) {
                        var o = t.g.shift(),
                            r = o[0],
                            a = o[1];
                        if (o = o[2], r = t.f ? a : r) try {
                            var s = r.call(o || t.s, e);
                            void 0 !== s && (t.f = t.f && (s == e || s instanceof Error), t.c = e = s), (y(e) || "function" == typeof Nc.Promise && e instanceof Nc.Promise) && (i = !0, t.i = !0)
                        } catch (i) {
                            e = i, t.f = !0, Eo(t) || (n = !0)
                        }
                    }
                    t.c = e, i && (s = f(t.m, t, !0), i = f(t.m, t, !1), e instanceof So ? (ko(e, s, i), e.B = !0) : e.then(s, i)), n && (e = new Po(e), lf[e.a] = e, t.h = e.a)
                }

                function Ao() {
                    b.call(this)
                }

                function Oo() {
                    b.call(this)
                }

                function Po(t) {
                    this.a = Nc.setTimeout(f(this.c, this), 0), this.b = t
                }

                function xo(t) {
                    var e = {},
                        n = e.document || document,
                        i = "" + K(t),
                        o = ht(document, "SCRIPT"),
                        r = {
                            Tb: o,
                            Ka: void 0
                        },
                        a = new So(r),
                        s = null,
                        u = null != e.timeout ? e.timeout : 5e3;
                    return u > 0 && (s = window.setTimeout(function() {
                        jo(o, !0);
                        var t = new Do(ff, "Timeout reached for loading script " + i);
                        To(a), Io(a, !1, t)
                    }, u), r.Ka = s), o.onload = o.onreadystatechange = function() {
                        o.readyState && "loaded" != o.readyState && "complete" != o.readyState || (jo(o, e.ud || !1, s), To(a), Io(a, !0, null))
                    }, o.onerror = function() {
                        jo(o, !0, s);
                        var t = new Do(hf, "Error while loading script " + i);
                        To(a), Io(a, !1, t)
                    }, r = e.attributes || {}, F(r, {
                        type: "text/javascript",
                        charset: "UTF-8"
                    }), ut(o, r), tt(o, t), Mo(n).appendChild(o), a
                }

                function Mo(t) {
                    var e;
                    return (e = (t || document).getElementsByTagName("HEAD")) && 0 != e.length ? e[0] : t.documentElement
                }

                function Lo() {
                    if (this && this.Tb) {
                        var t = this.Tb;
                        t && "SCRIPT" == t.tagName && jo(t, !0, this.Ka)
                    }
                }

                function jo(t, e, n) {
                    null != n && Nc.clearTimeout(n), t.onload = o, t.onerror = o, t.onreadystatechange = o, e && window.setTimeout(function() {
                        t && t.parentNode && t.parentNode.removeChild(t)
                    }, 0)
                }

                function Do(t, e) {
                    var n = "Jsloader error (code #" + t + ")";
                    e && (n += ": " + e), b.call(this, n), this.code = t
                }

                function Ro(t) {
                    this.f = t
                }

                function Uo(t, e, n) {
                    if (this.c = t, t = e || {}, this.u = t.secureTokenEndpoint || "https://securetoken.googleapis.com/v1/token", this.m = t.secureTokenTimeout || mf, this.g = V(t.secureTokenHeaders || vf), this.h = t.firebaseEndpoint || "https://www.googleapis.com/identitytoolkit/v3/relyingparty/", this.l = t.identityPlatformEndpoint || "https://identitytoolkit.googleapis.com/v2/", this.i = t.firebaseTimeout || gf, this.a = V(t.firebaseHeaders || yf), n && (this.a["X-Client-Version"] = n, this.g["X-Client-Version"] = n), n = "Node" == nn(), !(n = Nc.XMLHttpRequest || n && i.a.INTERNAL.node && i.a.INTERNAL.node.XMLHttpRequest) && !en()) throw new m("internal-error", "The XMLHttpRequest compatibility library was not found.");
                    this.f = void 0, this.f = en() ? new io(self) : on() ? new Ro(n) : new Xi, this.b = null
                }

                function Vo(t, e) {
                    e ? t.a["X-Firebase-Locale"] = e : delete t.a["X-Firebase-Locale"]
                }

                function Fo(t, e) {
                    e ? (t.a["X-Client-Version"] = e, t.g["X-Client-Version"] = e) : (delete t.a["X-Client-Version"], delete t.g["X-Client-Version"])
                }

                function Bo(t, e, n, i, o, r, a) {
                    qe() || en() ? t = f(t.w, t) : (pf || (pf = new yt(function(t, e) {
                        Ho(t, e)
                    })), t = f(t.s, t)), t(e, n, i, o, r, a)
                }

                function Ho(t, e) {
                    ((window.gapi || {}).client || {}).request ? t() : (Nc[wf] = function() {
                        ((window.gapi || {}).client || {}).request ? t() : e(Error("CORS_UNSUPPORTED"))
                    }, No(xo(q(bf, {
                        onload: wf
                    })), function() {
                        e(Error("CORS_UNSUPPORTED"))
                    }))
                }

                function Go(t, e) {
                    return new yt(function(n, i) {
                        "refresh_token" == e.grant_type && e.refresh_token || "authorization_code" == e.grant_type && e.code ? Bo(t, t.u + "?key=" + encodeURIComponent(t.c), function(t) {
                            t ? t.error ? i(hr(t)) : t.access_token && t.refresh_token ? n(t) : i(new m("internal-error")) : i(new m("network-request-failed"))
                        }, "POST", "" + Pe(e), t.g, t.m.get()) : i(new m("internal-error"))
                    })
                }

                function Wo(t, e, n, i, o, r, a) {
                    var s = Te(e + n);
                    Se(s, "key", t.c), a && Se(s, "cb", "" + Oc());
                    var u = "GET" == i;
                    if (u)
                        for (var c in o) o.hasOwnProperty(c) && Se(s, c, o[c]);
                    return new yt(function(e, n) {
                        Bo(t, "" + s, function(t) {
                            t ? t.error ? n(hr(t, r || {})) : e(t) : n(new m("network-request-failed"))
                        }, i, u ? void 0 : Ue(vn(o)), t.a, t.i.get())
                    })
                }

                function Ko(t) {
                    if ("string" != typeof(t = t.email) || !nh.test(t)) throw new m("invalid-email")
                }

                function qo(t) {
                    "email" in t && Ko(t)
                }

                function zo(t, e) {
                    return cr(t, Nf, {
                        identifier: e,
                        continueUri: fn() ? Ge() : "http://localhost"
                    }).then(function(t) {
                        return t.signinMethods || []
                    })
                }

                function Xo(t) {
                    return cr(t, Rf, {}).then(function(t) {
                        return t.authorizedDomains || []
                    })
                }

                function Jo(t) {
                    if (!t[df]) {
                        if (t.mfaPendingCredential) throw new m("multi-factor-auth-required", null, V(t));
                        throw new m("internal-error")
                    }
                }

                function Yo(t) {
                    if (t.phoneNumber || t.temporaryProof) {
                        if (!t.phoneNumber || !t.temporaryProof) throw new m("internal-error")
                    } else {
                        if (!t.sessionInfo) throw new m("missing-verification-id");
                        if (!t.code) throw new m("missing-verification-code")
                    }
                }

                function $o(t, e) {
                    return cr(t, Ff, e)
                }

                function Zo(t, e) {
                    return cr(t, Wf, e).then(function(t) {
                        return t.phoneSessionInfo.sessionInfo
                    })
                }

                function Qo(t) {
                    if (!t.phoneVerificationInfo) throw new m("internal-error");
                    if (!t.phoneVerificationInfo.sessionInfo) throw new m("missing-verification-id");
                    if (!t.phoneVerificationInfo.code) throw new m("missing-verification-code")
                }

                function tr(t, e) {
                    return cr(t, Kf, e).then(function(t) {
                        return t.phoneResponseInfo.sessionInfo
                    })
                }

                function er(t, e, n) {
                    return cr(t, Ef, {
                        idToken: e,
                        deleteProvider: n
                    })
                }

                function nr(t) {
                    if (!t.requestUri || !t.sessionId && !t.postBody && !t.pendingToken) throw new m("internal-error")
                }

                function ir(t, e) {
                    return e.oauthIdToken && e.providerId && 0 == e.providerId.indexOf("oidc.") && !e.pendingToken && (t.sessionId ? e.nonce = t.sessionId : t.postBody && (t = new Ae(t.postBody), Me(t, "nonce") && (e.nonce = t.get("nonce")))), e
                }

                function or(t) {
                    var e = null;
                    if (t.needConfirmation ? (t.code = "account-exists-with-different-credential", e = Gi(t)) : "FEDERATED_USER_ID_ALREADY_LINKED" == t.errorMessage ? (t.code = "credential-already-in-use", e = Gi(t)) : "EMAIL_EXISTS" == t.errorMessage ? (t.code = "email-already-in-use", e = Gi(t)) : t.errorMessage && (e = lr(t.errorMessage)), e) throw e;
                    Jo(t)
                }

                function rr(t, e) {
                    return e.returnIdpCredential = !0, cr(t, qf, e)
                }

                function ar(t, e) {
                    return e.returnIdpCredential = !0, cr(t, Xf, e)
                }

                function sr(t, e) {
                    return e.returnIdpCredential = !0, e.autoCreate = !1, cr(t, zf, e)
                }

                function ur(t) {
                    if (!t.oobCode) throw new m("invalid-action-code")
                }

                function cr(t, e, n) {
                    if (!Mn(n, e.M)) return St(new m("internal-error"));
                    var i, o = !!e.La,
                        r = e.Rb || "POST";
                    return _t(n).then(e.A).then(function() {
                        return e.U && (n.returnSecureToken = !0), e.C && t.b && void 0 === n.tenantId && (n.tenantId = t.b), o ? Wo(t, t.l, e.endpoint, r, n, e.Eb, e.hb || !1) : Wo(t, t.h, e.endpoint, r, n, e.Eb, e.hb || !1)
                    }).then(function(t) {
                        return i = t, e.Wa ? e.Wa(n, i) : i
                    }).then(e.G).then(function() {
                        if (!e.Y) return i;
                        if (!(e.Y in i)) throw new m("internal-error");
                        return i[e.Y]
                    })
                }

                function lr(t) {
                    return hr({
                        error: {
                            errors: [{
                                message: t
                            }],
                            code: 400,
                            message: t
                        }
                    })
                }

                function hr(t, e) {
                    var n = (t.error && t.error.errors && t.error.errors[0] || {}).reason || "",
                        i = {
                            keyInvalid: "invalid-api-key",
                            ipRefererBlocked: "app-not-authorized"
                        };
                    if (n = i[n] ? new m(i[n]) : null) return n;
                    n = t.error && t.error.message || "", i = {
                        INVALID_CUSTOM_TOKEN: "invalid-custom-token",
                        CREDENTIAL_MISMATCH: "custom-token-mismatch",
                        MISSING_CUSTOM_TOKEN: "internal-error",
                        INVALID_IDENTIFIER: "invalid-email",
                        MISSING_CONTINUE_URI: "internal-error",
                        INVALID_EMAIL: "invalid-email",
                        INVALID_PASSWORD: "wrong-password",
                        USER_DISABLED: "user-disabled",
                        MISSING_PASSWORD: "internal-error",
                        EMAIL_EXISTS: "email-already-in-use",
                        PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
                        INVALID_IDP_RESPONSE: "invalid-credential",
                        INVALID_PENDING_TOKEN: "invalid-credential",
                        FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
                        MISSING_OR_INVALID_NONCE: "missing-or-invalid-nonce",
                        INVALID_MESSAGE_PAYLOAD: "invalid-message-payload",
                        INVALID_RECIPIENT_EMAIL: "invalid-recipient-email",
                        INVALID_SENDER: "invalid-sender",
                        EMAIL_NOT_FOUND: "user-not-found",
                        RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
                        EXPIRED_OOB_CODE: "expired-action-code",
                        INVALID_OOB_CODE: "invalid-action-code",
                        MISSING_OOB_CODE: "internal-error",
                        INVALID_PROVIDER_ID: "invalid-provider-id",
                        CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
                        INVALID_ID_TOKEN: "invalid-user-token",
                        TOKEN_EXPIRED: "user-token-expired",
                        USER_NOT_FOUND: "user-token-expired",
                        CORS_UNSUPPORTED: "cors-unsupported",
                        DYNAMIC_LINK_NOT_ACTIVATED: "dynamic-link-not-activated",
                        INVALID_APP_ID: "invalid-app-id",
                        TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
                        WEAK_PASSWORD: "weak-password",
                        OPERATION_NOT_ALLOWED: "operation-not-allowed",
                        USER_CANCELLED: "user-cancelled",
                        CAPTCHA_CHECK_FAILED: "captcha-check-failed",
                        INVALID_APP_CREDENTIAL: "invalid-app-credential",
                        INVALID_CODE: "invalid-verification-code",
                        INVALID_PHONE_NUMBER: "invalid-phone-number",
                        INVALID_SESSION_INFO: "invalid-verification-id",
                        INVALID_TEMPORARY_PROOF: "invalid-credential",
                        MISSING_APP_CREDENTIAL: "missing-app-credential",
                        MISSING_CODE: "missing-verification-code",
                        MISSING_PHONE_NUMBER: "missing-phone-number",
                        MISSING_SESSION_INFO: "missing-verification-id",
                        QUOTA_EXCEEDED: "quota-exceeded",
                        SESSION_EXPIRED: "code-expired",
                        REJECTED_CREDENTIAL: "rejected-credential",
                        INVALID_CONTINUE_URI: "invalid-continue-uri",
                        MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
                        MISSING_IOS_BUNDLE_ID: "missing-ios-bundle-id",
                        UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
                        INVALID_DYNAMIC_LINK_DOMAIN: "invalid-dynamic-link-domain",
                        INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
                        INVALID_CERT_HASH: "invalid-cert-hash",
                        UNSUPPORTED_TENANT_OPERATION: "unsupported-tenant-operation",
                        INVALID_TENANT_ID: "invalid-tenant-id",
                        TENANT_ID_MISMATCH: "tenant-id-mismatch",
                        ADMIN_ONLY_OPERATION: "admin-restricted-operation",
                        INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
                        MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
                        MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
                        MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
                        EMAIL_CHANGE_NEEDS_VERIFICATION: "email-change-needs-verification",
                        SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
                        SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
                        UNSUPPORTED_FIRST_FACTOR: "unsupported-first-factor",
                        UNVERIFIED_EMAIL: "unverified-email"
                    }, F(i, e || {}), e = (e = n.match(/^[^\s]+\s*:\s*([\s\S]*)$/)) && e.length > 1 ? e[1] : void 0;
                    for (var o in i)
                        if (0 === n.indexOf(o)) return new m(i[o], e);
                    return !e && t && (e = mn(t)), new m("internal-error", e)
                }

                function fr(t) {
                    this.b = t, this.a = null, this.nb = pr(this)
                }

                function pr(t) {
                    return vr().then(function() {
                        return new yt(function(e, n) {
                            cn("gapi.iframes.getContext")().open({
                                where: document.body,
                                url: t.b,
                                messageHandlersFilter: cn("gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER"),
                                attributes: {
                                    style: {
                                        position: "absolute",
                                        top: "-100px",
                                        width: "1px",
                                        height: "1px"
                                    }
                                },
                                dontclear: !0
                            }, function(i) {
                                function o() {
                                    clearTimeout(r), e()
                                }
                                t.a = i, t.a.restyle({
                                    setHideOnLeave: !1
                                });
                                var r = setTimeout(function() {
                                    n(Error("Network Error"))
                                }, ip.get());
                                i.ping(o).then(o, function() {
                                    n(Error("Network Error"))
                                })
                            })
                        })
                    })
                }

                function dr(t, e) {
                    return t.nb.then(function() {
                        return new yt(function(n) {
                            t.a.send(e.type, e, n, cn("gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER"))
                        })
                    })
                }

                function mr(t, e) {
                    t.nb.then(function() {
                        t.a.register("authEvent", e, cn("gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER"))
                    })
                }

                function vr() {
                    return op || (op = new yt(function(t, e) {
                        function n() {
                            wn(), cn("gapi.load")("gapi.iframes", {
                                callback: t,
                                ontimeout: function() {
                                    wn(), e(Error("Network Error"))
                                },
                                timeout: np.get()
                            })
                        }
                        if (cn("gapi.iframes.Iframe")) t();
                        else if (cn("gapi.load")) n();
                        else {
                            var i = "__iframefcb" + Math.floor(1e6 * Math.random());
                            Nc[i] = function() {
                                cn("gapi.load") ? n() : e(Error("Network Error"))
                            }, i = q(ep, {
                                onload: i
                            }), _t(xo(i)).o(function() {
                                e(Error("Network Error"))
                            })
                        }
                    }).o(function(t) {
                        throw op = null, t
                    }))
                }

                function gr(t, e, n) {
                    this.i = t, this.g = e, this.h = n, this.f = null, this.a = Ne(this.i, "/__/auth/iframe"), Se(this.a, "apiKey", this.g), Se(this.a, "appName", this.h), this.b = null, this.c = []
                }

                function yr(t, e, n, i, o) {
                    this.s = t, this.m = e, this.c = n, this.u = i, this.i = this.g = this.l = null, this.a = o, this.h = this.f = null
                }

                function br(t) {
                    try {
                        return i.a.app(t).auth().Ea()
                    } catch (t) {
                        return []
                    }
                }

                function wr(t, e, n, i, o) {
                    this.u = t, this.f = e, this.b = n, this.c = i || null, this.h = o || null, this.m = this.s = this.w = null, this.g = [], this.l = this.a = null
                }

                function _r(t) {
                    var e = Ge();
                    return Xo(t).then(function(t) {
                        t: {
                            var n = Te(e),
                                i = n.f;n = n.b;
                            for (var o = 0; t.length > o; o++) {
                                var r = t[o],
                                    a = n,
                                    s = i;
                                if (0 == r.indexOf("chrome-extension_/index.html") ? a = Te(r).b == a && "chrome-extension" == s : "http" != s && "https" != s ? a = !1 : eh.test(r) ? a = a == r : (r = r.split(".").join("\\."), a = RegExp("^(.+\\." + r + "|" + r + ")$", "i").test(a)), a) {
                                    t = !0;
                                    break t
                                }
                            }
                            t = !1
                        }
                        if (!t) throw new Bi(Ge())
                    })
                }

                function Sr(t) {
                    return t.l ? t.l : t.l = $e().then(function() {
                        if (!t.s) {
                            var e = t.c,
                                n = t.h,
                                i = br(t.b),
                                o = new gr(t.u, t.f, t.b);
                            o.f = e, o.b = n, o.c = M(i || []), t.s = "" + o
                        }
                        t.i = new fr(t.s), Nr(t)
                    })
                }

                function Ir(t) {
                    return t.m || (t.w = t.c ? sn(t.c, br(t.b)) : null, t.m = new Uo(t.f, g(t.h), t.w)), t.m
                }

                function Tr(t, e, n, i, o, r, a, s, u, c, l) {
                    return t = new yr(t, e, n, i, o), t.l = r, t.g = a, t.i = s, t.b = V(u || null), t.f = c, "" + t.ub(l)
                }

                function Nr(t) {
                    if (!t.i) throw Error("IfcHandler must be initialized!");
                    mr(t.i, function(e) {
                        var n = {};
                        if (e && e.authEvent) {
                            var i = !1;
                            for (e = Ui(e.authEvent), n = 0; t.g.length > n; n++) i = t.g[n](e) || i;
                            return n = {}, n.status = i ? "ACK" : "ERROR", _t(n)
                        }
                        return n.status = "ERROR", _t(n)
                    })
                }

                function kr(t) {
                    var e = {
                        type: "webStorageSupport"
                    };
                    return Sr(t).then(function() {
                        return dr(t.i, e)
                    }).then(function(t) {
                        if (t && t.length && void 0 !== t[0].webStorageSupport) return t[0].webStorageSupport;
                        throw Error()
                    })
                }

                function Er(t) {
                    if (!(this.a = t || i.a.INTERNAL.reactNative && i.a.INTERNAL.reactNative.AsyncStorage)) throw new m("internal-error", "The React Native compatibility library was not found.");
                    this.type = "asyncStorage"
                }

                function Cr(t) {
                    this.b = t, this.a = {}, this.f = f(this.c, this)
                }

                function Ar() {
                    var t = en() ? self : null;
                    if (Uc(rp, function(n) {
                            n.b == t && (e = n)
                        }), !e) {
                        var e = new Cr(t);
                        rp.push(e)
                    }
                    return e
                }

                function Or(t, e, n) {
                    U(t.a) && t.b.addEventListener("message", t.f), void 0 === t.a[e] && (t.a[e] = []), t.a[e].push(n)
                }

                function Pr(t) {
                    this.a = t
                }

                function xr(t) {
                    this.c = t, this.b = !1, this.a = []
                }

                function Mr(t, e, n, i) {
                    var o, r, a, s, u = n || {},
                        c = null;
                    if (t.b) return St(Error("connection_unavailable"));
                    var l = i ? 800 : 50,
                        h = "undefined" != typeof MessageChannel ? new MessageChannel : null;
                    return new yt(function(n, i) {
                        h ? (o = "" + Math.floor(Math.random() * Math.pow(10, 20)), h.port1.start(), a = setTimeout(function() {
                            i(Error("unsupported_event"))
                        }, l), r = function(t) {
                            t.data.eventId === o && ("ack" === t.data.status ? (clearTimeout(a), s = setTimeout(function() {
                                i(Error("timeout"))
                            }, 3e3)) : "done" === t.data.status ? (clearTimeout(s), void 0 !== t.data.response ? n(t.data.response) : i(Error("unknown_error"))) : (clearTimeout(a), clearTimeout(s), i(Error("invalid_response"))))
                        }, c = {
                            messageChannel: h,
                            onMessage: r
                        }, t.a.push(c), h.port1.addEventListener("message", r), t.c.postMessage({
                            eventType: e,
                            eventId: o,
                            data: u
                        }, [h.port2])) : i(Error("connection_unavailable"))
                    }).then(function(e) {
                        return Lr(t, c), e
                    }).o(function(e) {
                        throw Lr(t, c), e
                    })
                }

                function Lr(t, e) {
                    if (e) {
                        var n = e.messageChannel,
                            i = e.onMessage;
                        n && (n.port1.removeEventListener("message", i), n.port1.close()), P(t.a, function(t) {
                            return t == e
                        })
                    }
                }

                function jr() {
                    if (!Vr()) throw new m("web-storage-unsupported");
                    this.c = {}, this.a = [], this.b = 0, this.u = Nc.indexedDB, this.type = "indexedDB", this.g = this.l = this.f = this.i = null, this.s = !1, this.h = null;
                    var t = this;
                    en() && self ? (this.l = Ar(), Or(this.l, "keyChanged", function(e, n) {
                        return Wr(t).then(function(e) {
                            return e.length > 0 && Uc(t.a, function(t) {
                                t(e)
                            }), {
                                keyProcessed: A(e, n.key)
                            }
                        })
                    }), Or(this.l, "ping", function() {
                        return _t(["keyChanged"])
                    })) : En().then(function(e) {
                        (t.h = e) && (t.g = new xr(new Pr(e)), Mr(t.g, "ping", null, !0).then(function(e) {
                            e[0].fulfilled && A(e[0].value, "keyChanged") && (t.s = !0)
                        }).o(function() {}))
                    })
                }

                function Dr(t) {
                    return new yt(function(e, n) {
                        var i = t.u.deleteDatabase("firebaseLocalStorageDb");
                        i.onsuccess = function() {
                            e()
                        }, i.onerror = function(t) {
                            n(Error(t.target.error))
                        }
                    })
                }

                function Rr(t) {
                    return new yt(function(e, n) {
                        var i = t.u.open("firebaseLocalStorageDb.html", 1);
                        i.onerror = function(t) {
                            try {
                                t.preventDefault()
                            } catch (t) {}
                            n(Error(t.target.error))
                        }, i.onupgradeneeded = function(t) {
                            t = t.target.result;
                            try {
                                t.createObjectStore("firebaseLocalStorage", {
                                    keyPath: "fbase_key"
                                })
                            } catch (t) {
                                n(t)
                            }
                        }, i.onsuccess = function(i) {
                            i = i.target.result, i.objectStoreNames.contains("firebaseLocalStorage") ? e(i) : Dr(t).then(function() {
                                return Rr(t)
                            }).then(function(t) {
                                e(t)
                            }).o(function(t) {
                                n(t)
                            })
                        }
                    })
                }

                function Ur(t) {
                    return t.m || (t.m = Rr(t)), t.m
                }

                function Vr() {
                    try {
                        return !!Nc.indexedDB
                    } catch (t) {
                        return !1
                    }
                }

                function Fr(t) {
                    return t.objectStore("firebaseLocalStorage")
                }

                function Br(t, e) {
                    return t.transaction(["firebaseLocalStorage"], e ? "readwrite" : "readonly")
                }

                function Hr(t) {
                    return new yt(function(e, n) {
                        t.onsuccess = function(t) {
                            t && t.target ? e(t.target.result) : e()
                        }, t.onerror = function(t) {
                            n(t.target.error)
                        }
                    })
                }

                function Gr(t, e) {
                    return t.g && t.h && kn() === t.h ? Mr(t.g, "keyChanged", {
                        key: e
                    }, t.s).then(function() {}).o(function() {}) : _t()
                }

                function Wr(t) {
                    return Ur(t).then(function(t) {
                        var e = Fr(Br(t, !1));
                        return e.getAll ? Hr(e.getAll()) : new yt(function(t, n) {
                            var i = [],
                                o = e.openCursor();
                            o.onsuccess = function(e) {
                                (e = e.target.result) ? (i.push(e.value), e.continue()) : t(i)
                            }, o.onerror = function(t) {
                                n(t.target.error)
                            }
                        })
                    }).then(function(e) {
                        var n = {},
                            i = [];
                        if (0 == t.b) {
                            for (i = 0; e.length > i; i++) n[e[i].fbase_key] = e[i].value;
                            i = Ke(t.c, n), t.c = n
                        }
                        return i
                    })
                }

                function Kr(t) {
                    function e() {
                        t.f = setTimeout(function() {
                            t.i = Wr(t).then(function(e) {
                                e.length > 0 && Uc(t.a, function(t) {
                                    t(e)
                                })
                            }).then(function() {
                                e()
                            }).o(function(t) {
                                "STOP_EVENT" != t.message && e()
                            })
                        }, 800)
                    }
                    qr(t), e()
                }

                function qr(t) {
                    t.i && t.i.cancel("STOP_EVENT"), t.f && (clearTimeout(t.f), t.f = null)
                }

                function zr(t) {
                    var e = this,
                        n = null;
                    this.a = [], this.type = "indexedDB", this.c = t, this.b = _t().then(function() {
                        if (Vr()) {
                            var t = yn(),
                                i = "__sak" + t;
                            return ap || (ap = new jr), n = ap, n.set(i, t).then(function() {
                                return n.get(i)
                            }).then(function(e) {
                                if (e !== t) throw Error("indexedDB not supported!");
                                return n.T(i)
                            }).then(function() {
                                return n
                            }).o(function() {
                                return e.c
                            })
                        }
                        return e.c
                    }).then(function(t) {
                        return e.type = t.type, t.ba(function(t) {
                            Uc(e.a, function(e) {
                                e(t)
                            })
                        }), t
                    })
                }

                function Xr() {
                    this.a = {}, this.type = "inMemory"
                }

                function Jr() {
                    if (!$r()) {
                        if ("Node" == nn()) throw new m("internal-error", "The LocalStorage compatibility library was not found.");
                        throw new m("web-storage-unsupported")
                    }
                    this.a = Yr() || i.a.INTERNAL.node.localStorage, this.type = "localStorage"
                }

                function Yr() {
                    try {
                        var t = Nc.localStorage,
                            e = yn();
                        return t && (t.setItem(e, "1"), t.removeItem(e)), t
                    } catch (t) {
                        return null
                    }
                }

                function $r() {
                    var t = "Node" == nn();
                    if (!(t = Yr() || t && i.a.INTERNAL.node && i.a.INTERNAL.node.localStorage)) return !1;
                    try {
                        return t.setItem("__sak", "1"), t.removeItem("__sak"), !0
                    } catch (t) {
                        return !1
                    }
                }

                function Zr() {
                    this.type = "nullStorage"
                }

                function Qr() {
                    if (!ea()) {
                        if ("Node" == nn()) throw new m("internal-error", "The SessionStorage compatibility library was not found.");
                        throw new m("web-storage-unsupported")
                    }
                    this.a = ta() || i.a.INTERNAL.node.sessionStorage, this.type = "sessionStorage"
                }

                function ta() {
                    try {
                        var t = Nc.sessionStorage,
                            e = yn();
                        return t && (t.setItem(e, "1"), t.removeItem(e)), t
                    } catch (t) {
                        return null
                    }
                }

                function ea() {
                    var t = "Node" == nn();
                    if (!(t = ta() || t && i.a.INTERNAL.node && i.a.INTERNAL.node.sessionStorage)) return !1;
                    try {
                        return t.setItem("__sak", "1"), t.removeItem("__sak"), !0
                    } catch (t) {
                        return !1
                    }
                }

                function na() {
                    var t = {};
                    t.Browser = cp, t.Node = lp, t.ReactNative = hp, t.Worker = fp, this.a = t[nn()]
                }

                function ia(t) {
                    var e = new m("invalid-persistence-type"),
                        n = new m("unsupported-persistence-type");
                    t: {
                        for (i in pp)
                            if (pp[i] == t) {
                                var i = !0;
                                break t
                            } i = !1
                    }
                    if (!i || "string" != typeof t) throw e;
                    switch (nn()) {
                        case "ReactNative":
                            if ("session" === t) throw n;
                            break;
                        case "Node":
                            if ("none" !== t) throw n;
                            break;
                        case "Worker":
                            if ("session" === t || !Vr() && "none" !== t) throw n;
                            break;
                        default:
                            if (!ln() && "none" !== t) throw n
                    }
                }

                function oa() {
                    var t = !(bn(un()) || !tn()),
                        e = dn(),
                        n = ln();
                    this.m = t, this.h = e, this.l = n, this.a = {}, sp || (sp = new na), t = sp;
                    try {
                        this.g = !He() && Nn() || !Nc.indexedDB ? new t.a.F : new zr(en() ? new Xr : new t.a.F)
                    } catch (t) {
                        this.g = new Xr, this.h = !0
                    }
                    try {
                        this.i = new t.a.$a
                    } catch (t) {
                        this.i = new Xr
                    }
                    this.u = new Xr, this.f = f(this.Vb, this), this.b = {}
                }

                function ra() {
                    return up || (up = new oa), up
                }

                function aa(t, e) {
                    switch (e) {
                        case "session":
                            return t.i;
                        case "none":
                            return t.u;
                        default:
                            return t.g
                    }
                }

                function sa(t, e) {
                    return "firebase:" + t.name + (e ? ":" + e : "")
                }

                function ua(t, e, n) {
                    var i = sa(e, n),
                        o = aa(t, e.F);
                    return t.get(e, n).then(function(r) {
                        var a = null;
                        try {
                            a = gn(Nc.localStorage.getItem(i))
                        } catch (t) {}
                        if (a && !r) return Nc.localStorage.removeItem(i), t.set(e, a, n);
                        a && r && "localStorage" != o.type && Nc.localStorage.removeItem(i)
                    })
                }

                function ca(t, e, n) {
                    return n = sa(e, n), "local" == e.F && (t.b[n] = null), aa(t, e.F).T(n)
                }

                function la(t) {
                    ha(t), t.c = setInterval(function() {
                        for (var e in t.a) {
                            var n = Nc.localStorage.getItem(e),
                                i = t.b[e];
                            n != i && (t.b[e] = n, n = new Bt({
                                type: "storage",
                                key: e,
                                target: window,
                                oldValue: i,
                                newValue: n,
                                a: !0
                            }), t.Vb(n))
                        }
                    }, 1e3)
                }

                function ha(t) {
                    t.c && (clearInterval(t.c), t.c = null)
                }

                function fa(t) {
                    this.a = t, this.b = ra()
                }

                function pa(t) {
                    return t.b.get(mp, t.a).then(function(t) {
                        return Ui(t)
                    })
                }

                function da() {
                    this.a = ra()
                }

                function ma() {
                    this.b = -1
                }

                function va(t, e) {
                    this.b = vp, this.f = Nc.Uint8Array ? new Uint8Array(this.b) : Array(this.b), this.g = this.c = 0, this.a = [], this.i = t, this.h = e, this.l = Nc.Int32Array ? new Int32Array(64) : Array(64), void 0 === dp && (dp = Nc.Int32Array ? new Int32Array(_p) : _p), this.reset()
                }

                function ga(t) {
                    for (var e = t.f, n = t.l, i = 0, o = 0; e.length > o;) n[i++] = e[o] << 24 | e[o + 1] << 16 | e[o + 2] << 8 | e[o + 3], o = 4 * i;
                    for (e = 16; 64 > e; e++) {
                        o = 0 | n[e - 15], i = 0 | n[e - 2];
                        var r = (0 | n[e - 16]) + ((o >>> 7 | o << 25) ^ (o >>> 18 | o << 14) ^ o >>> 3) | 0,
                            a = (0 | n[e - 7]) + ((i >>> 17 | i << 15) ^ (i >>> 19 | i << 13) ^ i >>> 10) | 0;
                        n[e] = r + a | 0
                    }
                    i = 0 | t.a[0], o = 0 | t.a[1];
                    var s = 0 | t.a[2],
                        u = 0 | t.a[3],
                        c = 0 | t.a[4],
                        l = 0 | t.a[5],
                        h = 0 | t.a[6];
                    for (r = 0 | t.a[7], e = 0; 64 > e; e++) {
                        var f = ((i >>> 2 | i << 30) ^ (i >>> 13 | i << 19) ^ (i >>> 22 | i << 10)) + (i & o ^ i & s ^ o & s) | 0;
                        a = c & l ^ ~c & h, r = r + ((c >>> 6 | c << 26) ^ (c >>> 11 | c << 21) ^ (c >>> 25 | c << 7)) | 0, a = a + (0 | dp[e]) | 0, a = r + (a + (0 | n[e]) | 0) | 0, r = h, h = l, l = c, c = u + a | 0, u = s, s = o, o = i, i = a + f | 0
                    }
                    t.a[0] = t.a[0] + i | 0, t.a[1] = t.a[1] + o | 0, t.a[2] = t.a[2] + s | 0, t.a[3] = t.a[3] + u | 0, t.a[4] = t.a[4] + c | 0, t.a[5] = t.a[5] + l | 0, t.a[6] = t.a[6] + h | 0, t.a[7] = t.a[7] + r | 0
                }

                function ya(t, e, n) {
                    void 0 === n && (n = e.length);
                    var i = 0,
                        o = t.c;
                    if ("string" == typeof e)
                        for (; n > i;) t.f[o++] = e.charCodeAt(i++), o == t.b && (ga(t), o = 0);
                    else {
                        if (!a(e)) throw Error("message must be string or array");
                        for (; n > i;) {
                            var r = e[i++];
                            if ("number" != typeof r || 0 > r || r > 255 || r != (0 | r)) throw Error("message must be a byte array");
                            t.f[o++] = r, o == t.b && (ga(t), o = 0)
                        }
                    }
                    t.c = o, t.g += n
                }

                function ba() {
                    va.call(this, 8, Sp)
                }

                function wa(t, e, n, i, o) {
                    this.u = t, this.i = e, this.l = n, this.m = i || null, this.s = o || null, this.h = e + ":" + n, this.w = new da, this.g = new fa(this.h), this.f = null, this.b = [], this.a = this.c = null
                }

                function _a(t) {
                    return new m("invalid-cordova-configuration", t)
                }

                function Sa() {
                    for (var t = 20, e = []; t > 0;) e.push("1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(Math.floor(62 * Math.random()))), t--;
                    return e.join("")
                }

                function Ia(t) {
                    var e = new ba;
                    ya(e, t), t = [];
                    var n = 8 * e.g;
                    56 > e.c ? ya(e, wp, 56 - e.c) : ya(e, wp, e.b - (e.c - 56));
                    for (var i = 63; i >= 56; i--) e.f[i] = 255 & n, n /= 256;
                    for (ga(e), i = n = 0; e.i > i; i++)
                        for (var o = 24; o >= 0; o -= 8) t[n++] = e.a[i] >> o & 255;
                    return Gn(t)
                }

                function Ta(t, e, n, i, o) {
                    var r = Sa(),
                        a = new Ri(e, i, null, r, new m("no-auth-event"), null, o),
                        s = cn("BuildInfo.packageName", Nc);
                    if ("string" != typeof s) throw new m("invalid-cordova-configuration");
                    var u = cn("BuildInfo.displayName", Nc),
                        c = {};
                    if (un().toLowerCase().match(/iphone|ipad|ipod/)) c.ibi = s;
                    else {
                        if (!un().toLowerCase().match(/android/)) return St(new m("operation-not-supported-in-this-environment"));
                        c.apn = s
                    }
                    u && (c.appDisplayName = u), r = Ia(r), c.sessionId = r;
                    var l = Tr(t.u, t.i, t.l, e, n, null, i, t.m, c, t.s, o);
                    return t.ka().then(function() {
                        var e = t.h;
                        return t.w.a.set(mp, a.v(), e)
                    }).then(function() {
                        var e = cn("cordova.plugins.browsertab.isAvailable", Nc);
                        if ("function" != typeof e) throw new m("invalid-cordova-configuration");
                        var n = null;
                        e(function(e) {
                            if (e) {
                                if ("function" != typeof(n = cn("cordova.plugins.browsertab.openUrl", Nc))) throw new m("invalid-cordova-configuration");
                                n(l)
                            } else {
                                if ("function" != typeof(n = cn("cordova.InAppBrowser.open", Nc))) throw new m("invalid-cordova-configuration");
                                e = un(), t.a = n(l, e.match(/(iPad|iPhone|iPod).*OS 7_\d/i) || e.match(/(iPad|iPhone|iPod).*OS 8_\d/i) ? "_blank" : "_system", "location=yes")
                            }
                        })
                    })
                }

                function Na(t, e) {
                    for (var n = 0; t.b.length > n; n++) try {
                        t.b[n](e)
                    } catch (t) {}
                }

                function ka(t) {
                    return t.f || (t.f = t.ka().then(function() {
                        return new yt(function(e) {
                            function n(i) {
                                return e(i), t.Qa(n), !1
                            }
                            t.Ca(n), Ca(t)
                        })
                    })), t.f
                }

                function Ea(t) {
                    var e = null;
                    return pa(t.g).then(function(n) {
                        return e = n, n = t.g, ca(n.b, mp, n.a)
                    }).then(function() {
                        return e
                    })
                }

                function Ca(t) {
                    function e(e) {
                        i = !0, o && o.cancel(), Ea(t).then(function(i) {
                            var o = n;
                            if (i && e && e.url) {
                                var r = null;
                                o = oi(e.url), -1 != o.indexOf("/__/auth/callback") && (r = Te(o), r = gn(Ie(r, "firebaseError") || null), r = (r = "object" == typeof r ? v(r) : null) ? new Ri(i.c, i.b, null, null, r, null, i.S()) : new Ri(i.c, i.b, o, i.f, null, null, i.S())), o = r || n
                            }
                            Na(t, o)
                        })
                    }
                    var n = new Ri("unknown", null, null, null, new m("no-auth-event")),
                        i = !1,
                        o = le(500).then(function() {
                            return Ea(t).then(function() {
                                i || Na(t, n)
                            })
                        }),
                        r = Nc.handleOpenURL;
                    Nc.handleOpenURL = function(t) {
                        if (0 == t.toLowerCase().indexOf(cn("BuildInfo.packageName", Nc).toLowerCase() + "://") && e({
                                url: t
                            }), "function" == typeof r) try {
                            r(t)
                        } catch (t) {}
                    }, Yh || (Yh = new Vi), Fi(e)
                }

                function Aa(t) {
                    this.a = t, this.b = ra()
                }

                function Oa(t) {
                    return t.b.set(Ip, "pending", t.a)
                }

                function Pa(t) {
                    return ca(t.b, Ip, t.a)
                }

                function xa(t) {
                    return t.b.get(Ip, t.a).then(function(t) {
                        return "pending" == t
                    })
                }

                function Ma(t, e, n) {
                    this.i = {}, this.w = 0, this.D = t, this.u = e, this.m = n, this.h = [], this.f = !1, this.l = f(this.s, this), this.b = new Wa, this.B = new Za, this.g = new Aa(this.u + ":" + this.m), this.c = {}, this.c.unknown = this.b, this.c.signInViaRedirect = this.b, this.c.linkViaRedirect = this.b, this.c.reauthViaRedirect = this.b, this.c.signInViaPopup = this.B, this.c.linkViaPopup = this.B, this.c.reauthViaPopup = this.B, this.a = La(this.D, this.u, this.m, Pc)
                }

                function La(t, e, n, o) {
                    var r = i.a.SDK_VERSION || null;
                    return Qe() ? new wa(t, e, n, r, o) : new wr(t, e, n, r, o)
                }

                function ja(t) {
                    t.f || (t.f = !0, t.a.Ca(t.l));
                    var e = t.a;
                    return t.a.ka().o(function(n) {
                        throw t.a == e && t.reset(), n
                    })
                }

                function Da(t) {
                    t.a.Ub() && ja(t).o(function(e) {
                        var n = new Ri("unknown", null, null, null, new m("operation-not-supported-in-this-environment"));
                        Fa(e) && t.s(n)
                    }), t.a.Qb() || Ka(t.b)
                }

                function Ra(t, e) {
                    A(t.h, e) || t.h.push(e), t.f || xa(t.g).then(function(e) {
                        e ? Pa(t.g).then(function() {
                            ja(t).o(function(e) {
                                var n = new Ri("unknown", null, null, null, new m("operation-not-supported-in-this-environment"));
                                Fa(e) && t.s(n)
                            })
                        }) : Da(t)
                    }).o(function() {
                        Da(t)
                    })
                }

                function Ua(t, e) {
                    P(t.h, function(t) {
                        return t == e
                    })
                }

                function Va(t, e, n, i, o, r, a) {
                    return t.a.Jb(e, n, i, function() {
                        t.f || (t.f = !0, t.a.Ca(t.l))
                    }, function() {
                        t.reset()
                    }, o, r, a)
                }

                function Fa(t) {
                    return !(!t || "auth/cordova-not-ready" != t.code)
                }

                function Ba(t, e, n, i, o) {
                    var r;
                    return Oa(t.g).then(function() {
                        return t.a.Kb(e, n, i, o).o(function(e) {
                            if (Fa(e)) throw new m("operation-not-supported-in-this-environment");
                            return r = e, Pa(t.g).then(function() {
                                throw r
                            })
                        }).then(function() {
                            return t.a.Xb() ? new yt(function() {}) : Pa(t.g).then(function() {
                                return t.pa()
                            }).then(function() {}).o(function() {})
                        })
                    })
                }

                function Ha(t, e, n, i, o) {
                    return t.a.Lb(i, function(t) {
                        e.la(n, null, t, o)
                    }, Tp.get())
                }

                function Ga(t, e, n) {
                    var i = e + ":" + n;
                    return kp[i] || (kp[i] = new Ma(t, e, n)), kp[i]
                }

                function Wa() {
                    this.b = null, this.f = [], this.c = [], this.a = null, this.i = this.g = !1
                }

                function Ka(t) {
                    t.g || (t.g = !0, Ya(t, !1, null, null))
                }

                function qa(t) {
                    t.g && !t.i && Ya(t, !1, null, null)
                }

                function za(t, e, n) {
                    n = n.Da(e.c, e.b);
                    var i = e.g,
                        o = e.f,
                        r = e.i,
                        a = e.S(),
                        s = !!e.c.match(/Redirect$/);
                    n(i, o, a, r).then(function(e) {
                        Ya(t, s, e, null)
                    }).o(function(e) {
                        Ya(t, s, null, e)
                    })
                }

                function Xa(t, e) {
                    if (t.b = function() {
                            return St(e)
                        }, t.c.length)
                        for (var n = 0; t.c.length > n; n++) t.c[n](e)
                }

                function Ja(t, e) {
                    if (t.b = function() {
                            return _t(e)
                        }, t.f.length)
                        for (var n = 0; t.f.length > n; n++) t.f[n](e)
                }

                function Ya(t, e, n, i) {
                    e ? i ? Xa(t, i) : Ja(t, n) : Ja(t, {
                        user: null
                    }), t.f = [], t.c = []
                }

                function $a(t) {
                    var e = new m("timeout");
                    t.a && t.a.cancel(), t.a = le(Np.get()).then(function() {
                        t.b || (t.g = !0, Ya(t, !0, null, e))
                    })
                }

                function Za() {}

                function Qa(t, e) {
                    var n = t.b,
                        i = t.c;
                    e.Da(i, n)(t.g, t.f, t.S(), t.i).then(function(t) {
                        e.la(i, t, null, n)
                    }).o(function(t) {
                        e.la(i, null, t, n)
                    })
                }

                function ts() {
                    this.Bb = !1, Object.defineProperty(this, "appVerificationDisabled", {
                        get: function() {
                            return this.Bb
                        },
                        set: function(t) {
                            this.Bb = t
                        },
                        enumerable: !1
                    })
                }

                function es(t, e) {
                    this.a = e, An(this, "verificationId", t)
                }

                function ns(t, e, n, i) {
                    return new Mi(t).cb(e, n).then(function(t) {
                        return new es(t, i)
                    })
                }

                function is(t) {
                    var e = Jn(t);
                    if (!(e && e.exp && e.auth_time && e.iat)) throw new m("internal-error", "An internal error occurred. The token obtained by Firebase appears to be malformed. Please retry the operation.");
                    On(this, {
                        token: t,
                        expirationTime: Tn(1e3 * e.exp),
                        authTime: Tn(1e3 * e.auth_time),
                        issuedAtTime: Tn(1e3 * e.iat),
                        signInProvider: e.firebase && e.firebase.sign_in_provider ? e.firebase.sign_in_provider : null,
                        signInSecondFactor: e.firebase && e.firebase.sign_in_second_factor ? e.firebase.sign_in_second_factor : null,
                        claims: e
                    })
                }

                function os(t, e, n) {
                    var i = e && e[Cp];
                    if (!i) throw new m("argument-error", "Internal assert: Invalid MultiFactorResolver");
                    this.a = t, this.f = V(e), this.g = n, this.c = new ri(null, i), this.b = [];
                    var o = this;
                    Uc(e[Ep] || [], function(t) {
                        (t = Dn(t)) && o.b.push(t)
                    }), An(this, "auth", this.a), An(this, "session", this.c), An(this, "hints", this.b)
                }

                function rs(t, e, n, i) {
                    m.call(this, "multi-factor-auth-required", i, e), this.b = new os(t, e, n), An(this, "resolver", this.b)
                }

                function as(t, e, n) {
                    if (t && u(t.serverResponse) && "auth/multi-factor-auth-required" === t.code) try {
                        return new rs(e, t.serverResponse, n, t.message)
                    } catch (t) {}
                    return null
                }

                function ss() {}

                function us(t, e, n, i) {
                    return n.Fa().then(function(n) {
                        return n = {
                            idToken: n
                        }, void 0 !== i && (n.displayName = i), F(n, {
                            phoneVerificationInfo: xi(t.a)
                        }), cr(e, Of, n)
                    })
                }

                function cs(t, e, n) {
                    return n.Fa().then(function(n) {
                        return n = {
                            mfaPendingCredential: n
                        }, F(n, {
                            phoneVerificationInfo: xi(t.a)
                        }), cr(e, Pf, n)
                    })
                }

                function ls(t) {
                    An(this, "factorId", t.ea), this.a = t
                }

                function hs(t) {
                    if (ls.call(this, t), this.a.ea != Mi.PROVIDER_ID) throw new m("argument-error", "firebase.auth.PhoneMultiFactorAssertion requires a valid firebase.auth.PhoneAuthCredential")
                }

                function fs(t, e) {
                    Ft.call(this, t);
                    for (var n in e) this[n] = e[n]
                }

                function ps(t, e) {
                    this.a = t, this.b = [], this.c = f(this.wc, this), zt(this.a, "userReloaded", this.c);
                    var n = [];
                    e && e.multiFactor && e.multiFactor.enrolledFactors && Uc(e.multiFactor.enrolledFactors, function(t) {
                        var e = null,
                            i = {};
                        if (t) {
                            t.uid && (i[hh] = t.uid), t.displayName && (i[ch] = t.displayName), t.enrollmentTime && (i[lh] = new Date(t.enrollmentTime).toISOString()), t.phoneNumber && (i[fh] = t.phoneNumber);
                            try {
                                e = new Rn(i)
                            } catch (t) {}
                            t = e
                        } else t = null;
                        t && n.push(t)
                    }), ms(this, n)
                }

                function ds(t) {
                    var e = [];
                    return Uc(t.mfaInfo || [], function(t) {
                        (t = Dn(t)) && e.push(t)
                    }), e
                }

                function ms(t, e) {
                    t.b = e, An(t, "enrolledFactors", e)
                }

                function vs(t, e, n) {
                    if (this.h = t, this.i = e, this.g = n, this.c = 3e4, this.f = 96e4, this.b = null, this.a = this.c, this.c > this.f) throw Error("Proactive refresh lower bound greater than upper bound!")
                }

                function gs(t, e) {
                    return e ? (t.a = t.c, t.g()) : (e = t.a, t.a *= 2, t.a > t.f && (t.a = t.f), e)
                }

                function ys(t, e) {
                    t.stop(), t.b = le(gs(t, e)).then(function() {
                        return In()
                    }).then(function() {
                        return t.h()
                    }).then(function() {
                        ys(t, !0)
                    }).o(function(e) {
                        t.i(e) && ys(t, !1)
                    })
                }

                function bs(t) {
                    this.c = t, this.b = this.a = null
                }

                function ws(t) {
                    return t.b && 1e3 * t.b.c || 0
                }

                function _s(t, e) {
                    var n = e.refreshToken;
                    t.b = Xn(e[df] || ""), t.a = n
                }

                function Ss(t, e) {
                    t.b = e.b, t.a = e.a
                }

                function Is(t, e) {
                    return Go(t.c, e).then(function(e) {
                        return t.b = Xn(e.access_token), t.a = e.refresh_token, {
                            accessToken: "" + t.b,
                            refreshToken: t.a
                        }
                    }).o(function(e) {
                        throw "auth/user-token-expired" == e.code && (t.a = null), e
                    })
                }

                function Ts(t, e) {
                    this.a = t || null, this.b = e || null, On(this, {
                        lastSignInTime: Tn(e || null),
                        creationTime: Tn(t || null)
                    })
                }

                function Ns(t) {
                    return new Ts(t.a, t.b)
                }

                function ks(t, e, n, i, o, r) {
                    On(this, {
                        uid: t,
                        displayName: i || null,
                        photoURL: o || null,
                        email: n || null,
                        phoneNumber: r || null,
                        providerId: e
                    })
                }

                function Es(t, e, n) {
                    this.N = [], this.l = t.apiKey, this.m = t.appName, this.s = t.authDomain || null, t = i.a.SDK_VERSION ? sn(i.a.SDK_VERSION) : null, this.a = new Uo(this.l, g(Pc), t), this.b = new bs(this.a), js(this, e[df]), _s(this.b, e), An(this, "refreshToken", this.b.a), Vs(this, n || {}), re.call(this), this.P = !1, this.s && hn() && (this.i = Ga(this.s, this.l, this.m)), this.R = [], this.h = null, this.B = xs(this), this.Z = f(this.Ma, this);
                    var o = this;
                    this.oa = null, this.za = function(t) {
                        o.va(t.g)
                    }, this.aa = null, this.W = [], this.ya = function(t) {
                        As(o, t.c)
                    }, this.$ = null, this.O = new ps(this, n), An(this, "multiFactor", this.O)
                }

                function Cs(t, e) {
                    t.aa && $t(t.aa, "languageCodeChanged", t.za), (t.aa = e) && zt(e, "languageCodeChanged", t.za)
                }

                function As(t, e) {
                    t.W = e, Fo(t.a, i.a.SDK_VERSION ? sn(i.a.SDK_VERSION, t.W) : null)
                }

                function Os(t, e) {
                    t.$ && $t(t.$, "frameworkChanged", t.ya), (t.$ = e) && zt(e, "frameworkChanged", t.ya)
                }

                function Ps(t) {
                    try {
                        return i.a.app(t.m).auth()
                    } catch (e) {
                        throw new m("internal-error", "No firebase.auth.Auth instance is available for the Firebase App '" + t.m + "'!")
                    }
                }

                function xs(t) {
                    return new vs(function() {
                        return t.I(!0)
                    }, function(t) {
                        return !(!t || "auth/network-request-failed" != t.code)
                    }, function() {
                        var e = ws(t.b) - Oc() - 3e5;
                        return e > 0 ? e : 0
                    })
                }

                function Ms(t) {
                    t.D || t.B.b || (t.B.start(), $t(t, "tokenChanged", t.Z), zt(t, "tokenChanged", t.Z))
                }

                function Ls(t) {
                    $t(t, "tokenChanged", t.Z), t.B.stop()
                }

                function js(t, e) {
                    t.xa = e, An(t, "_lat", e)
                }

                function Ds(t, e) {
                    P(t.R, function(t) {
                        return t == e
                    })
                }

                function Rs(t) {
                    for (var e = [], n = 0; t.R.length > n; n++) e.push(t.R[n](t));
                    return Nt(e).then(function() {
                        return t
                    })
                }

                function Us(t) {
                    t.i && !t.P && (t.P = !0, Ra(t.i, t))
                }

                function Vs(t, e) {
                    On(t, {
                        uid: e.uid,
                        displayName: e.displayName || null,
                        photoURL: e.photoURL || null,
                        email: e.email || null,
                        emailVerified: e.emailVerified || !1,
                        phoneNumber: e.phoneNumber || null,
                        isAnonymous: e.isAnonymous || !1,
                        tenantId: e.tenantId || null,
                        metadata: new Ts(e.createdAt, e.lastLoginAt),
                        providerData: []
                    }), t.a.b = t.tenantId
                }

                function Fs() {}

                function Bs(t) {
                    return _t().then(function() {
                        if (t.D) throw new m("app-deleted")
                    })
                }

                function Hs(t) {
                    return Fc(t.providerData, function(t) {
                        return t.providerId
                    })
                }

                function Gs(t, e) {
                    e && (Ws(t, e.providerId), t.providerData.push(e))
                }

                function Ws(t, e) {
                    P(t.providerData, function(t) {
                        return t.providerId == e
                    })
                }

                function Ks(t, e, n) {
                    ("uid" != e || n) && t.hasOwnProperty(e) && An(t, e, n)
                }

                function qs(t, e) {
                    t != e && (On(t, {
                        uid: e.uid,
                        displayName: e.displayName,
                        photoURL: e.photoURL,
                        email: e.email,
                        emailVerified: e.emailVerified,
                        phoneNumber: e.phoneNumber,
                        isAnonymous: e.isAnonymous,
                        tenantId: e.tenantId,
                        providerData: []
                    }), e.metadata ? An(t, "metadata", Ns(e.metadata)) : An(t, "metadata", new Ts), Uc(e.providerData, function(e) {
                        Gs(t, e)
                    }), Ss(t.b, e.b), An(t, "refreshToken", t.b.a), ms(t.O, e.O.b))
                }

                function zs(t) {
                    return t.I().then(function(e) {
                        var n = t.isAnonymous;
                        return Js(t, e).then(function() {
                            return n || Ks(t, "isAnonymous", !1), e
                        })
                    })
                }

                function Xs(t, e) {
                    e[df] && t.xa != e[df] && (_s(t.b, e), t.dispatchEvent(new fs("tokenChanged")), js(t, e[df]), Ks(t, "refreshToken", t.b.a))
                }

                function Js(t, e) {
                    return cr(t.a, xf, {
                        idToken: e
                    }).then(f(t.Ic, t))
                }

                function Ys(t) {
                    return (t = t.providerUserInfo) && t.length ? Fc(t, function(t) {
                        return new ks(t.rawId, t.providerId, t.email, t.displayName, t.photoUrl, t.phoneNumber)
                    }) : []
                }

                function $s(t, e) {
                    return zs(t).then(function() {
                        if (A(Hs(t), e)) return Rs(t).then(function() {
                            throw new m("provider-already-linked")
                        })
                    })
                }

                function Zs(t, e, n) {
                    var i = ji(e);
                    return e = $n(e), Pn({
                        user: t,
                        credential: i,
                        additionalUserInfo: e,
                        operationType: n
                    })
                }

                function Qs(t, e) {
                    return Xs(t, e), t.reload().then(function() {
                        return t
                    })
                }

                function tu(t, e, n, o, r) {
                    if (!hn()) return St(new m("operation-not-supported-in-this-environment"));
                    if (t.h && !r) return St(t.h);
                    var a = Yn(n.providerId),
                        s = yn(t.uid + ":::"),
                        u = null;
                    (!dn() || tn()) && t.s && n.isOAuthProvider && (u = Tr(t.s, t.l, t.m, e, n, null, s, i.a.SDK_VERSION || null, null, null, t.tenantId));
                    var c = Je(u, a && a.ta, a && a.sa);
                    return o = o().then(function() {
                        if (nu(t), !r) return t.I().then(function() {})
                    }).then(function() {
                        return Va(t.i, c, e, n, s, !!u, t.tenantId)
                    }).then(function() {
                        return new yt(function(n, i) {
                            t.la(e, null, new m("cancelled-popup-request"), t.g || null), t.f = n, t.w = i, t.g = s, t.c = Ha(t.i, t, e, c, s)
                        })
                    }).then(function(t) {
                        return c && Xe(c), t ? Pn(t) : null
                    }).o(function(t) {
                        throw c && Xe(c), t
                    }), iu(t, o, r)
                }

                function eu(t, e, n, i, o) {
                    if (!hn()) return St(new m("operation-not-supported-in-this-environment"));
                    if (t.h && !o) return St(t.h);
                    var r = null,
                        a = yn(t.uid + ":::");
                    return i = i().then(function() {
                        if (nu(t), !o) return t.I().then(function() {})
                    }).then(function() {
                        return t.fa = a, Rs(t)
                    }).then(function(e) {
                        return t.ga && (e = t.ga, e = e.b.set(Ap, t.v(), e.a)), e
                    }).then(function() {
                        return Ba(t.i, e, n, a, t.tenantId)
                    }).o(function(e) {
                        if (r = e, t.ga) return cu(t.ga);
                        throw r
                    }).then(function() {
                        if (r) throw r
                    }), iu(t, i, o)
                }

                function nu(t) {
                    if (!t.i || !t.P) {
                        if (t.i && !t.P) throw new m("internal-error");
                        throw new m("auth-domain-config-required")
                    }
                }

                function iu(t, e, n) {
                    var i = ou(t, e, n);
                    return t.N.push(i), i.ma(function() {
                        O(t.N, i)
                    }), i.o(function(e) {
                        var n = null;
                        throw e && "auth/multi-factor-auth-required" === e.code && (n = as(e.v(), Ps(t), f(t.hc, t))), n || e
                    })
                }

                function ou(t, e, n) {
                    return t.h && !n ? (e.cancel(), St(t.h)) : e.o(function(e) {
                        throw !e || "auth/user-disabled" != e.code && "auth/user-token-expired" != e.code || (t.h || t.dispatchEvent(new fs("userInvalidated")), t.h = e), e
                    })
                }

                function ru(t) {
                    if (!t.apiKey) return null;
                    var e = {
                            apiKey: t.apiKey,
                            authDomain: t.authDomain,
                            appName: t.appName
                        },
                        n = {};
                    if (!t.stsTokenManager || !t.stsTokenManager.accessToken) return null;
                    n[df] = t.stsTokenManager.accessToken, n.refreshToken = t.stsTokenManager.refreshToken || null;
                    var i = new Es(e, n, t);
                    return t.providerData && Uc(t.providerData, function(t) {
                        t && Gs(i, Pn(t))
                    }), t.redirectEventId && (i.fa = t.redirectEventId), i
                }

                function au(t, e, n, i) {
                    var o = new Es(t, e);
                    return n && (o.ga = n), i && As(o, i), o.reload().then(function() {
                        return o
                    })
                }

                function su(t, e, n, i) {
                    var o = t.b,
                        r = {};
                    return r[df] = o.b && "" + o.b, r.refreshToken = o.a, e = new Es(e || {
                        apiKey: t.l,
                        authDomain: t.s,
                        appName: t.m
                    }, r), n && (e.ga = n), i && As(e, i), qs(e, t), e
                }

                function uu(t) {
                    this.a = t, this.b = ra()
                }

                function cu(t) {
                    return ca(t.b, Ap, t.a)
                }

                function lu(t, e) {
                    return t.b.get(Ap, t.a).then(function(t) {
                        return t && e && (t.authDomain = e), ru(t || {})
                    })
                }

                function hu(t) {
                    this.a = t, this.b = ra(), this.c = null, this.f = pu(this), this.b.addListener(du("local"), this.a, f(this.g, this))
                }

                function fu(t, e) {
                    var n, i = [];
                    for (n in pp) pp[n] !== e && i.push(ca(t.b, du(pp[n]), t.a));
                    return i.push(ca(t.b, Op, t.a)), Tt(i)
                }

                function pu(t) {
                    var e = du("local"),
                        n = du("session"),
                        i = du("none");
                    return ua(t.b, e, t.a).then(function() {
                        return t.b.get(n, t.a)
                    }).then(function(o) {
                        return o ? n : t.b.get(i, t.a).then(function(n) {
                            return n ? i : t.b.get(e, t.a).then(function(n) {
                                return n ? e : t.b.get(Op, t.a).then(function(t) {
                                    return t ? du(t) : e
                                })
                            })
                        })
                    }).then(function(e) {
                        return t.c = e, fu(t, e.F)
                    }).o(function() {
                        t.c || (t.c = e)
                    })
                }

                function du(t) {
                    return {
                        name: "authUser",
                        F: t
                    }
                }

                function mu(t) {
                    return bu(t, function() {
                        return t.b.set(Op, t.c.F, t.a)
                    })
                }

                function vu(t, e) {
                    return bu(t, function() {
                        return t.b.set(t.c, e.v(), t.a)
                    })
                }

                function gu(t) {
                    return bu(t, function() {
                        return ca(t.b, t.c, t.a)
                    })
                }

                function yu(t, e) {
                    return bu(t, function() {
                        return t.b.get(t.c, t.a).then(function(t) {
                            return t && e && (t.authDomain = e), ru(t || {})
                        })
                    })
                }

                function bu(t, e) {
                    return t.f = t.f.then(e, e)
                }

                function wu(t) {
                    if (this.l = !1, An(this, "settings", new ts), An(this, "app", t), !Mu(this).options || !Mu(this).options.apiKey) throw new m("invalid-api-key");
                    t = i.a.SDK_VERSION ? sn(i.a.SDK_VERSION) : null, this.b = new Uo(Mu(this).options && Mu(this).options.apiKey, g(Pc), t), this.P = [], this.m = [], this.O = [], this.$b = i.a.INTERNAL.createSubscribe(f(this.xc, this)), this.W = void 0, this.ac = i.a.INTERNAL.createSubscribe(f(this.yc, this)), Cu(this, null), this.i = new hu(Mu(this).options.apiKey + ":" + Mu(this).name), this.B = new uu(Mu(this).options.apiKey + ":" + Mu(this).name), this.Z = Uu(this, Ou(this)), this.h = Uu(this, Pu(this)), this.aa = !1, this.oa = f(this.Xc, this), this.Ma = f(this.ca, this), this.xa = f(this.jc, this), this.ya = f(this.uc, this), this.za = f(this.vc, this), this.a = null, Nu(this), this.INTERNAL = {}, this.INTERNAL.delete = f(this.delete, this), this.INTERNAL.logFramework = f(this.Ec, this), this.s = 0, re.call(this), Iu(this), this.N = []
                }

                function _u(t) {
                    Ft.call(this, "languageCodeChanged"), this.g = t
                }

                function Su(t) {
                    Ft.call(this, "frameworkChanged"), this.c = t
                }

                function Iu(t) {
                    Object.defineProperty(t, "lc", {
                        get: function() {
                            return this.ja()
                        },
                        set: function(t) {
                            this.va(t)
                        },
                        enumerable: !1
                    }), t.$ = null, Object.defineProperty(t, "ti", {
                        get: function() {
                            return this.S()
                        },
                        set: function(t) {
                            this.ub(t)
                        },
                        enumerable: !1
                    }), t.R = null
                }

                function Tu(t) {
                    return t.Zb || St(new m("auth-domain-config-required"))
                }

                function Nu(t) {
                    var e = Mu(t).options.authDomain,
                        n = Mu(t).options.apiKey;
                    e && hn() && (t.Zb = t.Z.then(function() {
                        if (!t.l) {
                            if (t.a = Ga(e, n, Mu(t).name), Ra(t.a, t), Lu(t) && Us(Lu(t)), t.D) {
                                Us(t.D);
                                var i = t.D;
                                i.va(t.ja()), Cs(i, t), i = t.D, As(i, t.N), Os(i, t), t.D = null
                            }
                            return t.a
                        }
                    }))
                }

                function ku(t) {
                    if (!hn()) return St(new m("operation-not-supported-in-this-environment"));
                    var e = Tu(t).then(function() {
                        return t.a.pa()
                    }).then(function(t) {
                        return t ? Pn(t) : null
                    });
                    return Uu(t, e)
                }

                function Eu(t, e) {
                    var n = {};
                    return n.apiKey = Mu(t).options.apiKey, n.authDomain = Mu(t).options.authDomain, n.appName = Mu(t).name, t.Z.then(function() {
                        return au(n, e, t.B, t.Ea())
                    }).then(function(e) {
                        return Lu(t) && e.uid == Lu(t).uid ? (qs(Lu(t), e), t.ca(e)) : (Cu(t, e), Us(e), t.ca(e))
                    }).then(function() {
                        Du(t)
                    })
                }

                function Cu(t, e) {
                    Lu(t) && (Ds(Lu(t), t.Ma), $t(Lu(t), "tokenChanged", t.xa), $t(Lu(t), "userDeleted", t.ya), $t(Lu(t), "userInvalidated", t.za), Ls(Lu(t))), e && (e.R.push(t.Ma), zt(e, "tokenChanged", t.xa), zt(e, "userDeleted", t.ya), zt(e, "userInvalidated", t.za), t.s > 0 && Ms(e)), An(t, "currentUser", e), e && (e.va(t.ja()), Cs(e, t), As(e, t.N), Os(e, t))
                }

                function Au(t) {
                    var e = lu(t.B, Mu(t).options.authDomain).then(function(e) {
                        return (t.D = e) && (e.ga = t.B), cu(t.B)
                    });
                    return Uu(t, e)
                }

                function Ou(t) {
                    var e = Mu(t).options.authDomain,
                        n = Au(t).then(function() {
                            return yu(t.i, e)
                        }).then(function(e) {
                            return e ? (e.ga = t.B, t.D && (t.D.fa || null) == (e.fa || null) ? e : e.reload().then(function() {
                                return vu(t.i, e).then(function() {
                                    return e
                                })
                            }).o(function(n) {
                                return "auth/network-request-failed" == n.code ? e : gu(t.i)
                            })) : null
                        }).then(function(e) {
                            Cu(t, e || null)
                        });
                    return Uu(t, n)
                }

                function Pu(t) {
                    return t.Z.then(function() {
                        return ku(t)
                    }).o(function() {}).then(function() {
                        if (!t.l) return t.oa()
                    }).o(function() {}).then(function() {
                        if (!t.l) {
                            t.aa = !0;
                            var e = t.i;
                            e.b.addListener(du("local"), e.a, t.oa)
                        }
                    })
                }

                function xu(t, e) {
                    var n = null,
                        i = null;
                    return Uu(t, e.then(function(e) {
                        return n = ji(e), i = $n(e), Eu(t, e)
                    }, function(e) {
                        var n = null;
                        throw e && "auth/multi-factor-auth-required" === e.code && (n = as(e.v(), t, f(t.ic, t))), n || e
                    }).then(function() {
                        return Pn({
                            user: Lu(t),
                            credential: n,
                            additionalUserInfo: i,
                            operationType: "signIn"
                        })
                    }))
                }

                function Mu(t) {
                    return t.app
                }

                function Lu(t) {
                    return t.currentUser
                }

                function ju(t) {
                    return Lu(t) && Lu(t)._lat || null
                }

                function Du(t) {
                    if (t.aa) {
                        for (var e = 0; t.m.length > e; e++) t.m[e] && t.m[e](ju(t));
                        if (t.W !== t.getUid() && t.O.length)
                            for (t.W = t.getUid(), e = 0; t.O.length > e; e++) t.O[e] && t.O[e](ju(t))
                    }
                }

                function Ru(t, e) {
                    t.O.push(e), Uu(t, t.h.then(function() {
                        !t.l && A(t.O, e) && t.W !== t.getUid() && (t.W = t.getUid(), e(ju(t)))
                    }))
                }

                function Uu(t, e) {
                    return t.P.push(e), e.ma(function() {
                        O(t.P, e)
                    }), e
                }

                function Vu() {}

                function Fu() {
                    this.a = {}, this.b = 1e12
                }

                function Bu(t, e) {
                    return (e = Hu(e)) ? t.a[e] || null : null
                }

                function Hu(t) {
                    return (t = void 0 === t ? 1e12 : t) ? "" + t : null
                }

                function Gu(t, e) {
                    this.g = !1, this.c = e, this.a = this.b = null, this.h = "invisible" !== this.c.size, this.f = st(t);
                    var n = this;
                    this.i = function() {
                        n.execute()
                    }, this.h ? this.execute() : zt(this.f, "click", this.i)
                }

                function Wu(t) {
                    if (t.g) throw Error("reCAPTCHA mock was already deleted!")
                }

                function Ku() {}

                function qu() {}

                function zu() {
                    this.b = Nc.grecaptcha ? 1 / 0 : 0, this.f = null, this.a = "__rcb" + Math.floor(1e6 * Math.random())
                }

                function Xu(t, e, n, i, o, r, a) {
                    if (An(this, "type", "recaptcha"), this.c = this.f = null, this.D = !1, this.u = e, this.g = null, a ? (xp || (xp = new qu), a = xp) : (jp || (jp = new zu), a = jp), this.m = a, this.a = n || {
                            theme: "light",
                            type: "image"
                        }, this.h = [], this.a[Up]) throw new m("argument-error", "sitekey should not be provided for reCAPTCHA as one is automatically provisioned for the current project.");
                    if (this.i = "invisible" === this.a[Vp], !Nc.document) throw new m("operation-not-supported-in-this-environment", "RecaptchaVerifier is only supported in a browser HTTP/HTTPS environment with DOM support.");
                    if (!st(e) || !this.i && st(e).hasChildNodes()) throw new m("argument-error", "reCAPTCHA container is either not found or already contains inner elements!");
                    this.s = new Uo(t, r || null, o || null), this.w = i || function() {
                        return null
                    };
                    var s = this;
                    this.l = [];
                    var u = this.a[Dp];
                    this.a[Dp] = function(t) {
                        if (Ju(s, t), "function" == typeof u) u(t);
                        else if ("string" == typeof u) {
                            var e = cn(u, Nc);
                            "function" == typeof e && e(t)
                        }
                    };
                    var c = this.a[Rp];
                    this.a[Rp] = function() {
                        if (Ju(s, null), "function" == typeof c) c();
                        else if ("string" == typeof c) {
                            var t = cn(c, Nc);
                            "function" == typeof t && t()
                        }
                    }
                }

                function Ju(t, e) {
                    for (var n = 0; t.l.length > n; n++) try {
                        t.l[n](e)
                    } catch (t) {}
                }

                function Yu(t, e) {
                    P(t.l, function(t) {
                        return t == e
                    })
                }

                function $u(t, e) {
                    return t.h.push(e), e.ma(function() {
                        O(t.h, e)
                    }), e
                }

                function Zu(t) {
                    if (t.D) throw new m("internal-error", "RecaptchaVerifier instance has been destroyed.")
                }

                function Qu(t, e, n) {
                    var o = !1;
                    try {
                        this.b = n || i.a.app()
                    } catch (t) {
                        throw new m("argument-error", "No firebase.app.App instance is currently initialized.")
                    }
                    if (!this.b.options || !this.b.options.apiKey) throw new m("invalid-api-key");
                    n = this.b.options.apiKey;
                    var r = this,
                        a = null;
                    try {
                        a = this.b.auth().Ea()
                    } catch (t) {}
                    try {
                        o = this.b.auth().settings.appVerificationDisabledForTesting
                    } catch (t) {}
                    a = i.a.SDK_VERSION ? sn(i.a.SDK_VERSION, a) : null, Xu.call(this, n, t, e, function() {
                        try {
                            var t = r.b.auth().ja()
                        } catch (e) {
                            t = null
                        }
                        return t
                    }, a, g(Pc), o)
                }

                function tc(t, e, n, i) {
                    t: {
                        n = Array.prototype.slice.call(n);
                        for (var o = 0, r = !1, a = 0; e.length > a; a++)
                            if (e[a].optional) r = !0;
                            else {
                                if (r) throw new m("internal-error", "Argument validator encountered a required argument after an optional argument.");
                                o++
                            } if (r = e.length, o > n.length || n.length > r) i = "Expected " + (o == r ? 1 == o ? "1 argument" : o + " arguments" : o + "-" + r + " arguments") + " but got " + n.length + ".";
                        else {
                            for (o = 0; n.length > o; o++)
                                if (r = e[o].optional && void 0 === n[o], !e[o].K(n[o]) && !r) {
                                    if (e = e[o], 0 > o || o >= Fp.length) throw new m("internal-error", "Argument validator received an unsupported number of arguments.");
                                    n = Fp[o], i = (i ? "" : n + " argument ") + (e.name ? '"' + e.name + '" ' : "") + "must be " + e.J + ".";
                                    break t
                                } i = null
                        }
                    }
                    if (i) throw new m("argument-error", t + " failed: " + i)
                }

                function ec(t, e) {
                    return {
                        name: t || "",
                        J: "a valid string",
                        optional: !!e,
                        K: function(t) {
                            return "string" == typeof t
                        }
                    }
                }

                function nc(t, e) {
                    return {
                        name: t || "",
                        J: "a boolean",
                        optional: !!e,
                        K: function(t) {
                            return "boolean" == typeof t
                        }
                    }
                }

                function ic(t, e) {
                    return {
                        name: t || "",
                        J: "a valid object",
                        optional: !!e,
                        K: u
                    }
                }

                function oc(t, e) {
                    return {
                        name: t || "",
                        J: "a function",
                        optional: !!e,
                        K: s
                    }
                }

                function rc(t, e) {
                    return {
                        name: t || "",
                        J: "null",
                        optional: !!e,
                        K: function(t) {
                            return null === t
                        }
                    }
                }

                function ac() {
                    return {
                        name: "",
                        J: "an HTML element",
                        optional: !1,
                        K: function(t) {
                            return !!(t && t instanceof Element)
                        }
                    }
                }

                function sc() {
                    return {
                        name: "auth",
                        J: "an instance of Firebase Auth",
                        optional: !0,
                        K: function(t) {
                            return !!(t && t instanceof wu)
                        }
                    }
                }

                function uc() {
                    return {
                        name: "app",
                        J: "an instance of Firebase App",
                        optional: !0,
                        K: function(t) {
                            return !!(t && t instanceof i.a.app.App)
                        }
                    }
                }

                function cc(t) {
                    return {
                        name: t ? t + "Credential" : "credential",
                        J: t ? "a valid " + t + " credential" : "a valid credential",
                        optional: !1,
                        K: function(e) {
                            if (!e) return !1;
                            var n = !t || e.providerId === t;
                            return !(!e.ia || !n)
                        }
                    }
                }

                function lc() {
                    return {
                        name: "multiFactorAssertion",
                        J: "a valid multiFactorAssertion",
                        optional: !1,
                        K: function(t) {
                            return !!t && !!t.ob
                        }
                    }
                }

                function hc() {
                    return {
                        name: "authProvider",
                        J: "a valid Auth provider",
                        optional: !1,
                        K: function(t) {
                            return !!(t && t.providerId && t.hasOwnProperty && t.hasOwnProperty("isOAuthProvider"))
                        }
                    }
                }

                function fc(t, e) {
                    return u(t) && "string" == typeof t.type && t.type === e && s(t.Fa)
                }

                function pc(t) {
                    return u(t) && "string" == typeof t.uid
                }

                function dc() {
                    return {
                        name: "applicationVerifier",
                        J: "an implementation of firebase.auth.ApplicationVerifier",
                        optional: !1,
                        K: function(t) {
                            return !(!t || "string" != typeof t.type || !s(t.verify))
                        }
                    }
                }

                function mc(t, e, n, i) {
                    return {
                        name: n || "",
                        J: t.J + " or " + e.J,
                        optional: !!i,
                        K: function(n) {
                            return t.K(n) || e.K(n)
                        }
                    }
                }

                function vc(t, e) {
                    for (var n in e) {
                        var i = e[n].name;
                        t[i] = bc(i, t[n], e[n].j)
                    }
                }

                function gc(t, e) {
                    for (var n in e) {
                        var i = e[n].name;
                        i !== n && Object.defineProperty(t, i, {
                            get: p(function(t) {
                                return this[t]
                            }, n),
                            set: p(function(t, e, n, i) {
                                tc(t, [n], [i], !0), this[e] = i
                            }, i, n, e[n].gb),
                            enumerable: !0
                        })
                    }
                }

                function yc(t, e, n, i) {
                    t[e] = bc(e, n, i)
                }

                function bc(t, e, n) {
                    function i() {
                        var t = Array.prototype.slice.call(arguments);
                        return tc(r, n, t), e.apply(this, t)
                    }
                    if (!n) return e;
                    var o, r = wc(t);
                    for (o in e) i[o] = e[o];
                    for (o in e.prototype) i.prototype[o] = e.prototype[o];
                    return i
                }

                function wc(t) {
                    return t = t.split("."), t[t.length - 1]
                }
                var _c, Sc = "function" == typeof Object.defineProperties ? Object.defineProperty : function(t, e, n) {
                        t != Array.prototype && t != Object.prototype && (t[e] = n.value)
                    },
                    Ic = function(e) {
                        e = ["object" == typeof window && window, "object" == typeof self && self, "object" == typeof t && t, e];
                        for (var n = 0; e.length > n; ++n) {
                            var i = e[n];
                            if (i && i.Math == Math) return i
                        }
                        return globalThis
                    }(this);
                ! function(t, e) {
                    if (e) {
                        var n = Ic;
                        t = t.split(".");
                        for (var i = 0; t.length - 1 > i; i++) {
                            var o = t[i];
                            o in n || (n[o] = {}), n = n[o]
                        }
                        t = t[t.length - 1], i = n[t], (e = e(i)) != i && null != e && Sc(n, t, {
                            configurable: !0,
                            writable: !0,
                            value: e
                        })
                    }
                }("Promise", function(t) {
                    function e(t) {
                        this.b = 0, this.c = void 0, this.a = [];
                        var e = this.f();
                        try {
                            t(e.resolve, e.reject)
                        } catch (t) {
                            e.reject(t)
                        }
                    }

                    function i() {
                        this.a = null
                    }

                    function o(t) {
                        return t instanceof e ? t : new e(function(e) {
                            e(t)
                        })
                    }
                    if (t) return t;
                    i.prototype.b = function(t) {
                        if (null == this.a) {
                            this.a = [];
                            var e = this;
                            this.c(function() {
                                e.g()
                            })
                        }
                        this.a.push(t)
                    };
                    var r = Ic.setTimeout;
                    i.prototype.c = function(t) {
                        r(t, 0)
                    }, i.prototype.g = function() {
                        for (; this.a && this.a.length;) {
                            var t = this.a;
                            this.a = [];
                            for (var e = 0; t.length > e; ++e) {
                                var n = t[e];
                                t[e] = null;
                                try {
                                    n()
                                } catch (t) {
                                    this.f(t)
                                }
                            }
                        }
                        this.a = null
                    }, i.prototype.f = function(t) {
                        this.c(function() {
                            throw t
                        })
                    }, e.prototype.f = function() {
                        function t(t) {
                            return function(i) {
                                n || (n = !0, t.call(e, i))
                            }
                        }
                        var e = this,
                            n = !1;
                        return {
                            resolve: t(this.m),
                            reject: t(this.g)
                        }
                    }, e.prototype.m = function(t) {
                        if (t === this) this.g(new TypeError("A Promise cannot resolve to itself"));
                        else if (t instanceof e) this.s(t);
                        else {
                            t: switch (typeof t) {
                                case "object":
                                    var n = null != t;
                                    break t;
                                case "function":
                                    n = !0;
                                    break t;
                                default:
                                    n = !1
                            }
                            n ? this.u(t) : this.h(t)
                        }
                    }, e.prototype.u = function(t) {
                        var e = void 0;
                        try {
                            e = t.then
                        } catch (t) {
                            return void this.g(t)
                        }
                        "function" == typeof e ? this.w(e, t) : this.h(t)
                    }, e.prototype.g = function(t) {
                        this.i(2, t)
                    }, e.prototype.h = function(t) {
                        this.i(1, t)
                    }, e.prototype.i = function(t, e) {
                        if (0 != this.b) throw Error("Cannot settle(" + t + ", " + e + "): Promise already settled in state" + this.b);
                        this.b = t, this.c = e, this.l()
                    }, e.prototype.l = function() {
                        if (null != this.a) {
                            for (var t = 0; this.a.length > t; ++t) a.b(this.a[t]);
                            this.a = null
                        }
                    };
                    var a = new i;
                    return e.prototype.s = function(t) {
                        var e = this.f();
                        t.Oa(e.resolve, e.reject)
                    }, e.prototype.w = function(t, e) {
                        var n = this.f();
                        try {
                            t.call(e, n.resolve, n.reject)
                        } catch (t) {
                            n.reject(t)
                        }
                    }, e.prototype.then = function(t, n) {
                        function i(t, e) {
                            return "function" == typeof t ? function(e) {
                                try {
                                    o(t(e))
                                } catch (t) {
                                    r(t)
                                }
                            } : e
                        }
                        var o, r, a = new e(function(t, e) {
                            o = t, r = e
                        });
                        return this.Oa(i(t, o), i(n, r)), a
                    }, e.prototype.catch = function(t) {
                        return this.then(void 0, t)
                    }, e.prototype.Oa = function(t, e) {
                        function n() {
                            switch (i.b) {
                                case 1:
                                    t(i.c);
                                    break;
                                case 2:
                                    e(i.c);
                                    break;
                                default:
                                    throw Error("Unexpected state: " + i.b)
                            }
                        }
                        var i = this;
                        null == this.a ? a.b(n) : this.a.push(n)
                    }, e.resolve = o, e.reject = function(t) {
                        return new e(function(e, n) {
                            n(t)
                        })
                    }, e.race = function(t) {
                        return new e(function(e, i) {
                            for (var r = n(t), a = r.next(); !a.done; a = r.next()) o(a.value).Oa(e, i)
                        })
                    }, e.all = function(t) {
                        var i = n(t),
                            r = i.next();
                        return r.done ? o([]) : new e(function(t, e) {
                            var n = [],
                                a = 0;
                            do {
                                n.push(void 0), a++, o(r.value).Oa(function(e) {
                                    return function(i) {
                                        n[e] = i, 0 == --a && t(n)
                                    }
                                }(n.length - 1), e), r = i.next()
                            } while (!r.done)
                        })
                    }, e
                });
                var Tc = Tc || {},
                    Nc = this || self,
                    kc = /^[\w+\/_-]+[=]{0,2}$/,
                    Ec = null,
                    Cc = "closure_uid_" + (1e9 * Math.random() >>> 0),
                    Ac = 0,
                    Oc = Date.now || function() {
                        return +new Date
                    };
                d(m, Error), m.prototype.v = function() {
                    var t = {
                        code: this.code,
                        message: this.message
                    };
                    return this.a && (t.serverResponse = this.a), t
                }, m.prototype.toJSON = function() {
                    return this.v()
                };
                var Pc, xc = "auth/index.html",
                    Mc = {
                        "admin-restricted-operation": "This operation is restricted to administrators only.",
                        "argument-error": "",
                        "app-not-authorized": "This app, identified by the domain where it's hosted, is not authorized to use Firebase Authentication with the provided API key. Review your key configuration in the Google API console.",
                        "app-not-installed": "The requested mobile application corresponding to the identifier (Android package name or iOS bundle ID) provided is not installed on this device.",
                        "captcha-check-failed": "The reCAPTCHA response token provided is either invalid, expired, already used or the domain associated with it does not match the list of whitelisted domains.",
                        "code-expired": "The SMS code has expired. Please re-send the verification code to try again.",
                        "cordova-not-ready": "Cordova framework is not ready.",
                        "cors-unsupported": "This browser is not supported.",
                        "credential-already-in-use": "This credential is already associated with a different user account.",
                        "custom-token-mismatch": "The custom token corresponds to a different audience.",
                        "requires-recent-login": "This operation is sensitive and requires recent authentication. Log in again before retrying this request.",
                        "dynamic-link-not-activated": "Please activate Dynamic Links in the Firebase Console and agree to the terms and conditions.",
                        "email-change-needs-verification": "Multi-factor users must always have a verified email.",
                        "email-already-in-use": "The email address is already in use by another account.",
                        "expired-action-code": "The action code has expired. ",
                        "cancelled-popup-request": "This operation has been cancelled due to another conflicting popup being opened.",
                        "internal-error": "An internal error has occurred.",
                        "invalid-app-credential": "The phone verification request contains an invalid application verifier. The reCAPTCHA token response is either invalid or expired.",
                        "invalid-app-id": "The mobile app identifier is not registed for the current project.",
                        "invalid-user-token": "This user's credential isn't valid for this project. This can happen if the user's token has been tampered with, or if the user isn't for the project associated with this API key.",
                        "invalid-auth-event": "An internal error has occurred.",
                        "invalid-verification-code": "The SMS verification code used to create the phone auth credential is invalid. Please resend the verification code sms and be sure use the verification code provided by the user.",
                        "invalid-continue-uri": "The continue URL provided in the request is invalid.",
                        "invalid-cordova-configuration": "The following Cordova plugins must be installed to enable OAuth sign-in: cordova-plugin-buildinfo, cordova-universal-links-plugin, cordova-plugin-browsertab, cordova-plugin-inappbrowser and cordova-plugin-customurlscheme.",
                        "invalid-custom-token": "The custom token format is incorrect. Please check the documentation.",
                        "invalid-dynamic-link-domain": "The provided dynamic link domain is not configured or authorized for the current project.",
                        "invalid-email": "The email address is badly formatted.",
                        "invalid-api-key": "Your API key is invalid, please check you have copied it correctly.",
                        "invalid-cert-hash": "The SHA-1 certificate hash provided is invalid.",
                        "invalid-credential": "The supplied auth credential is malformed or has expired.",
                        "invalid-message-payload": "The email template corresponding to this action contains invalid characters in its message. Please fix by going to the Auth email templates section in the Firebase Console.",
                        "invalid-multi-factor-session": "The request does not contain a valid proof of first factor successful sign-in.",
                        "invalid-oauth-provider": "EmailAuthProvider is not supported for this operation. This operation only supports OAuth providers.",
                        "invalid-oauth-client-id": "The OAuth client ID provided is either invalid or does not match the specified API key.",
                        "unauthorized-domain": "This domain is not authorized for OAuth operations for your Firebase project. Edit the list of authorized domains from the Firebase console.",
                        "invalid-action-code": "The action code is invalid. This can happen if the code is malformed, expired, or has already been used.",
                        "wrong-password": "The password is invalid or the user does not have a password.",
                        "invalid-persistence-type": "The specified persistence type is invalid. It can only be local, session or none.",
                        "invalid-phone-number": "The format of the phone number provided is incorrect. Please enter the phone number in a format that can be parsed into E.164 format. E.164 phone numbers are written in the format [+][country code][subscriber number including area code].",
                        "invalid-provider-id": "The specified provider ID is invalid.",
                        "invalid-recipient-email": "The email corresponding to this action failed to send as the provided recipient email address is invalid.",
                        "invalid-sender": "The email template corresponding to this action contains an invalid sender email or name. Please fix by going to the Auth email templates section in the Firebase Console.",
                        "invalid-verification-id": "The verification ID used to create the phone auth credential is invalid.",
                        "invalid-tenant-id": "The Auth instance's tenant ID is invalid.",
                        "multi-factor-info-not-found": "The user does not have a second factor matching the identifier provided.",
                        "multi-factor-auth-required": "Proof of ownership of a second factor is required to complete sign-in.",
                        "missing-android-pkg-name": "An Android Package Name must be provided if the Android App is required to be installed.",
                        "auth-domain-config-required": "Be sure to include authDomain when calling firebase.initializeApp(), by following the instructions in the Firebase console.",
                        "missing-app-credential": "The phone verification request is missing an application verifier assertion. A reCAPTCHA response token needs to be provided.",
                        "missing-verification-code": "The phone auth credential was created with an empty SMS verification code.",
                        "missing-continue-uri": "A continue URL must be provided in the request.",
                        "missing-iframe-start": "An internal error has occurred.",
                        "missing-ios-bundle-id": "An iOS Bundle ID must be provided if an App Store ID is provided.",
                        "missing-multi-factor-info": "No second factor identifier is provided.",
                        "missing-multi-factor-session": "The request is missing proof of first factor successful sign-in.",
                        "missing-or-invalid-nonce": "The request does not contain a valid nonce. This can occur if the SHA-256 hash of the provided raw nonce does not match the hashed nonce in the ID token payload.",
                        "missing-phone-number": "To send verification codes, provide a phone number for the recipient.",
                        "missing-verification-id": "The phone auth credential was created with an empty verification ID.",
                        "app-deleted": "This instance of FirebaseApp has been deleted.",
                        "account-exists-with-different-credential": "An account already exists with the same email address but different sign-in credentials.  using a provider associated with this email address.",
                        "network-request-failed": "A network error (such as timeout, interrupted connection or unreachable host) has occurred.",
                        "no-auth-event": "An internal error has occurred.",
                        "no-such-provider": "User was not linked to an account with the given provider.",
                        "null-user": "A null user object was provided as the argument for an operation which requires a non-null user object.",
                        "operation-not-allowed": "The given sign-in provider is disabled for this Firebase project. Enable it in the Firebase console, under the sign-in method tab of the Auth section.",
                        "operation-not-supported-in-this-environment": 'This operation is not supported in the environment this application is running on. "location.protocol" must be http, https or chrome-extension and web storage must be enabled.',
                        "popup-blocked": "Unable to establish a connection with the popup. It may have been blocked by the browser.",
                        "popup-closed-by-user": "The popup has been closed by the user before finalizing the operation.",
                        "provider-already-linked": "User can only be linked to one identity for the given provider.",
                        "quota-exceeded": "The project's quota for this operation has been exceeded.",
                        "redirect-cancelled-by-user": "The redirect operation has been cancelled by the user before finalizing.",
                        "redirect-operation-pending": "A redirect sign-in operation is already pending.",
                        "rejected-credential": "The request contains malformed or mismatching credentials.",
                        "second-factor-already-in-use": "The second factor is already enrolled on this account.",
                        "maximum-second-factor-count-exceeded": "The maximum allowed number of second factors on a user has been exceeded.",
                        "tenant-id-mismatch": "The provided tenant ID does not match the Auth instance's tenant ID",
                        timeout: "The operation has timed out.",
                        "user-token-expired": "The user's credential is no longer valid. The user must  again.",
                        "too-many-requests": "We have blocked all requests from this device due to unusual activity. Try again later.",
                        "unauthorized-continue-uri": "The domain of the continue URL is not whitelisted.  Please whitelist the domain in the Firebase console.",
                        "unsupported-first-factor": "Enrolling a second factor or signing in with a multi-factor account requires sign-in with a supported first factor.",
                        "unsupported-persistence-type": "The current environment does not support the specified persistence type.",
                        "unsupported-tenant-operation": "This operation is not supported in a multi-tenant context.",
                        "unverified-email": "The operation requires a verified email.",
                        "user-cancelled": "The user did not grant your application the permissions it requested.",
                        "user-not-found": "There is no user record corresponding to this identifier. The user may have been deleted.",
                        "user-disabled": "The user account has been disabled by an administrator.",
                        "user-mismatch": "The supplied credentials do not correspond to the previously signed in user.",
                        "user-signed-out": "",
                        "weak-password": "The password must be 6 characters long or more.",
                        "web-storage-unsupported": "This browser is not supported or 3rd party cookies and data may be disabled."
                    },
                    Lc = {
                        hd: {
                            Ra: "https://staging-identitytoolkit.sandbox.googleapis.com/identitytoolkit/v3/relyingparty/",
                            Xa: "https://staging-securetoken.sandbox.googleapis.com/v1/token",
                            Ua: "https://staging-identitytoolkit.sandbox.googleapis.com/v2/",
                            id: "b"
                        },
                        pd: {
                            Ra: "https://www.googleapis.com/identitytoolkit/v3/relyingparty/",
                            Xa: "https://securetoken.googleapis.com/v1/token",
                            Ua: "https://identitytoolkit.googleapis.com/v2/",
                            id: "p"
                        },
                        rd: {
                            Ra: "https://staging-www.sandbox.googleapis.com/identitytoolkit/v3/relyingparty/",
                            Xa: "https://staging-securetoken.sandbox.googleapis.com/v1/token",
                            Ua: "https://staging-identitytoolkit.sandbox.googleapis.com/v2/",
                            id: "s"
                        },
                        sd: {
                            Ra: "https://www-googleapis-test.sandbox.google.com/identitytoolkit/v3/relyingparty/",
                            Xa: "https://test-securetoken.sandbox.googleapis.com/v1/token",
                            Ua: "https://test-identitytoolkit.sandbox.googleapis.com/v2/",
                            id: "t"
                        }
                    };
                Pc = g("__EID__") ? "__EID__" : void 0, d(b, Error), b.prototype.name = "CustomError", d(w, b), w.prototype.name = "AssertionError", S.prototype.get = function() {
                    if (this.b > 0) {
                        this.b--;
                        var t = this.a;
                        this.a = t.next, t.next = null
                    } else t = this.c();
                    return t
                };
                var jc = new S(function() {
                    return new k
                }, function(t) {
                    t.reset()
                });
                T.prototype.add = function(t, e) {
                    var n = jc.get();
                    n.set(t, e), this.b ? this.b.next = n : this.a = n, this.b = n
                }, k.prototype.set = function(t, e) {
                    this.a = t, this.b = e, this.next = null
                }, k.prototype.reset = function() {
                    this.next = this.b = this.a = null
                };
                var Dc, Rc = Array.prototype.indexOf ? function(t, e) {
                        return Array.prototype.indexOf.call(t, e, void 0)
                    } : function(t, e) {
                        if ("string" == typeof t) return "string" != typeof e || 1 != e.length ? -1 : t.indexOf(e, 0);
                        for (var n = 0; t.length > n; n++)
                            if (n in t && t[n] === e) return n;
                        return -1
                    },
                    Uc = Array.prototype.forEach ? function(t, e, n) {
                        Array.prototype.forEach.call(t, e, n)
                    } : function(t, e, n) {
                        for (var i = t.length, o = "string" == typeof t ? t.split("") : t, r = 0; i > r; r++) r in o && e.call(n, o[r], r, t)
                    },
                    Vc = Array.prototype.filter ? function(t, e) {
                        return Array.prototype.filter.call(t, e, void 0)
                    } : function(t, e) {
                        for (var n = t.length, i = [], o = 0, r = "string" == typeof t ? t.split("") : t, a = 0; n > a; a++)
                            if (a in r) {
                                var s = r[a];
                                e.call(void 0, s, a, t) && (i[o++] = s)
                            } return i
                    },
                    Fc = Array.prototype.map ? function(t, e) {
                        return Array.prototype.map.call(t, e, void 0)
                    } : function(t, e) {
                        for (var n = t.length, i = Array(n), o = "string" == typeof t ? t.split("") : t, r = 0; n > r; r++) r in o && (i[r] = e.call(void 0, o[r], r, t));
                        return i
                    },
                    Bc = Array.prototype.some ? function(t, e) {
                        return Array.prototype.some.call(t, e, void 0)
                    } : function(t, e) {
                        for (var n = t.length, i = "string" == typeof t ? t.split("") : t, o = 0; n > o; o++)
                            if (o in i && e.call(void 0, i[o], o, t)) return !0;
                        return !1
                    },
                    Hc = String.prototype.trim ? function(t) {
                        return t.trim()
                    } : function(t) {
                        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(t)[1]
                    },
                    Gc = /&/g,
                    Wc = /</g,
                    Kc = />/g,
                    qc = /"/g,
                    zc = /'/g,
                    Xc = /\x00/g,
                    Jc = /[\x00&<>"']/;
                t: {
                    var Yc = Nc.navigator;
                    if (Yc) {
                        var $c = Yc.userAgent;
                        if ($c) {
                            Dc = $c;
                            break t
                        }
                    }
                    Dc = ""
                }
                var Zc = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
                H.prototype.ra = !0, H.prototype.qa = function() {
                    return this.a
                }, H.prototype.toString = function() {
                    return "Const{" + this.a + "}"
                };
                var Qc = {},
                    tl = {},
                    el = new H(tl, "");
                W.prototype.ra = !0, W.prototype.qa = function() {
                    return "" + this.a
                }, W.prototype.toString = function() {
                    return "TrustedResourceUrl{" + this.a + "}"
                };
                var nl = /%{(\w+)}/g,
                    il = /^((https:)?\/\/[0-9a-z.:[\]-]+\/|\/[^\/\\]|[^:\/\\%]+\/|[^:\/\\%]*[?#]|about:blank#)/i,
                    ol = {},
                    rl = {};
                z.prototype.ra = !0, z.prototype.qa = function() {
                    return "" + this.a
                }, z.prototype.toString = function() {
                    return "SafeUrl{" + this.a + "}"
                };
                var al = /^(?:(?:https?|mailto|ftp):|[^:\/?#]*(?:[\/?#]|$))/i,
                    sl = {},
                    ul = {};
                Y.prototype.ra = !0, Y.prototype.qa = function() {
                    return "" + this.a
                }, Y.prototype.toString = function() {
                    return "SafeHtml{" + this.a + "}"
                };
                var cl = {};
                Z("<!DOCTYPE html>");
                var ll = Z("");
                Z("<br>"), it[" "] = o;
                var hl, fl = D("Opera"),
                    pl = D("Trident") || D("MSIE"),
                    dl = D("Edge"),
                    ml = dl || pl,
                    vl = D("Gecko") && !(L(Dc.toLowerCase(), "webkit") && !D("Edge")) && !(D("Trident") || D("MSIE")) && !D("Edge"),
                    gl = L(Dc.toLowerCase(), "webkit") && !D("Edge");
                t: {
                    var yl = "",
                        bl = function() {
                            var t = Dc;
                            return vl ? /rv:([^\);]+)(\)|;)/.exec(t) : dl ? /Edge\/([\d\.]+)/.exec(t) : pl ? /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(t) : gl ? /WebKit\/(\S+)/.exec(t) : fl ? /(?:Version)[ \/]?(\S+)/.exec(t) : void 0
                        }();
                    if (bl && (yl = bl ? bl[1] : ""), pl) {
                        var wl = rt();
                        if (null != wl && wl > parseFloat(yl)) {
                            hl = wl + "";
                            break t
                        }
                    }
                    hl = yl
                }
                var _l, Sl = {};
                _l = Nc.document && pl ? rt() : void 0;
                try {
                    new self.OffscreenCanvas(0, 0).getContext("2d")
                } catch (t) {}
                var Il, Tl, Nl = !pl || +_l >= 9,
                    kl = {
                        cellpadding: "cellPadding",
                        cellspacing: "cellSpacing",
                        colspan: "colSpan",
                        frameborder: "frameBorder",
                        height: "height",
                        maxlength: "maxLength",
                        nonce: "nonce",
                        role: "role",
                        rowspan: "rowSpan",
                        type: "type",
                        usemap: "useMap",
                        valign: "vAlign",
                        width: "width"
                    },
                    El = !1,
                    Cl = new T,
                    Al = 0,
                    Ol = 2,
                    Pl = 3;
                bt.prototype.reset = function() {
                    this.f = this.b = this.g = this.a = null, this.c = !1
                };
                var xl = new S(function() {
                    return new bt
                }, function(t) {
                    t.reset()
                });
                yt.prototype.then = function(t, e, n) {
                    return Ct(this, s(t) ? t : null, s(e) ? e : null, n)
                }, yt.prototype.$goog_Thenable = !0, _c = yt.prototype, _c.ma = function(t, e) {
                    return t = wt(t, t, e), t.c = !0, Et(this, t), this
                }, _c.o = function(t, e) {
                    return Ct(this, null, t, e)
                }, _c.cancel = function(t) {
                    if (this.a == Al) {
                        var e = new Rt(t);
                        mt(function() {
                            kt(this, e)
                        }, this)
                    }
                }, _c.Yc = function(t) {
                    this.a = Al, At(this, Ol, t)
                }, _c.Zc = function(t) {
                    this.a = Al, At(this, Pl, t)
                }, _c.ec = function() {
                    for (var t; t = Mt(this);) Lt(this, t, this.a, this.i);
                    this.h = !1
                };
                var Ml = pt;
                d(Rt, b), Rt.prototype.name = "cancel";
                var Ll = 0,
                    jl = {};
                Ut.prototype.wa = !1, Ut.prototype.Ba = function() {
                    if (this.na)
                        for (; this.na.length;) this.na.shift()()
                };
                var Dl = Object.freeze || function(t) {
                        return t
                    },
                    Rl = !pl || +_l >= 9,
                    Ul = pl && !at("9"),
                    Vl = function() {
                        if (!Nc.addEventListener || !Object.defineProperty) return !1;
                        var t = !1,
                            e = Object.defineProperty({}, "passive", {
                                get: function() {
                                    t = !0
                                }
                            });
                        try {
                            Nc.addEventListener("test", o, e), Nc.removeEventListener("test", o, e)
                        } catch (t) {}
                        return t
                    }();
                Ft.prototype.preventDefault = function() {
                    this.defaultPrevented = !0
                }, d(Bt, Ft);
                var Fl = Dl({
                    2: "touch",
                    3: "pen",
                    4: "mouse"
                });
                Bt.prototype.preventDefault = function() {
                    Bt.Za.preventDefault.call(this);
                    var t = this.a;
                    if (t.preventDefault) t.preventDefault();
                    else if (t.returnValue = !1, Ul) try {
                        (t.ctrlKey || t.keyCode >= 112 && 123 >= t.keyCode) && (t.keyCode = -1)
                    } catch (t) {}
                }, Bt.prototype.f = function() {
                    return this.a
                };
                var Bl = "closure_listenable_" + (1e6 * Math.random() | 0),
                    Hl = 0;
                Wt.prototype.add = function(t, e, n, i, o) {
                    var r = "" + t;
                    (t = this.a[r]) || (t = this.a[r] = [], this.b++);
                    var a = qt(t, e, i, o);
                    return a > -1 ? (e = t[a], n || (e.Na = !1)) : (e = new Ht(e, this.src, r, !!i, o), e.Na = n, t.push(e)), e
                };
                var Gl = "closure_lm_" + (1e6 * Math.random() | 0),
                    Wl = {},
                    Kl = 0,
                    ql = "__closure_events_fn_" + (1e9 * Math.random() >>> 0);
                d(re, Ut), re.prototype[Bl] = !0, re.prototype.addEventListener = function(t, e, n, i) {
                    zt(this, t, e, n, i)
                }, re.prototype.removeEventListener = function(t, e, n, i) {
                    $t(this, t, e, n, i)
                }, re.prototype.dispatchEvent = function(t) {
                    var e, n = this.eb;
                    if (n)
                        for (e = []; n; n = n.eb) e.push(n);
                    n = this.Yb;
                    var i = t.type || t;
                    if ("string" == typeof t) t = new Ft(t, n);
                    else if (t instanceof Ft) t.target = t.target || n;
                    else {
                        var o = t;
                        t = new Ft(i, n), F(t, o)
                    }
                    if (o = !0, e)
                        for (var r = e.length - 1; r >= 0; r--) {
                            var a = t.b = e[r];
                            o = ue(a, i, !0, t) && o
                        }
                    if (a = t.b = n, o = ue(a, i, !0, t) && o, o = ue(a, i, !1, t) && o, e)
                        for (r = 0; e.length > r; r++) a = t.b = e[r], o = ue(a, i, !1, t) && o;
                    return o
                }, re.prototype.Ba = function() {
                    if (re.Za.Ba.call(this), this.u) {
                        var t, e = this.u,
                            n = 0;
                        for (t in e.a) {
                            for (var i = e.a[t], o = 0; i.length > o; o++) ++n, Gt(i[o]);
                            delete e.a[t], e.b--
                        }
                    }
                    this.eb = null
                }, _c = de.prototype, _c.V = function() {
                    me(this);
                    for (var t = [], e = 0; this.a.length > e; e++) t.push(this.b[this.a[e]]);
                    return t
                }, _c.X = function() {
                    return me(this), this.a.concat()
                }, _c.clear = function() {
                    this.b = {}, this.c = this.a.length = 0
                }, _c.get = function(t, e) {
                    return ve(this.b, t) ? this.b[t] : e
                }, _c.set = function(t, e) {
                    ve(this.b, t) || (this.c++, this.a.push(t)), this.b[t] = e
                }, _c.forEach = function(t, e) {
                    for (var n = this.X(), i = 0; n.length > i; i++) {
                        var o = n[i];
                        t.call(e, this.get(o), o, this)
                    }
                };
                var zl = /^(?:([^:\/?#.]+):)?(?:\/\/(?:([^\/?#]*)@)?([^\/#?]*?)(?::([0-9]+))?(?=[\/\\#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/;
                ye.prototype.toString = function() {
                    var t = [],
                        e = this.f;
                    e && t.push(Ee(e, Xl, !0), ":");
                    var n = this.b;
                    return (n || "file" == e) && (t.push("//"), (e = this.i) && t.push(Ee(e, Xl, !0), "@"), t.push(encodeURIComponent(n + "").replace(/%25([0-9a-fA-F]{2})/g, "%$1")), null != (n = this.l) && t.push(":", n + "")), (n = this.c) && (this.b && "/" != n.charAt(0) && t.push("/"), t.push(Ee(n, "/" == n.charAt(0) ? Yl : Jl, !0))), (n = "" + this.a) && t.push("?", n), (n = this.g) && t.push("#", Ee(n, Zl)), t.join("")
                }, ye.prototype.resolve = function(t) {
                    var e = new ye(this),
                        n = !!t.f;
                    n ? be(e, t.f) : n = !!t.i, n ? e.i = t.i : n = !!t.b, n ? e.b = t.b : n = null != t.l;
                    var i = t.c;
                    if (n) we(e, t.l);
                    else if (n = !!t.c) {
                        if ("/" != i.charAt(0))
                            if (this.b && !this.c) i = "/" + i;
                            else {
                                var o = e.c.lastIndexOf("/"); - 1 != o && (i = e.c.substr(0, o + 1) + i)
                            } if (".." == (o = i) || "." == o) i = "";
                        else if (L(o, "./") || L(o, "/.")) {
                            i = 0 == o.lastIndexOf("/", 0), o = o.split("/");
                            for (var r = [], a = 0; o.length > a;) {
                                var s = o[a++];
                                "." == s ? i && a == o.length && r.push("") : ".." == s ? ((r.length > 1 || 1 == r.length && "" != r[0]) && r.pop(), i && a == o.length && r.push("")) : (r.push(s), i = !0)
                            }
                            i = r.join("/")
                        } else i = o
                    }
                    return n ? e.c = i : n = "" != "" + t.a, n ? _e(e, je(t.a)) : n = !!t.g, n && (e.g = t.g), e
                };
                var Xl = /[#\/\?@]/g,
                    Jl = /[#\?:]/g,
                    Yl = /[#\?]/g,
                    $l = /[#\?@]/g,
                    Zl = /#/g;
                _c = Ae.prototype, _c.add = function(t, e) {
                    Oe(this), this.c = null, t = De(this, t);
                    var n = this.a.get(t);
                    return n || this.a.set(t, n = []), n.push(e), this.b += 1, this
                }, _c.clear = function() {
                    this.a = this.c = null, this.b = 0
                }, _c.forEach = function(t, e) {
                    Oe(this), this.a.forEach(function(n, i) {
                        Uc(n, function(n) {
                            t.call(e, n, i, this)
                        }, this)
                    }, this)
                }, _c.X = function() {
                    Oe(this);
                    for (var t = this.a.V(), e = this.a.X(), n = [], i = 0; e.length > i; i++)
                        for (var o = t[i], r = 0; o.length > r; r++) n.push(e[i]);
                    return n
                }, _c.V = function(t) {
                    Oe(this);
                    var e = [];
                    if ("string" == typeof t) Me(this, t) && (e = x(e, this.a.get(De(this, t))));
                    else {
                        t = this.a.V();
                        for (var n = 0; t.length > n; n++) e = x(e, t[n])
                    }
                    return e
                }, _c.set = function(t, e) {
                    return Oe(this), this.c = null, t = De(this, t), Me(this, t) && (this.b -= this.a.get(t).length), this.a.set(t, [e]), this.b += 1, this
                }, _c.get = function(t, e) {
                    return t ? (t = this.V(t), t.length > 0 ? t[0] + "" : e) : e
                }, _c.toString = function() {
                    if (this.c) return this.c;
                    if (!this.a) return "";
                    for (var t = [], e = this.a.X(), n = 0; e.length > n; n++) {
                        var i = e[n],
                            o = encodeURIComponent(i + "");
                        i = this.V(i);
                        for (var r = 0; i.length > r; r++) {
                            var a = o;
                            "" !== i[r] && (a += "=" + encodeURIComponent(i[r] + "")), t.push(a)
                        }
                    }
                    return this.c = t.join("&")
                };
                var Ql = {
                        '"': '\\"',
                        "\\": "\\\\",
                        "/": "\\/",
                        "\b": "\\b",
                        "\f": "\\f",
                        "\n": "\\n",
                        "\r": "\\r",
                        "\t": "\\t",
                        "\v": "\\u000b"
                    },
                    th = /\uffff/.test("￿") ? /[\\"\x00-\x1f\x7f-\uffff]/g : /[\\"\x00-\x1f\x7f-\xff]/g,
                    eh = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,
                    nh = /^[^@]+@[^@]+$/,
                    ih = "Firefox",
                    oh = "Chrome",
                    rh = {
                        jd: "FirebaseCore-web",
                        ld: "FirebaseUI-web"
                    };
                _n.prototype.get = function() {
                    var t = Nc.navigator;
                    return (t && "boolean" == typeof t.onLine && (fn() || "chrome-extension:" === pn() || void 0 !== t.connection) ? t.onLine : 1) ? this.b ? this.c : this.a : Math.min(5e3, this.a)
                };
                var ah, sh = {};
                try {
                    var uh = {};
                    Object.defineProperty(uh, "abcd", {
                        configurable: !0,
                        enumerable: !0,
                        value: 1
                    }), Object.defineProperty(uh, "abcd", {
                        configurable: !0,
                        enumerable: !0,
                        value: 2
                    }), ah = 2 == uh.abcd
                } catch (t) {
                    ah = !1
                }
                jn.prototype.v = function() {
                    return {
                        uid: this.uid,
                        displayName: this.displayName,
                        factorId: this.factorId,
                        enrollmentTime: this.enrollmentTime
                    }
                };
                var ch = "displayName",
                    lh = "enrolledAt",
                    hh = "mfaEnrollmentId",
                    fh = "phoneInfo";
                d(Rn, jn), Rn.prototype.v = function() {
                    var t = Rn.Za.v.call(this);
                    return t.phoneNumber = this.phoneNumber, t
                };
                var ph = "REVERT_SECOND_FACTOR_ADDITION",
                    dh = "EMAIL_SIGNIN",
                    mh = "VERIFY_AND_CHANGE_EMAIL",
                    vh = "email",
                    gh = "mfaInfo",
                    yh = "newEmail",
                    bh = "requestType",
                    wh = "email",
                    _h = "fromEmail",
                    Sh = "multiFactorInfo",
                    Ih = "previousEmail",
                    Th = "data",
                    Nh = "operation",
                    kh = "apiKey",
                    Eh = "oobCode",
                    Ch = "continueUrl",
                    Ah = "languageCode",
                    Oh = "mode",
                    Ph = "tenantId",
                    xh = {
                        recoverEmail: "RECOVER_EMAIL",
                        resetPassword: "PASSWORD_RESET",
                        revertSecondFactorAddition: ph,
                        signIn: dh,
                        verifyAndChangeEmail: mh,
                        verifyEmail: "VERIFY_EMAIL"
                    },
                    Mh = "android",
                    Lh = "dynamicLinkDomain",
                    jh = "handleCodeInApp",
                    Dh = "iOS",
                    Rh = "url",
                    Uh = "installApp",
                    Vh = "minimumVersion",
                    Fh = "packageName",
                    Bh = "bundleId",
                    Hh = null;
                zn.prototype.S = function() {
                    return this.f
                }, zn.prototype.i = function() {
                    return this.b
                }, zn.prototype.toString = function() {
                    return this.g
                };
                var Gh = "oauth_consumer_key oauth_nonce oauth_signature oauth_signature_method oauth_timestamp oauth_token oauth_version".split(" "),
                    Wh = ["client_id", "response_type", "scope", "redirect_uri", "state"],
                    Kh = {
                        kd: {
                            Ha: "locale",
                            ta: 700,
                            sa: 600,
                            ea: "facebook.com",
                            Va: Wh
                        },
                        md: {
                            Ha: null,
                            ta: 500,
                            sa: 750,
                            ea: "github.com",
                            Va: Wh
                        },
                        nd: {
                            Ha: "hl",
                            ta: 515,
                            sa: 680,
                            ea: "google.com",
                            Va: Wh
                        },
                        td: {
                            Ha: "lang",
                            ta: 485,
                            sa: 705,
                            ea: "twitter.com",
                            Va: Gh
                        },
                        gd: {
                            Ha: "locale",
                            ta: 640,
                            sa: 600,
                            ea: "apple.com",
                            Va: []
                        }
                    },
                    qh = "idToken",
                    zh = "providerId";
                d(Qn, Zn), d(ti, Qn), d(ei, Qn), d(ni, Qn), d(ii, Qn);
                var Xh = "enroll",
                    Jh = "signin";
                ri.prototype.Fa = function() {
                    return _t(this.a ? this.a : this.b)
                }, ri.prototype.v = function() {
                    return this.type == Xh ? {
                        multiFactorSession: {
                            idToken: this.a
                        }
                    } : {
                        multiFactorSession: {
                            pendingCredential: this.b
                        }
                    }
                }, ai.prototype.ia = function() {}, ai.prototype.b = function() {}, ai.prototype.c = function() {}, ai.prototype.v = function() {}, ui.prototype.ia = function(t) {
                    return rr(t, ci(this))
                }, ui.prototype.b = function(t, e) {
                    var n = ci(this);
                    return n.idToken = e, ar(t, n)
                }, ui.prototype.c = function(t, e) {
                    return si(sr(t, ci(this)), e)
                }, ui.prototype.v = function() {
                    return {
                        providerId: this.providerId,
                        signInMethod: this.signInMethod,
                        pendingToken: this.a
                    }
                }, hi.prototype.ia = function(t) {
                    return rr(t, fi(this))
                }, hi.prototype.b = function(t, e) {
                    var n = fi(this);
                    return n.idToken = e, ar(t, n)
                }, hi.prototype.c = function(t, e) {
                    return si(sr(t, fi(this)), e)
                }, hi.prototype.v = function() {
                    var t = {
                        providerId: this.providerId,
                        signInMethod: this.signInMethod
                    };
                    return this.idToken && (t.oauthIdToken = this.idToken), this.accessToken && (t.oauthAccessToken = this.accessToken), this.secret && (t.oauthTokenSecret = this.secret), this.nonce && (t.nonce = this.nonce), this.a && (t.pendingToken = this.a), t
                }, di.prototype.Ia = function(t) {
                    return this.Fb = V(t), this
                }, d(mi, di), d(vi, di), vi.prototype.Aa = function(t) {
                    return A(this.a, t) || this.a.push(t), this
                }, vi.prototype.Nb = function() {
                    return M(this.a)
                }, vi.prototype.credential = function(t, e) {
                    var n;
                    if (n = u(t) ? {
                            idToken: t.idToken || null,
                            accessToken: t.accessToken || null,
                            nonce: t.rawNonce || null
                        } : {
                            idToken: t || null,
                            accessToken: e || null
                        }, !n.idToken && !n.accessToken) throw new m("argument-error", "credential failed: must provide the ID token and/or the access token.");
                    return new hi(this.providerId, n, this.providerId)
                }, d(gi, vi), An(gi, "PROVIDER_ID", "facebook.com"), An(gi, "FACEBOOK_SIGN_IN_METHOD", "facebook.com"), d(bi, vi), An(bi, "PROVIDER_ID", "github.com"), An(bi, "GITHUB_SIGN_IN_METHOD", "github.com"), d(_i, vi), An(_i, "PROVIDER_ID", "google.com"), An(_i, "GOOGLE_SIGN_IN_METHOD", "google.com"), d(Ii, di), An(Ii, "PROVIDER_ID", "twitter.com"), An(Ii, "TWITTER_SIGN_IN_METHOD", "twitter.com"), Ni.prototype.ia = function(t) {
                    return this.signInMethod == Ei.EMAIL_LINK_SIGN_IN_METHOD ? cr(t, Cf, {
                        email: this.a,
                        oobCode: this.f
                    }) : cr(t, Yf, {
                        email: this.a,
                        password: this.f
                    })
                }, Ni.prototype.b = function(t, e) {
                    return this.signInMethod == Ei.EMAIL_LINK_SIGN_IN_METHOD ? cr(t, Af, {
                        idToken: e,
                        email: this.a,
                        oobCode: this.f
                    }) : cr(t, Hf, {
                        idToken: e,
                        email: this.a,
                        password: this.f
                    })
                }, Ni.prototype.c = function(t, e) {
                    return si(this.ia(t), e)
                }, Ni.prototype.v = function() {
                    return {
                        email: this.a,
                        password: this.f,
                        signInMethod: this.signInMethod
                    }
                }, On(Ei, {
                    PROVIDER_ID: "password"
                }), On(Ei, {
                    EMAIL_LINK_SIGN_IN_METHOD: "emailLink"
                }), On(Ei, {
                    EMAIL_PASSWORD_SIGN_IN_METHOD: "password"
                }), Oi.prototype.ia = function(t) {
                    return t.cb(xi(this))
                }, Oi.prototype.b = function(t, e) {
                    var n = xi(this);
                    return n.idToken = e, cr(t, Zf, n)
                }, Oi.prototype.c = function(t, e) {
                    var n = xi(this);
                    return n.operation = "REAUTH", t = cr(t, Qf, n), si(t, e)
                }, Oi.prototype.v = function() {
                    var t = {
                        providerId: "phone"
                    };
                    return this.a.bb && (t.verificationId = this.a.bb), this.a.ab && (t.verificationCode = this.a.ab), this.a.Ja && (t.temporaryProof = this.a.Ja), this.a.da && (t.phoneNumber = this.a.da), t
                }, Mi.prototype.cb = function(t, e) {
                    var n = this.a.b;
                    return _t(e.verify()).then(function(i) {
                        if ("string" != typeof i) throw new m("argument-error", "An implementation of firebase.auth.ApplicationVerifier.prototype.verify() must return a firebase.Promise that resolves with a string.");
                        switch (e.type) {
                            case "recaptcha":
                                var o, r = u(t) ? t.session : null,
                                    a = u(t) ? t.phoneNumber : t;
                                return o = r && r.type == Xh ? r.Fa().then(function(t) {
                                    return Zo(n, {
                                        idToken: t,
                                        phoneEnrollmentInfo: {
                                            phoneNumber: a,
                                            recaptchaToken: i
                                        }
                                    })
                                }) : r && r.type == Jh ? r.Fa().then(function(e) {
                                    return tr(n, {
                                        mfaPendingCredential: e,
                                        mfaEnrollmentId: t.multiFactorHint && t.multiFactorHint.uid || t.multiFactorUid,
                                        phoneSignInInfo: {
                                            recaptchaToken: i
                                        }
                                    })
                                }) : $o(n, {
                                    phoneNumber: a,
                                    recaptchaToken: i
                                }), o.then(function(t) {
                                    return "function" == typeof e.reset && e.reset(), t
                                }, function(t) {
                                    throw "function" == typeof e.reset && e.reset(), t
                                });
                            default:
                                throw new m("argument-error", 'Only firebase.auth.ApplicationVerifiers with type="recaptcha" are currently supported.')
                        }
                    })
                }, On(Mi, {
                    PROVIDER_ID: "phone"
                }), On(Mi, {
                    PHONE_SIGN_IN_METHOD: "phone"
                }), Ri.prototype.getUid = function() {
                    var t = [];
                    return t.push(this.c), this.b && t.push(this.b), this.f && t.push(this.f), this.h && t.push(this.h), t.join("-")
                }, Ri.prototype.S = function() {
                    return this.h
                }, Ri.prototype.v = function() {
                    return {
                        type: this.c,
                        eventId: this.b,
                        urlResponse: this.g,
                        sessionId: this.f,
                        postBody: this.i,
                        tenantId: this.h,
                        error: this.a && this.a.v()
                    }
                };
                var Yh = null;
                d(Bi, m), d(Hi, m), Hi.prototype.v = function() {
                    var t = {
                        code: this.code,
                        message: this.message
                    };
                    this.email && (t.email = this.email), this.phoneNumber && (t.phoneNumber = this.phoneNumber), this.tenantId && (t.tenantId = this.tenantId);
                    var e = this.credential && this.credential.v();
                    return e && F(t, e), t
                }, Hi.prototype.toJSON = function() {
                    return this.v()
                }, Wi.prototype.c = null;
                var $h;
                d(qi, Wi), qi.prototype.a = function() {
                    var t = zi(this);
                    return t ? new ActiveXObject(t) : new XMLHttpRequest
                }, qi.prototype.b = function() {
                    var t = {};
                    return zi(this) && (t[0] = !0, t[1] = !0), t
                }, $h = new qi, d(Xi, Wi), Xi.prototype.a = function() {
                    var t = new XMLHttpRequest;
                    if ("withCredentials" in t) return t;
                    if ("undefined" != typeof XDomainRequest) return new Ji;
                    throw Error("Unsupported browser")
                }, Xi.prototype.b = function() {
                    return {}
                }, _c = Ji.prototype, _c.open = function(t, e, n) {
                    if (null != n && !n) throw Error("Only async requests are supported.");
                    this.a.open(t, e)
                }, _c.send = function(t) {
                    if (t) {
                        if ("string" != typeof t) throw Error("Only string data is supported");
                        this.a.send(t)
                    } else this.a.send()
                }, _c.abort = function() {
                    this.a.abort()
                }, _c.setRequestHeader = function() {}, _c.getResponseHeader = function(t) {
                    return "content-type" == t.toLowerCase() ? this.a.contentType : ""
                }, _c.oc = function() {
                    this.status = 200, this.response = this.responseText = this.a.responseText, Yi(this, 4)
                }, _c.Pb = function() {
                    this.status = 500, this.response = this.responseText = "", Yi(this, 4)
                }, _c.tc = function() {
                    this.Pb()
                }, _c.pc = function() {
                    this.status = 200, Yi(this, 1)
                }, _c.getAllResponseHeaders = function() {
                    return "content-type: " + this.a.contentType
                }, $i.prototype.a = null;
                var Zh = 0;
                $i.prototype.reset = function(t, e, n, i, o) {
                    "number" == typeof o || Zh++, i || Oc(), delete this.a
                }, Qi.prototype.toString = function() {
                    return this.name
                };
                var Qh = new Qi("SEVERE", 1e3),
                    tf = new Qi("WARNING", 900),
                    ef = new Qi("CONFIG", 700),
                    nf = new Qi("FINE", 500);
                Zi.prototype.log = function(t, e, n) {
                    if (t.value >= to(this).value)
                        for (s(e) && (e = e()), t = new $i(t, e + "", this.f), n && (t.a = n), n = this; n;) n = n.a
                };
                var of = {}, rf = null;
                d(io, Wi), io.prototype.a = function() {
                    return new oo(this.f)
                }, io.prototype.b = function(t) {
                    return function() {
                        return t
                    }
                }({}), d(oo, re);
                var af = 0;
                _c = oo.prototype, _c.open = function(t, e) {
                    if (this.readyState != af) throw this.abort(), Error("Error reopening a connection");
                    this.m = t, this.g = e, this.readyState = 1, so(this)
                }, _c.send = function(t) {
                    if (1 != this.readyState) throw this.abort(), Error("need to call open() first. ");
                    this.a = !0;
                    var e = {
                        headers: this.i,
                        method: this.m,
                        credentials: void 0,
                        cache: void 0
                    };
                    t && (e.body = t), this.s.fetch(new Request(this.g, e)).then(this.sc.bind(this), this.Sa.bind(this))
                }, _c.abort = function() {
                    this.response = this.responseText = "", this.i = new Headers, this.status = 0, this.c && this.c.cancel("Request was aborted."), this.readyState >= 1 && this.a && 4 != this.readyState && (this.a = !1, ao(this, !1)), this.readyState = af
                }, _c.sc = function(t) {
                    this.a && (this.f = t, this.b || (this.b = t.headers, this.readyState = 2, so(this)), this.a && (this.readyState = 3, so(this), this.a && ("arraybuffer" === this.responseType ? t.arrayBuffer().then(this.qc.bind(this), this.Sa.bind(this)) : void 0 !== Nc.ReadableStream && "body" in t ? (this.response = this.responseText = "", this.c = t.body.getReader(), this.l = new TextDecoder, ro(this)) : t.text().then(this.rc.bind(this), this.Sa.bind(this)))))
                }, _c.nc = function(t) {
                    if (this.a) {
                        var e = this.l.decode(t.value ? t.value : new Uint8Array(0), {
                            stream: !t.done
                        });
                        e && (this.response = this.responseText += e), t.done ? ao(this, !0) : so(this), 3 == this.readyState && ro(this)
                    }
                }, _c.rc = function(t) {
                    this.a && (this.response = this.responseText = t, ao(this, !0))
                }, _c.qc = function(t) {
                    this.a && (this.response = t, ao(this, !0))
                }, _c.Sa = function(t) {
                    var e = this.h;
                    e && e.log(tf, "Failed to fetch url " + this.g, t instanceof Error ? t : Error(t)), this.a && ao(this, !0)
                }, _c.setRequestHeader = function(t, e) {
                    this.i.append(t, e)
                }, _c.getResponseHeader = function(t) {
                    return this.b ? this.b.get(t.toLowerCase()) || "" : ((t = this.h) && t.log(tf, "Attempting to get response header but no headers have been received for url: " + this.g, void 0), "")
                }, _c.getAllResponseHeaders = function() {
                    if (!this.b) {
                        var t = this.h;
                        return t && t.log(tf, "Attempting to get all response headers but no headers have been received for url: " + this.g, void 0), ""
                    }
                    t = [];
                    for (var e = this.b.entries(), n = e.next(); !n.done;) n = n.value, t.push(n[0] + ": " + n[1]), n = e.next();
                    return t.join("\r\n")
                }, d(uo, re);
                var sf = "";
                uo.prototype.b = eo("goog.net.XhrIo");
                var uf = /^https?$/i,
                    cf = ["POST", "PUT"];
                _c = uo.prototype, _c.Ka = function() {
                    void 0 !== Tc && this.a && (this.h = "Timed out after " + this.g + "ms, aborting", no(this.b, _o(this, this.h)), this.dispatchEvent("timeout"), this.abort(8))
                }, _c.abort = function() {
                    this.a && this.c && (no(this.b, _o(this, "Aborting")), this.c = !1, this.f = !0, this.a.abort(), this.f = !1, this.dispatchEvent("complete"), this.dispatchEvent("abort"), vo(this))
                }, _c.Ba = function() {
                    this.a && (this.c && (this.c = !1, this.f = !0, this.a.abort(), this.f = !1), vo(this, !0)), uo.Za.Ba.call(this)
                }, _c.Sb = function() {
                    this.wa || (this.O || this.i || this.f ? mo(this) : this.Hc())
                }, _c.Hc = function() {
                    mo(this)
                }, _c.getResponse = function() {
                    try {
                        if (!this.a) return null;
                        if ("response" in this.a) return this.a.response;
                        switch (this.m) {
                            case sf:
                            case "text":
                                return this.a.responseText;
                            case "arraybuffer":
                                if ("mozResponseArrayBuffer" in this.a) return this.a.mozResponseArrayBuffer
                        }
                        var t = this.b;
                        return t && t.log(Qh, "Response type " + this.m + " is not supported on this browser", void 0), null
                    } catch (t) {
                        return no(this.b, "Can not get response: " + t.message), null
                    }
                }, So.prototype.cancel = function(t) {
                    if (this.a) this.c instanceof So && this.c.cancel();
                    else {
                        if (this.b) {
                            var e = this.b;
                            delete this.b, t ? e.cancel(t) : 0 >= --e.l && e.cancel()
                        }
                        this.w ? this.w.call(this.s, this) : this.u = !0, this.a || (t = new Oo(this), To(this), Io(this, !1, t))
                    }
                }, So.prototype.m = function(t, e) {
                    this.i = !1, Io(this, t, e)
                }, So.prototype.then = function(t, e, n) {
                    var i, o, r = new yt(function(t, e) {
                        i = t, o = e
                    });
                    return ko(this, i, function(t) {
                        t instanceof Oo ? r.cancel() : o(t)
                    }), r.then(t, e, n)
                }, So.prototype.$goog_Thenable = !0, d(Ao, b), Ao.prototype.message = "Deferred has already fired", Ao.prototype.name = "AlreadyCalledError", d(Oo, b), Oo.prototype.message = "Deferred was canceled", Oo.prototype.name = "CanceledError", Po.prototype.c = function() {
                    throw delete lf[this.a], this.b
                };
                var lf = {},
                    hf = 0,
                    ff = 1;
                d(Do, b), d(Ro, Wi), Ro.prototype.a = function() {
                    return new this.f
                }, Ro.prototype.b = function() {
                    return {}
                };
                var pf, df = "idToken",
                    mf = new _n(3e4, 6e4),
                    vf = {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    gf = new _n(3e4, 6e4),
                    yf = {
                        "Content-Type": "application/json"
                    };
                Uo.prototype.S = function() {
                    return this.b
                }, Uo.prototype.w = function(t, e, n, i, o, r) {
                    if (en() && (void 0 === Nc.fetch || void 0 === Nc.Headers || void 0 === Nc.Request)) throw new m("operation-not-supported-in-this-environment", "fetch, Headers and Request native APIs or equivalent Polyfills must be available to support HTTP requests from a Worker environment.");
                    var a = new uo(this.f);
                    if (r) {
                        a.g = Math.max(0, r);
                        var s = setTimeout(function() {
                            a.dispatchEvent("timeout")
                        }, r)
                    }
                    ae(a, "complete", function() {
                        s && clearTimeout(s);
                        var t = null;
                        try {
                            t = JSON.parse(wo(this)) || null
                        } catch (e) {
                            t = null
                        }
                        e && e(t)
                    }), se(a, "ready", function() {
                        s && clearTimeout(s), Vt(this)
                    }), se(a, "timeout", function() {
                        s && clearTimeout(s), Vt(this), e && e(null)
                    }), co(a, t, n, i, o)
                };
                var bf = new H(tl, "https://apis.google.com/js/client.js?onload=%{onload}"),
                    wf = "__fcb" + Math.floor(1e6 * Math.random());
                Uo.prototype.s = function(t, e, n, i, o) {
                    var r = this;
                    pf.then(function() {
                        window.gapi.client.setApiKey(r.c);
                        var a = window.gapi.auth.getToken();
                        window.gapi.auth.setToken(null), window.gapi.client.request({
                            path: t,
                            method: n,
                            body: i,
                            headers: o,
                            authType: "none",
                            callback: function(t) {
                                window.gapi.auth.setToken(a), e && e(t)
                            }
                        })
                    }).o(function(t) {
                        e && e({
                            error: {
                                message: t && t.message || "CORS_UNSUPPORTED"
                            }
                        })
                    })
                }, Uo.prototype.vb = function() {
                    return cr(this, Gf, {})
                }, Uo.prototype.xb = function(t, e) {
                    return cr(this, Bf, {
                        idToken: t,
                        email: e
                    })
                }, Uo.prototype.yb = function(t, e) {
                    return cr(this, Hf, {
                        idToken: t,
                        password: e
                    })
                };
                var _f = {
                    displayName: "DISPLAY_NAME",
                    photoUrl: "PHOTO_URL"
                };
                _c = Uo.prototype, _c.zb = function(t, e) {
                    var n = {
                            idToken: t
                        },
                        i = [];
                    return R(_f, function(t, o) {
                        var r = e[o];
                        null === r ? i.push(t) : o in e && (n[o] = r)
                    }), i.length && (n.deleteAttribute = i), cr(this, Bf, n)
                }, _c.rb = function(t, e) {
                    return t = {
                        requestType: "PASSWORD_RESET",
                        email: t
                    }, F(t, e), cr(this, Df, t)
                }, _c.sb = function(t, e) {
                    return t = {
                        requestType: "EMAIL_SIGNIN",
                        email: t
                    }, F(t, e), cr(this, Mf, t)
                }, _c.qb = function(t, e) {
                    return t = {
                        requestType: "VERIFY_EMAIL",
                        idToken: t
                    }, F(t, e), cr(this, Lf, t)
                }, _c.Ab = function(t, e, n) {
                    return t = {
                        requestType: "VERIFY_AND_CHANGE_EMAIL",
                        idToken: t,
                        newEmail: e
                    }, F(t, n), cr(this, jf, t)
                }, _c.cb = function(t) {
                    return cr(this, $f, t)
                }, _c.jb = function(t, e) {
                    return cr(this, Vf, {
                        oobCode: t,
                        newPassword: e
                    })
                }, _c.Pa = function(t) {
                    return cr(this, If, {
                        oobCode: t
                    })
                }, _c.fb = function(t) {
                    return cr(this, Sf, {
                        oobCode: t
                    })
                };
                var Sf = {
                        endpoint: "setAccountInfo",
                        A: ur,
                        Y: "email",
                        C: !0
                    },
                    If = {
                        endpoint: "resetPassword",
                        A: ur,
                        G: function(t) {
                            var e = t.requestType;
                            if (!e || !t.email && "EMAIL_SIGNIN" != e && "VERIFY_AND_CHANGE_EMAIL" != e) throw new m("internal-error")
                        },
                        C: !0
                    },
                    Tf = {
                        endpoint: "signupNewUser",
                        A: function(t) {
                            if (Ko(t), !t.password) throw new m("weak-password")
                        },
                        G: Jo,
                        U: !0,
                        C: !0
                    },
                    Nf = {
                        endpoint: "createAuthUri",
                        C: !0
                    },
                    kf = {
                        endpoint: "deleteAccount",
                        M: ["idToken"]
                    },
                    Ef = {
                        endpoint: "setAccountInfo",
                        M: ["idToken", "deleteProvider"],
                        A: function(t) {
                            if ("array" != r(t.deleteProvider)) throw new m("internal-error")
                        }
                    },
                    Cf = {
                        endpoint: "emailLinkSignin",
                        M: ["email", "oobCode"],
                        A: Ko,
                        G: Jo,
                        U: !0,
                        C: !0
                    },
                    Af = {
                        endpoint: "emailLinkSignin",
                        M: ["idToken", "email", "oobCode"],
                        A: Ko,
                        G: Jo,
                        U: !0
                    },
                    Of = {
                        endpoint: "accounts/mfaEnrollment:finalize",
                        M: ["idToken", "phoneVerificationInfo"],
                        A: Qo,
                        G: Jo,
                        C: !0,
                        La: !0
                    },
                    Pf = {
                        endpoint: "accounts/mfaSignIn:finalize",
                        M: ["mfaPendingCredential", "phoneVerificationInfo"],
                        A: Qo,
                        G: Jo,
                        C: !0,
                        La: !0
                    },
                    xf = {
                        endpoint: "getAccountInfo"
                    },
                    Mf = {
                        endpoint: "getOobConfirmationCode",
                        M: ["requestType"],
                        A: function(t) {
                            if ("EMAIL_SIGNIN" != t.requestType) throw new m("internal-error");
                            Ko(t)
                        },
                        Y: "email",
                        C: !0
                    },
                    Lf = {
                        endpoint: "getOobConfirmationCode",
                        M: ["idToken", "requestType"],
                        A: function(t) {
                            if ("VERIFY_EMAIL" != t.requestType) throw new m("internal-error")
                        },
                        Y: "email",
                        C: !0
                    },
                    jf = {
                        endpoint: "getOobConfirmationCode",
                        M: ["idToken", "newEmail", "requestType"],
                        A: function(t) {
                            if ("VERIFY_AND_CHANGE_EMAIL" != t.requestType) throw new m("internal-error")
                        },
                        Y: "email",
                        C: !0
                    },
                    Df = {
                        endpoint: "getOobConfirmationCode",
                        M: ["requestType"],
                        A: function(t) {
                            if ("PASSWORD_RESET" != t.requestType) throw new m("internal-error");
                            Ko(t)
                        },
                        Y: "email",
                        C: !0
                    },
                    Rf = {
                        hb: !0,
                        endpoint: "getProjectConfig",
                        Rb: "GET"
                    },
                    Uf = {
                        hb: !0,
                        endpoint: "getRecaptchaParam",
                        Rb: "GET",
                        G: function(t) {
                            if (!t.recaptchaSiteKey) throw new m("internal-error")
                        }
                    },
                    Vf = {
                        endpoint: "resetPassword",
                        A: ur,
                        Y: "email",
                        C: !0
                    },
                    Ff = {
                        endpoint: "sendVerificationCode",
                        M: ["phoneNumber", "recaptchaToken"],
                        Y: "sessionInfo",
                        C: !0
                    },
                    Bf = {
                        endpoint: "setAccountInfo",
                        M: ["idToken"],
                        A: qo,
                        U: !0
                    },
                    Hf = {
                        endpoint: "setAccountInfo",
                        M: ["idToken"],
                        A: function(t) {
                            if (qo(t), !t.password) throw new m("weak-password")
                        },
                        G: Jo,
                        U: !0
                    },
                    Gf = {
                        endpoint: "signupNewUser",
                        G: Jo,
                        U: !0,
                        C: !0
                    },
                    Wf = {
                        endpoint: "accounts/mfaEnrollment:start",
                        M: ["idToken", "phoneEnrollmentInfo"],
                        A: function(t) {
                            if (!t.phoneEnrollmentInfo) throw new m("internal-error");
                            if (!t.phoneEnrollmentInfo.phoneNumber) throw new m("missing-phone-number");
                            if (!t.phoneEnrollmentInfo.recaptchaToken) throw new m("missing-app-credential")
                        },
                        G: function(t) {
                            if (!t.phoneSessionInfo || !t.phoneSessionInfo.sessionInfo) throw new m("internal-error")
                        },
                        C: !0,
                        La: !0
                    },
                    Kf = {
                        endpoint: "accounts/mfaSignIn:start",
                        M: ["mfaPendingCredential", "mfaEnrollmentId", "phoneSignInInfo"],
                        A: function(t) {
                            if (!t.phoneSignInInfo || !t.phoneSignInInfo.recaptchaToken) throw new m("missing-app-credential")
                        },
                        G: function(t) {
                            if (!t.phoneResponseInfo || !t.phoneResponseInfo.sessionInfo) throw new m("internal-error")
                        },
                        C: !0,
                        La: !0
                    },
                    qf = {
                        endpoint: "verifyAssertion",
                        A: nr,
                        Wa: ir,
                        G: or,
                        U: !0,
                        C: !0
                    },
                    zf = {
                        endpoint: "verifyAssertion",
                        A: nr,
                        Wa: ir,
                        G: function(t) {
                            if (t.errorMessage && "USER_NOT_FOUND" == t.errorMessage) throw new m("user-not-found");
                            if (t.errorMessage) throw lr(t.errorMessage);
                            Jo(t)
                        },
                        U: !0,
                        C: !0
                    },
                    Xf = {
                        endpoint: "verifyAssertion",
                        A: function(t) {
                            if (nr(t), !t.idToken) throw new m("internal-error")
                        },
                        Wa: ir,
                        G: or,
                        U: !0
                    },
                    Jf = {
                        endpoint: "verifyCustomToken",
                        A: function(t) {
                            if (!t.token) throw new m("invalid-custom-token")
                        },
                        G: Jo,
                        U: !0,
                        C: !0
                    },
                    Yf = {
                        endpoint: "verifyPassword",
                        A: function(t) {
                            if (Ko(t), !t.password) throw new m("wrong-password")
                        },
                        G: Jo,
                        U: !0,
                        C: !0
                    },
                    $f = {
                        endpoint: "verifyPhoneNumber",
                        A: Yo,
                        G: Jo,
                        C: !0
                    },
                    Zf = {
                        endpoint: "verifyPhoneNumber",
                        A: function(t) {
                            if (!t.idToken) throw new m("internal-error");
                            Yo(t)
                        },
                        G: function(t) {
                            if (t.temporaryProof) throw t.code = "credential-already-in-use", Gi(t);
                            Jo(t)
                        }
                    },
                    Qf = {
                        Eb: {
                            USER_NOT_FOUND: "user-not-found"
                        },
                        endpoint: "verifyPhoneNumber",
                        A: Yo,
                        G: Jo,
                        C: !0
                    },
                    tp = {
                        endpoint: "accounts/mfaEnrollment:withdraw",
                        M: ["idToken", "mfaEnrollmentId"],
                        G: function(t) {
                            if (!!t[df] ^ !!t.refreshToken) throw new m("internal-error")
                        },
                        C: !0,
                        La: !0
                    },
                    ep = new H(tl, "https://apis.google.com/js/api.js?onload=%{onload}"),
                    np = new _n(3e4, 6e4),
                    ip = new _n(5e3, 15e3),
                    op = null;
                gr.prototype.toString = function() {
                    return this.f ? Se(this.a, "v", this.f) : xe(this.a.a, "v"), this.b ? Se(this.a, "eid", this.b) : xe(this.a.a, "eid"), this.c.length ? Se(this.a, "fw", this.c.join(",")) : xe(this.a.a, "fw"), "" + this.a
                }, yr.prototype.ub = function(t) {
                    return this.h = t, this
                }, yr.prototype.toString = function() {
                    var t = Ne(this.s, "/__/auth/handler");
                    if (Se(t, "apiKey", this.m), Se(t, "appName", this.c), Se(t, "authType", this.u), this.a.isOAuthProvider) {
                        var e = this.a;
                        try {
                            var n = i.a.app(this.c).auth().ja()
                        } catch (t) {
                            n = null
                        }
                        e.kb = n, Se(t, "providerId", this.a.providerId), e = this.a, n = vn(e.Fb);
                        for (var o in n) n[o] = "" + n[o];
                        o = e.Oc, n = V(n);
                        for (var r = 0; o.length > r; r++) {
                            var a = o[r];
                            a in n && delete n[a]
                        }
                        e.lb && e.kb && !n[e.lb] && (n[e.lb] = e.kb), U(n) || Se(t, "customParameters", mn(n))
                    }
                    if ("function" == typeof this.a.Nb && (e = this.a.Nb(), e.length && Se(t, "scopes", e.join(","))), this.l ? Se(t, "redirectUrl", this.l) : xe(t.a, "redirectUrl"), this.g ? Se(t, "eventId", this.g) : xe(t.a, "eventId"), this.i ? Se(t, "v", this.i) : xe(t.a, "v"), this.b)
                        for (var s in this.b) this.b.hasOwnProperty(s) && !Ie(t, s) && Se(t, s, this.b[s]);
                    return this.h ? Se(t, "tid", this.h) : xe(t.a, "tid"), this.f ? Se(t, "eid", this.f) : xe(t.a, "eid"), s = br(this.c), s.length && Se(t, "fw", s.join(",")), "" + t
                }, _c = wr.prototype, _c.Lb = function(t, e, n) {
                    var i = new m("popup-closed-by-user"),
                        o = new m("web-storage-unsupported"),
                        r = this,
                        a = !1;
                    return this.ka().then(function() {
                        kr(r).then(function(n) {
                            n || (t && Xe(t), e(o), a = !0)
                        })
                    }).o(function() {}).then(function() {
                        if (!a) return Ye(t)
                    }).then(function() {
                        if (!a) return le(n).then(function() {
                            e(i)
                        })
                    })
                }, _c.Ub = function() {
                    var t = un();
                    return !dn(t) && !bn(t)
                }, _c.Qb = function() {
                    return !1
                }, _c.Jb = function(t, e, n, i, o, r, a, s) {
                    if (!t) return St(new m("popup-blocked"));
                    if (a && !dn()) return this.ka().o(function(e) {
                        Xe(t), o(e)
                    }), i(), _t();
                    this.a || (this.a = _r(Ir(this)));
                    var u = this;
                    return this.a.then(function() {
                        var e = u.ka().o(function(e) {
                            throw Xe(t), o(e), e
                        });
                        return i(), e
                    }).then(function() {
                        Di(n), a || We(Tr(u.u, u.f, u.b, e, n, null, r, u.c, void 0, u.h, s), t)
                    }).o(function(t) {
                        throw "auth/network-request-failed" == t.code && (u.a = null), t
                    })
                }, _c.Kb = function(t, e, n, i) {
                    this.a || (this.a = _r(Ir(this)));
                    var o = this;
                    return this.a.then(function() {
                        Di(e), We(Tr(o.u, o.f, o.b, t, e, Ge(), n, o.c, void 0, o.h, i))
                    }).o(function(t) {
                        throw "auth/network-request-failed" == t.code && (o.a = null), t
                    })
                }, _c.ka = function() {
                    var t = this;
                    return Sr(this).then(function() {
                        return t.i.nb
                    }).o(function() {
                        throw t.a = null, new m("network-request-failed")
                    })
                }, _c.Xb = function() {
                    return !0
                }, _c.Ca = function(t) {
                    this.g.push(t)
                }, _c.Qa = function(t) {
                    P(this.g, function(e) {
                        return e == t
                    })
                }, _c = Er.prototype, _c.get = function(t) {
                    return _t(this.a.getItem(t)).then(function(t) {
                        return t && gn(t)
                    })
                }, _c.set = function(t, e) {
                    return _t(this.a.setItem(t, mn(e)))
                }, _c.T = function(t) {
                    return _t(this.a.removeItem(t))
                }, _c.ba = function() {}, _c.ha = function() {};
                var rp = [];
                Cr.prototype.c = function(t) {
                    var e = t.data.eventType,
                        n = t.data.eventId,
                        i = this.a[e];
                    if (i && i.length > 0) {
                        t.ports[0].postMessage({
                            status: "ack",
                            eventId: n,
                            eventType: e,
                            response: null
                        });
                        var o = [];
                        Uc(i, function(e) {
                            o.push(_t().then(function() {
                                return e(t.origin, t.data.data)
                            }))
                        }), Nt(o).then(function(i) {
                            var o = [];
                            Uc(i, function(t) {
                                o.push({
                                    fulfilled: t.Mb,
                                    value: t.value,
                                    reason: t.reason ? t.reason.message : void 0
                                })
                            }), Uc(o, function(t) {
                                for (var e in t) void 0 === t[e] && delete t[e]
                            }), t.ports[0].postMessage({
                                status: "done",
                                eventId: n,
                                eventType: e,
                                response: o
                            })
                        })
                    }
                }, Pr.prototype.postMessage = function(t, e) {
                    this.a.postMessage(t, e)
                }, xr.prototype.close = function() {
                    for (; this.a.length > 0;) Lr(this, this.a[0]);
                    this.b = !0
                };
                var ap;
                _c = jr.prototype, _c.set = function(t, e) {
                    var n, i = !1,
                        o = this;
                    return Ur(this).then(function(e) {
                        return n = e, e = Fr(Br(n, !0)), Hr(e.get(t))
                    }).then(function(r) {
                        var a = Fr(Br(n, !0));
                        return r ? (r.value = e, Hr(a.put(r))) : (o.b++, i = !0, r = {}, r.fbase_key = t, r.value = e, Hr(a.add(r)))
                    }).then(function() {
                        return o.c[t] = e, Gr(o, t)
                    }).ma(function() {
                        i && o.b--
                    })
                }, _c.get = function(t) {
                    return Ur(this).then(function(e) {
                        return Hr(Fr(Br(e, !1)).get(t))
                    }).then(function(t) {
                        return t && t.value
                    })
                }, _c.T = function(t) {
                    var e = !1,
                        n = this;
                    return Ur(this).then(function(i) {
                        return e = !0, n.b++, Hr(Fr(Br(i, !0)).delete(t))
                    }).then(function() {
                        return delete n.c[t], Gr(n, t)
                    }).ma(function() {
                        e && n.b--
                    })
                }, _c.ba = function(t) {
                    0 == this.a.length && Kr(this), this.a.push(t)
                }, _c.ha = function(t) {
                    P(this.a, function(e) {
                        return e == t
                    }), 0 == this.a.length && qr(this)
                }, _c = zr.prototype, _c.get = function(t) {
                    return this.b.then(function(e) {
                        return e.get(t)
                    })
                }, _c.set = function(t, e) {
                    return this.b.then(function(n) {
                        return n.set(t, e)
                    })
                }, _c.T = function(t) {
                    return this.b.then(function(e) {
                        return e.T(t)
                    })
                }, _c.ba = function(t) {
                    this.a.push(t)
                }, _c.ha = function(t) {
                    P(this.a, function(e) {
                        return e == t
                    })
                }, _c = Xr.prototype, _c.get = function(t) {
                    return _t(this.a[t])
                }, _c.set = function(t, e) {
                    return this.a[t] = e, _t()
                }, _c.T = function(t) {
                    return delete this.a[t], _t()
                }, _c.ba = function() {}, _c.ha = function() {}, _c = Jr.prototype, _c.get = function(t) {
                    var e = this;
                    return _t().then(function() {
                        return gn(e.a.getItem(t))
                    })
                }, _c.set = function(t, e) {
                    var n = this;
                    return _t().then(function() {
                        var i = mn(e);
                        null === i ? n.T(t) : n.a.setItem(t, i)
                    })
                }, _c.T = function(t) {
                    var e = this;
                    return _t().then(function() {
                        e.a.removeItem(t)
                    })
                }, _c.ba = function(t) {
                    Nc.window && zt(Nc.window, "storage", t)
                }, _c.ha = function(t) {
                    Nc.window && $t(Nc.window, "storage", t)
                }, _c = Zr.prototype, _c.get = function() {
                    return _t(null)
                }, _c.set = function() {
                    return _t()
                }, _c.T = function() {
                    return _t()
                }, _c.ba = function() {}, _c.ha = function() {}, _c = Qr.prototype, _c.get = function(t) {
                    var e = this;
                    return _t().then(function() {
                        return gn(e.a.getItem(t))
                    })
                }, _c.set = function(t, e) {
                    var n = this;
                    return _t().then(function() {
                        var i = mn(e);
                        null === i ? n.T(t) : n.a.setItem(t, i)
                    })
                }, _c.T = function(t) {
                    var e = this;
                    return _t().then(function() {
                        e.a.removeItem(t)
                    })
                }, _c.ba = function() {}, _c.ha = function() {};
                var sp, up, cp = {
                        F: Jr,
                        $a: Qr
                    },
                    lp = {
                        F: Jr,
                        $a: Qr
                    },
                    hp = {
                        F: Er,
                        $a: Zr
                    },
                    fp = {
                        F: Jr,
                        $a: Zr
                    },
                    pp = {
                        od: "local",
                        NONE: "none",
                        qd: "session"
                    };
                _c = oa.prototype, _c.get = function(t, e) {
                    return aa(this, t.F).get(sa(t, e))
                }, _c.set = function(t, e, n) {
                    var i = sa(t, n),
                        o = this,
                        r = aa(this, t.F);
                    return r.set(i, e).then(function() {
                        return r.get(i)
                    }).then(function(e) {
                        "local" == t.F && (o.b[i] = e)
                    })
                }, _c.addListener = function(t, e, n) {
                    t = sa(t, e), this.l && (this.b[t] = Nc.localStorage.getItem(t)), U(this.a) && (aa(this, "local").ba(this.f), this.h || (He() || !Nn()) && Nc.indexedDB || !this.l || la(this)), this.a[t] || (this.a[t] = []), this.a[t].push(n)
                }, _c.removeListener = function(t, e, n) {
                    t = sa(t, e), this.a[t] && (P(this.a[t], function(t) {
                        return t == n
                    }), 0 == this.a[t].length && delete this.a[t]), U(this.a) && (aa(this, "local").ha(this.f), ha(this))
                }, _c.Vb = function(t) {
                    if (t && t.f) {
                        var e = t.a.key;
                        if (null == e)
                            for (var n in this.a) {
                                var i = this.b[n];
                                void 0 === i && (i = null);
                                var o = Nc.localStorage.getItem(n);
                                o !== i && (this.b[n] = o, this.ib(n))
                            } else if (0 == e.indexOf("firebase:") && this.a[e]) {
                                if (void 0 !== t.a.a ? aa(this, "local").ha(this.f) : ha(this), this.m)
                                    if (n = Nc.localStorage.getItem(e), (i = t.a.newValue) !== n) null !== i ? Nc.localStorage.setItem(e, i) : Nc.localStorage.removeItem(e);
                                    else if (this.b[e] === i && void 0 === t.a.a) return;
                                var r = this;
                                n = function() {
                                    void 0 === t.a.a && r.b[e] === Nc.localStorage.getItem(e) || (r.b[e] = Nc.localStorage.getItem(e), r.ib(e))
                                }, pl && _l && 10 == _l && Nc.localStorage.getItem(e) !== t.a.newValue && t.a.newValue !== t.a.oldValue ? setTimeout(n, 10) : n()
                            }
                    } else Uc(t, f(this.ib, this))
                }, _c.ib = function(t) {
                    this.a[t] && Uc(this.a[t], function(t) {
                        t()
                    })
                };
                var dp, mp = {
                    name: "authEvent",
                    F: "local"
                };
                d(va, ma);
                for (var vp = 64, gp = vp - 1, yp = [], bp = 0; gp > bp; bp++) yp[bp] = 0;
                var wp = x(128, yp);
                va.prototype.reset = function() {
                    this.g = this.c = 0, this.a = Nc.Int32Array ? new Int32Array(this.h) : M(this.h)
                };
                var _p = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
                d(ba, va);
                var Sp = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
                _c = wa.prototype, _c.ka = function() {
                    return this.Ga ? this.Ga : this.Ga = Ze().then(function() {
                        if ("function" != typeof cn("universalLinks.subscribe", Nc)) throw _a("cordova-universal-links-plugin-fix is not installed");
                        if (void 0 === cn("BuildInfo.packageName", Nc)) throw _a("cordova-plugin-buildinfo is not installed");
                        if ("function" != typeof cn("cordova.plugins.browsertab.openUrl", Nc)) throw _a("cordova-plugin-browsertab is not installed");
                        if ("function" != typeof cn("cordova.InAppBrowser.open", Nc)) throw _a("cordova-plugin-inappbrowser is not installed")
                    }, function() {
                        throw new m("cordova-not-ready")
                    })
                }, _c.Lb = function(t, e) {
                    return e(new m("operation-not-supported-in-this-environment")), _t()
                }, _c.Jb = function() {
                    return St(new m("operation-not-supported-in-this-environment"))
                }, _c.Xb = function() {
                    return !1
                }, _c.Ub = function() {
                    return !0
                }, _c.Qb = function() {
                    return !0
                }, _c.Kb = function(t, e, n, i) {
                    if (this.c) return St(new m("redirect-operation-pending"));
                    var o = this,
                        r = Nc.document,
                        a = null,
                        s = null,
                        u = null,
                        c = null;
                    return this.c = _t().then(function() {
                        return Di(e), ka(o)
                    }).then(function() {
                        return Ta(o, t, e, n, i)
                    }).then(function() {
                        return new yt(function(t, e) {
                            s = function() {
                                var e = cn("cordova.plugins.browsertab.close", Nc);
                                return t(), "function" == typeof e && e(), o.a && "function" == typeof o.a.close && (o.a.close(), o.a = null), !1
                            }, o.Ca(s), u = function() {
                                a || (a = le(2e3).then(function() {
                                    e(new m("redirect-cancelled-by-user"))
                                }))
                            }, c = function() {
                                Sn() && u()
                            }, r.addEventListener("resume", u, !1), un().toLowerCase().match(/android/) || r.addEventListener("visibilitychange", c, !1)
                        }).o(function(t) {
                            return Ea(o).then(function() {
                                throw t
                            })
                        })
                    }).ma(function() {
                        u && r.removeEventListener("resume", u, !1), c && r.removeEventListener("visibilitychange", c, !1), a && a.cancel(), s && o.Qa(s), o.c = null
                    })
                }, _c.Ca = function(t) {
                    this.b.push(t), ka(this).o(function(e) {
                        "auth/invalid-cordova-configuration" === e.code && (e = new Ri("unknown", null, null, null, new m("no-auth-event")), t(e))
                    })
                }, _c.Qa = function(t) {
                    P(this.b, function(e) {
                        return e == t
                    })
                };
                var Ip = {
                    name: "pendingRedirect",
                    F: "session"
                };
                Ma.prototype.reset = function() {
                    this.f = !1, this.a.Qa(this.l), this.a = La(this.D, this.u, this.m), this.i = {}
                }, Ma.prototype.s = function(t) {
                    if (!t) throw new m("invalid-auth-event");
                    if (Oc() - this.w >= 6e5 && (this.i = {}, this.w = 0), t && t.getUid() && this.i.hasOwnProperty(t.getUid())) return !1;
                    for (var e = !1, n = 0; this.h.length > n; n++) {
                        var i = this.h[n];
                        if (i.Cb(t.c, t.b)) {
                            (e = this.c[t.c]) && (e.h(t, i), t && (t.f || t.b) && (this.i[t.getUid()] = !0, this.w = Oc())), e = !0;
                            break
                        }
                    }
                    return Ka(this.b), e
                };
                var Tp = new _n(2e3, 1e4),
                    Np = new _n(3e4, 6e4);
                Ma.prototype.pa = function() {
                    return this.b.pa()
                };
                var kp = {};
                Wa.prototype.reset = function() {
                    this.b = null, this.a && (this.a.cancel(), this.a = null)
                }, Wa.prototype.h = function(t, e) {
                    if (t) {
                        this.reset(), this.g = !0;
                        var n = t.c,
                            i = t.b,
                            o = t.a && "auth/web-storage-unsupported" == t.a.code,
                            r = t.a && "auth/operation-not-supported-in-this-environment" == t.a.code;
                        this.i = !(!o && !r), "unknown" != n || o || r ? t.a ? (Ya(this, !0, null, t.a), _t()) : e.Da(n, i) ? za(this, t, e) : St(new m("invalid-auth-event")) : (Ya(this, !1, null, null), _t())
                    } else St(new m("invalid-auth-event"))
                }, Wa.prototype.pa = function() {
                    var t = this;
                    return new yt(function(e, n) {
                        t.b ? t.b().then(e, n) : (t.f.push(e), t.c.push(n), $a(t))
                    })
                }, Za.prototype.h = function(t, e) {
                    if (t) {
                        var n = t.c,
                            i = t.b;
                        t.a ? (e.la(t.c, null, t.a, t.b), _t()) : e.Da(n, i) ? Qa(t, e) : St(new m("invalid-auth-event"))
                    } else St(new m("invalid-auth-event"))
                }, es.prototype.confirm = function(t) {
                    return t = Li(this.verificationId, t), this.a(t)
                };
                var Ep = "mfaInfo",
                    Cp = "mfaPendingCredential";
                os.prototype.Pc = function(t) {
                    var e = this;
                    return t.ob(this.a.b, this.c).then(function(t) {
                        var n = V(e.f);
                        return delete n[Ep], delete n[Cp], F(n, t), e.g(n)
                    })
                }, d(rs, m), ss.prototype.ob = function(t, e, n) {
                    return e.type == Xh ? us(this, t, e, n) : cs(this, t, e)
                }, d(ls, ss), d(hs, ls), d(fs, Ft), _c = ps.prototype, _c.wc = function(t) {
                    ms(this, ds(t.ed))
                }, _c.Ob = function() {
                    return this.a.I().then(function(t) {
                        return new ri(t, null)
                    })
                }, _c.dc = function(t, e) {
                    var n = this,
                        i = this.a.a;
                    return this.Ob().then(function(n) {
                        return t.ob(i, n, e)
                    }).then(function(t) {
                        return Xs(n.a, t), n.a.reload()
                    })
                }, _c.$c = function(t) {
                    var e = this,
                        n = "string" == typeof t ? t : t.uid,
                        i = this.a.a;
                    return this.a.I().then(function(t) {
                        return cr(i, tp, {
                            idToken: t,
                            mfaEnrollmentId: n
                        })
                    }).then(function(t) {
                        var i = Vc(e.b, function(t) {
                            return t.uid != n
                        });
                        return ms(e, i), Xs(e.a, t), e.a.reload().o(function(t) {
                            if ("auth/user-token-expired" != t.code) throw t
                        })
                    })
                }, _c.v = function() {
                    return {
                        multiFactor: {
                            enrolledFactors: Fc(this.b, function(t) {
                                return t.v()
                            })
                        }
                    }
                }, vs.prototype.start = function() {
                    this.a = this.c, ys(this, !0)
                }, vs.prototype.stop = function() {
                    this.b && (this.b.cancel(), this.b = null)
                }, bs.prototype.v = function() {
                    return {
                        apiKey: this.c.c,
                        refreshToken: this.a,
                        accessToken: this.b && "" + this.b,
                        expirationTime: ws(this)
                    }
                }, bs.prototype.getToken = function(t) {
                    return t = !!t, this.b && !this.a ? St(new m("user-token-expired")) : t || !this.b || Oc() > ws(this) - 3e4 ? this.a ? Is(this, {
                        grant_type: "refresh_token",
                        refresh_token: this.a
                    }) : _t(null) : _t({
                        accessToken: "" + this.b,
                        refreshToken: this.a
                    })
                }, Ts.prototype.v = function() {
                    return {
                        lastLoginAt: this.b,
                        createdAt: this.a
                    }
                }, d(Es, re), Es.prototype.va = function(t) {
                    this.oa = t, Vo(this.a, t)
                }, Es.prototype.ja = function() {
                    return this.oa
                }, Es.prototype.Ea = function() {
                    return M(this.W)
                }, Es.prototype.Ma = function() {
                    this.B.b && (this.B.stop(), this.B.start())
                }, An(Es.prototype, "providerId", "firebase"), _c = Es.prototype, _c.reload = function() {
                    var t = this;
                    return iu(this, Bs(this).then(function() {
                        return zs(t).then(function() {
                            return Rs(t)
                        }).then(Fs)
                    }))
                }, _c.mc = function(t) {
                    return this.I(t).then(function(t) {
                        return new is(t)
                    })
                }, _c.I = function(t) {
                    var e = this;
                    return iu(this, Bs(this).then(function() {
                        return e.b.getToken(t)
                    }).then(function(t) {
                        if (!t) throw new m("internal-error");
                        return t.accessToken != e.xa && (js(e, t.accessToken), e.dispatchEvent(new fs("tokenChanged"))), Ks(e, "refreshToken", t.refreshToken), t.accessToken
                    }))
                }, _c.Ic = function(t) {
                    if (!(t = t.users) || !t.length) throw new m("internal-error");
                    t = t[0], Vs(this, {
                        uid: t.localId,
                        displayName: t.displayName,
                        photoURL: t.photoUrl,
                        email: t.email,
                        emailVerified: !!t.emailVerified,
                        phoneNumber: t.phoneNumber,
                        lastLoginAt: t.lastLoginAt,
                        createdAt: t.createdAt,
                        tenantId: t.tenantId
                    });
                    for (var e = Ys(t), n = 0; e.length > n; n++) Gs(this, e[n]);
                    Ks(this, "isAnonymous", !(this.email && t.passwordHash || this.providerData && this.providerData.length)), this.dispatchEvent(new fs("userReloaded", {
                        ed: t
                    }))
                }, _c.Jc = function(t) {
                    return Cn("firebase.User.prototype.reauthenticateAndRetrieveDataWithCredential is deprecated. Please use firebase.User.prototype.reauthenticateWithCredential instead."), this.pb(t)
                }, _c.pb = function(t) {
                    var e = this,
                        n = null;
                    return iu(this, t.c(this.a, this.uid).then(function(t) {
                        return Xs(e, t), n = Zs(e, t, "reauthenticate"), e.h = null, e.reload()
                    }).then(function() {
                        return n
                    }), !0)
                }, _c.Ac = function(t) {
                    return Cn("firebase.User.prototype.linkAndRetrieveDataWithCredential is deprecated. Please use firebase.User.prototype.linkWithCredential instead."), this.mb(t)
                }, _c.mb = function(t) {
                    var e = this,
                        n = null;
                    return iu(this, $s(this, t.providerId).then(function() {
                        return e.I()
                    }).then(function(n) {
                        return t.b(e.a, n)
                    }).then(function(t) {
                        return n = Zs(e, t, "link"), Qs(e, t)
                    }).then(function() {
                        return n
                    }))
                }, _c.Bc = function(t, e) {
                    var n = this;
                    return iu(this, $s(this, "phone").then(function() {
                        return ns(Ps(n), t, e, f(n.mb, n))
                    }))
                }, _c.Kc = function(t, e) {
                    var n = this;
                    return iu(this, _t().then(function() {
                        return ns(Ps(n), t, e, f(n.pb, n))
                    }), !0)
                }, _c.xb = function(t) {
                    var e = this;
                    return iu(this, this.I().then(function(n) {
                        return e.a.xb(n, t)
                    }).then(function(t) {
                        return Xs(e, t), e.reload()
                    }))
                }, _c.cd = function(t) {
                    var e = this;
                    return iu(this, this.I().then(function(n) {
                        return t.b(e.a, n)
                    }).then(function(t) {
                        return Xs(e, t), e.reload()
                    }))
                }, _c.yb = function(t) {
                    var e = this;
                    return iu(this, this.I().then(function(n) {
                        return e.a.yb(n, t)
                    }).then(function(t) {
                        return Xs(e, t), e.reload()
                    }))
                }, _c.zb = function(t) {
                    if (void 0 === t.displayName && void 0 === t.photoURL) return Bs(this);
                    var e = this;
                    return iu(this, this.I().then(function(n) {
                        return e.a.zb(n, {
                            displayName: t.displayName,
                            photoUrl: t.photoURL
                        })
                    }).then(function(t) {
                        return Xs(e, t), Ks(e, "displayName", t.displayName || null), Ks(e, "photoURL", t.photoUrl || null), Uc(e.providerData, function(t) {
                            "password" === t.providerId && (An(t, "displayName", e.displayName), An(t, "photoURL", e.photoURL))
                        }), Rs(e)
                    }).then(Fs))
                }, _c.ad = function(t) {
                    var e = this;
                    return iu(this, zs(this).then(function(n) {
                        return A(Hs(e), t) ? er(e.a, n, [t]).then(function(t) {
                            var n = {};
                            return Uc(t.providerUserInfo || [], function(t) {
                                n[t.providerId] = !0
                            }), Uc(Hs(e), function(t) {
                                n[t] || Ws(e, t)
                            }), n[Mi.PROVIDER_ID] || An(e, "phoneNumber", null), Rs(e)
                        }) : Rs(e).then(function() {
                            throw new m("no-such-provider")
                        })
                    }))
                }, _c.delete = function() {
                    var t = this;
                    return iu(this, this.I().then(function(e) {
                        return cr(t.a, kf, {
                            idToken: e
                        })
                    }).then(function() {
                        t.dispatchEvent(new fs("userDeleted"))
                    })).then(function() {
                        for (var e = 0; t.N.length > e; e++) t.N[e].cancel("app-deleted");
                        Cs(t, null), Os(t, null), t.N = [], t.D = !0, Ls(t), An(t, "refreshToken", null), t.i && Ua(t.i, t)
                    })
                }, _c.Cb = function(t, e) {
                    return !!("linkViaPopup" == t && (this.g || null) == e && this.f || "reauthViaPopup" == t && (this.g || null) == e && this.f || "linkViaRedirect" == t && (this.fa || null) == e || "reauthViaRedirect" == t && (this.fa || null) == e)
                }, _c.la = function(t, e, n, i) {
                    "linkViaPopup" != t && "reauthViaPopup" != t || i != (this.g || null) || (n && this.w ? this.w(n) : e && !n && this.f && this.f(e), this.c && (this.c.cancel(), this.c = null), delete this.f, delete this.w)
                }, _c.Da = function(t, e) {
                    return "linkViaPopup" == t && e == (this.g || null) ? f(this.Hb, this) : "reauthViaPopup" == t && e == (this.g || null) ? f(this.Ib, this) : "linkViaRedirect" == t && (this.fa || null) == e ? f(this.Hb, this) : "reauthViaRedirect" == t && (this.fa || null) == e ? f(this.Ib, this) : null
                }, _c.Cc = function(t) {
                    var e = this;
                    return tu(this, "linkViaPopup", t, function() {
                        return $s(e, t.providerId).then(function() {
                            return Rs(e)
                        })
                    }, !1)
                }, _c.Lc = function(t) {
                    return tu(this, "reauthViaPopup", t, function() {
                        return _t()
                    }, !0)
                }, _c.Dc = function(t) {
                    var e = this;
                    return eu(this, "linkViaRedirect", t, function() {
                        return $s(e, t.providerId)
                    }, !1)
                }, _c.Mc = function(t) {
                    return eu(this, "reauthViaRedirect", t, function() {
                        return _t()
                    }, !0)
                }, _c.Hb = function(t, e, n, i) {
                    var o = this;
                    this.c && (this.c.cancel(), this.c = null);
                    var r = null;
                    return n = this.I().then(function(n) {
                        return ar(o.a, {
                            requestUri: t,
                            postBody: i,
                            sessionId: e,
                            idToken: n
                        })
                    }).then(function(t) {
                        return r = Zs(o, t, "link"), Qs(o, t)
                    }).then(function() {
                        return r
                    }), iu(this, n)
                }, _c.Ib = function(t, e, n, i) {
                    var o = this;
                    this.c && (this.c.cancel(), this.c = null);
                    var r = null;
                    return iu(this, _t().then(function() {
                        return si(sr(o.a, {
                            requestUri: t,
                            sessionId: e,
                            postBody: i,
                            tenantId: n
                        }), o.uid)
                    }).then(function(t) {
                        return r = Zs(o, t, "reauthenticate"), Xs(o, t), o.h = null, o.reload()
                    }).then(function() {
                        return r
                    }), !0)
                }, _c.qb = function(t) {
                    var e = this,
                        n = null;
                    return iu(this, this.I().then(function(e) {
                        return n = e, void 0 === t || U(t) ? {} : Hn(new Bn(t))
                    }).then(function(t) {
                        return e.a.qb(n, t)
                    }).then(function(t) {
                        if (e.email != t) return e.reload()
                    }).then(function() {}))
                }, _c.Ab = function(t, e) {
                    var n = this,
                        i = null;
                    return iu(this, this.I().then(function(t) {
                        return i = t, void 0 === e || U(e) ? {} : Hn(new Bn(e))
                    }).then(function(e) {
                        return n.a.Ab(i, t, e)
                    }).then(function(t) {
                        if (n.email != t) return n.reload()
                    }).then(function() {}))
                }, _c.hc = function(t) {
                    var e = null,
                        n = this;
                    return t = si(_t(t), n.uid).then(function(t) {
                        return e = Zs(n, t, "reauthenticate"), Xs(n, t), n.h = null, n.reload()
                    }).then(function() {
                        return e
                    }), iu(this, t, !0)
                }, _c.toJSON = function() {
                    return this.v()
                }, _c.v = function() {
                    var t = {
                        uid: this.uid,
                        displayName: this.displayName,
                        photoURL: this.photoURL,
                        email: this.email,
                        emailVerified: this.emailVerified,
                        phoneNumber: this.phoneNumber,
                        isAnonymous: this.isAnonymous,
                        tenantId: this.tenantId,
                        providerData: [],
                        apiKey: this.l,
                        appName: this.m,
                        authDomain: this.s,
                        stsTokenManager: this.b.v(),
                        redirectEventId: this.fa || null
                    };
                    return this.metadata && F(t, this.metadata.v()), Uc(this.providerData, function(e) {
                        t.providerData.push(xn(e))
                    }), F(t, this.O.v()), t
                };
                var Ap = {
                    name: "redirectUser",
                    F: "session"
                };
                hu.prototype.g = function() {
                    var t = this,
                        e = du("local");
                    bu(this, function() {
                        return _t().then(function() {
                            return t.c && "local" != t.c.F ? t.b.get(e, t.a) : null
                        }).then(function(n) {
                            if (n) return fu(t, "local").then(function() {
                                t.c = e
                            })
                        })
                    })
                };
                var Op = {
                    name: "persistence",
                    F: "session"
                };
                hu.prototype.tb = function(t) {
                    var e = null,
                        n = this;
                    return ia(t), bu(this, function() {
                        return t != n.c.F ? n.b.get(n.c, n.a).then(function(i) {
                            return e = i, fu(n, t)
                        }).then(function() {
                            if (n.c = du(t), e) return n.b.set(n.c, e, n.a)
                        }) : _t()
                    })
                }, d(wu, re), d(_u, Ft), d(Su, Ft), _c = wu.prototype, _c.tb = function(t) {
                    return t = this.i.tb(t), Uu(this, t)
                }, _c.va = function(t) {
                    this.$ === t || this.l || (this.$ = t, Vo(this.b, this.$), this.dispatchEvent(new _u(this.ja())))
                }, _c.ja = function() {
                    return this.$
                }, _c.dd = function() {
                    var t = Nc.navigator;
                    this.va(t ? t.languages && t.languages[0] || t.language || t.userLanguage || null : null)
                }, _c.Ec = function(t) {
                    this.N.push(t), Fo(this.b, i.a.SDK_VERSION ? sn(i.a.SDK_VERSION, this.N) : null), this.dispatchEvent(new Su(this.N))
                }, _c.Ea = function() {
                    return M(this.N)
                }, _c.ub = function(t) {
                    this.R === t || this.l || (this.R = t, this.b.b = this.R)
                }, _c.S = function() {
                    return this.R
                }, _c.toJSON = function() {
                    return {
                        apiKey: Mu(this).options.apiKey,
                        authDomain: Mu(this).options.authDomain,
                        appName: Mu(this).name,
                        currentUser: Lu(this) && Lu(this).v()
                    }
                }, _c.Cb = function(t, e) {
                    switch (t) {
                        case "unknown":
                        case "signInViaRedirect":
                            return !0;
                        case "signInViaPopup":
                            return this.g == e && !!this.f;
                        default:
                            return !1
                    }
                }, _c.la = function(t, e, n, i) {
                    "signInViaPopup" == t && this.g == i && (n && this.w ? this.w(n) : e && !n && this.f && this.f(e), this.c && (this.c.cancel(), this.c = null), delete this.f, delete this.w)
                }, _c.Da = function(t, e) {
                    return "signInViaRedirect" == t || "signInViaPopup" == t && this.g == e && this.f ? f(this.gc, this) : null
                }, _c.gc = function(t, e, n, i) {
                    var o = this,
                        r = {
                            requestUri: t,
                            postBody: i,
                            sessionId: e,
                            tenantId: n
                        };
                    return this.c && (this.c.cancel(), this.c = null), o.Z.then(function() {
                        return xu(o, rr(o.b, r))
                    })
                }, _c.Vc = function(t) {
                    if (!hn()) return St(new m("operation-not-supported-in-this-environment"));
                    var e = this,
                        n = Yn(t.providerId),
                        o = yn(),
                        r = null;
                    (!dn() || tn()) && Mu(this).options.authDomain && t.isOAuthProvider && (r = Tr(Mu(this).options.authDomain, Mu(this).options.apiKey, Mu(this).name, "signInViaPopup", t, null, o, i.a.SDK_VERSION || null, null, null, this.S()));
                    var a = Je(r, n && n.ta, n && n.sa);
                    return n = Tu(this).then(function(n) {
                        return Va(n, a, "signInViaPopup", t, o, !!r, e.S())
                    }).then(function() {
                        return new yt(function(t, n) {
                            e.la("signInViaPopup", null, new m("cancelled-popup-request"), e.g), e.f = t, e.w = n, e.g = o, e.c = Ha(e.a, e, "signInViaPopup", a, o)
                        })
                    }).then(function(t) {
                        return a && Xe(a), t ? Pn(t) : null
                    }).o(function(t) {
                        throw a && Xe(a), t
                    }), Uu(this, n)
                }, _c.Wc = function(t) {
                    if (!hn()) return St(new m("operation-not-supported-in-this-environment"));
                    var e = this;
                    return Uu(this, Tu(this).then(function() {
                        return mu(e.i)
                    }).then(function() {
                        return Ba(e.a, "signInViaRedirect", t, void 0, e.S())
                    }))
                }, _c.pa = function() {
                    var t = this;
                    return ku(this).then(function(e) {
                        return t.a && qa(t.a.b), e
                    }).o(function(e) {
                        throw t.a && qa(t.a.b), e
                    })
                }, _c.bd = function(t) {
                    if (!t) return St(new m("null-user"));
                    if (this.R != t.tenantId) return St(new m("tenant-id-mismatch"));
                    var e = this,
                        n = {};
                    n.apiKey = Mu(this).options.apiKey, n.authDomain = Mu(this).options.authDomain, n.appName = Mu(this).name;
                    var i = su(t, n, e.B, e.Ea());
                    return Uu(this, this.h.then(function() {
                        if (Mu(e).options.apiKey != t.l) return i.reload()
                    }).then(function() {
                        return Lu(e) && t.uid == Lu(e).uid ? (qs(Lu(e), t), e.ca(t)) : (Cu(e, i), Us(i), e.ca(i))
                    }).then(function() {
                        Du(e)
                    }))
                }, _c.wb = function() {
                    var t = this;
                    return Uu(this, this.h.then(function() {
                        return t.a && qa(t.a.b), Lu(t) ? (Cu(t, null), gu(t.i).then(function() {
                            Du(t)
                        })) : _t()
                    }))
                }, _c.Xc = function() {
                    var t = this;
                    return yu(this.i, Mu(this).options.authDomain).then(function(e) {
                        if (!t.l) {
                            var n;
                            if (n = Lu(t) && e) {
                                n = Lu(t).uid;
                                var i = e.uid;
                                n = void 0 !== n && null !== n && "" !== n && void 0 !== i && null !== i && "" !== i && n == i
                            }
                            if (n) return qs(Lu(t), e), Lu(t).I();
                            (Lu(t) || e) && (Cu(t, e), e && (Us(e), e.ga = t.B), t.a && Ra(t.a, t), Du(t))
                        }
                    })
                }, _c.ca = function(t) {
                    return vu(this.i, t)
                }, _c.jc = function() {
                    Du(this), this.ca(Lu(this))
                }, _c.uc = function() {
                    this.wb()
                }, _c.vc = function() {
                    this.wb()
                }, _c.ic = function(t) {
                    var e = this;
                    return this.h.then(function() {
                        return xu(e, _t(t))
                    })
                }, _c.xc = function(t) {
                    var e = this;
                    this.addAuthTokenListener(function() {
                        t.next(Lu(e))
                    })
                }, _c.yc = function(t) {
                    var e = this;
                    Ru(this, function() {
                        t.next(Lu(e))
                    })
                }, _c.Gc = function(t, e, n) {
                    var i = this;
                    return this.aa && Promise.resolve().then(function() {
                        s(t) ? t(Lu(i)) : s(t.next) && t.next(Lu(i))
                    }), this.$b(t, e, n)
                }, _c.Fc = function(t, e, n) {
                    var i = this;
                    return this.aa && Promise.resolve().then(function() {
                        i.W = i.getUid(), s(t) ? t(Lu(i)) : s(t.next) && t.next(Lu(i))
                    }), this.ac(t, e, n)
                }, _c.kc = function(t) {
                    var e = this;
                    return Uu(this, this.h.then(function() {
                        return Lu(e) ? Lu(e).I(t).then(function(t) {
                            return {
                                accessToken: t
                            }
                        }) : null
                    }))
                }, _c.Rc = function(t) {
                    var e = this;
                    return this.h.then(function() {
                        return xu(e, cr(e.b, Jf, {
                            token: t
                        }))
                    }).then(function(t) {
                        var n = t.user;
                        return Ks(n, "isAnonymous", !1), e.ca(n), t
                    })
                }, _c.Sc = function(t, e) {
                    var n = this;
                    return this.h.then(function() {
                        return xu(n, cr(n.b, Yf, {
                            email: t,
                            password: e
                        }))
                    })
                }, _c.cc = function(t, e) {
                    var n = this;
                    return this.h.then(function() {
                        return xu(n, cr(n.b, Tf, {
                            email: t,
                            password: e
                        }))
                    })
                }, _c.Ya = function(t) {
                    var e = this;
                    return this.h.then(function() {
                        return xu(e, t.ia(e.b))
                    })
                }, _c.Qc = function(t) {
                    return Cn("firebase.auth.Auth.prototype.signInAndRetrieveDataWithCredential is deprecated. Please use firebase.auth.Auth.prototype.signInWithCredential instead."), this.Ya(t)
                }, _c.vb = function() {
                    var t = this;
                    return this.h.then(function() {
                        var e = Lu(t);
                        return e && e.isAnonymous ? Pn({
                            user: e,
                            credential: null,
                            additionalUserInfo: Pn({
                                providerId: null,
                                isNewUser: !1
                            }),
                            operationType: "signIn"
                        }) : xu(t, t.b.vb()).then(function(e) {
                            var n = e.user;
                            return Ks(n, "isAnonymous", !0), t.ca(n), e
                        })
                    })
                }, _c.getUid = function() {
                    return Lu(this) && Lu(this).uid || null
                }, _c.bc = function(t) {
                    this.addAuthTokenListener(t), ++this.s > 0 && Lu(this) && Ms(Lu(this))
                }, _c.Nc = function(t) {
                    var e = this;
                    Uc(this.m, function(n) {
                        n == t && e.s--
                    }), 0 > this.s && (this.s = 0), 0 == this.s && Lu(this) && Ls(Lu(this)), this.removeAuthTokenListener(t)
                }, _c.addAuthTokenListener = function(t) {
                    var e = this;
                    this.m.push(t), Uu(this, this.h.then(function() {
                        e.l || A(e.m, t) && t(ju(e))
                    }))
                }, _c.removeAuthTokenListener = function(t) {
                    P(this.m, function(e) {
                        return e == t
                    })
                }, _c.delete = function() {
                    this.l = !0;
                    for (var t = 0; this.P.length > t; t++) this.P[t].cancel("app-deleted");
                    return this.P = [], this.i && (t = this.i, t.b.removeListener(du("local"), t.a, this.oa)), this.a && (Ua(this.a, this), qa(this.a.b)), Promise.resolve()
                }, _c.fc = function(t) {
                    return Uu(this, zo(this.b, t))
                }, _c.zc = function(t) {
                    return !!Ai(t)
                }, _c.sb = function(t, e) {
                    var n = this;
                    return Uu(this, _t().then(function() {
                        var t = new Bn(e);
                        if (!t.c) throw new m("argument-error", jh + " must be true when sending  link to email");
                        return Hn(t)
                    }).then(function(e) {
                        return n.b.sb(t, e)
                    }).then(function() {}))
                }, _c.fd = function(t) {
                    return this.Pa(t).then(function(t) {
                        return t.data.email
                    })
                }, _c.jb = function(t, e) {
                    return Uu(this, this.b.jb(t, e).then(function() {}))
                }, _c.Pa = function(t) {
                    return Uu(this, this.b.Pa(t).then(function(t) {
                        return new Un(t)
                    }))
                }, _c.fb = function(t) {
                    return Uu(this, this.b.fb(t).then(function() {}))
                }, _c.rb = function(t, e) {
                    var n = this;
                    return Uu(this, _t().then(function() {
                        return void 0 === e || U(e) ? {} : Hn(new Bn(e))
                    }).then(function(e) {
                        return n.b.rb(t, e)
                    }).then(function() {}))
                }, _c.Uc = function(t, e) {
                    return Uu(this, ns(this, t, e, f(this.Ya, this)))
                }, _c.Tc = function(t, e) {
                    var n = this;
                    return Uu(this, _t().then(function() {
                        var i = e || Ge(),
                            o = Ci(t, i);
                        if (!(i = Ai(i))) throw new m("argument-error", "Invalid email link!");
                        if (i.tenantId !== n.S()) throw new m("tenant-id-mismatch");
                        return n.Ya(o)
                    }))
                }, Vu.prototype.render = function() {}, Vu.prototype.reset = function() {}, Vu.prototype.getResponse = function() {}, Vu.prototype.execute = function() {};
                var Pp = null;
                Fu.prototype.render = function(t, e) {
                    return this.a["" + this.b] = new Gu(t, e), this.b++
                }, Fu.prototype.reset = function(t) {
                    var e = Bu(this, t);
                    t = Hu(t), e && t && (e.delete(), delete this.a[t])
                }, Fu.prototype.getResponse = function(t) {
                    return (t = Bu(this, t)) ? t.getResponse() : null
                }, Fu.prototype.execute = function(t) {
                    (t = Bu(this, t)) && t.execute()
                }, Gu.prototype.getResponse = function() {
                    return Wu(this), this.b
                }, Gu.prototype.execute = function() {
                    Wu(this);
                    var t = this;
                    this.a || (this.a = setTimeout(function() {
                        t.b = rn();
                        var e = t.c.callback,
                            n = t.c["expired-callback"];
                        if (e) try {
                            e(t.b)
                        } catch (t) {}
                        t.a = setTimeout(function() {
                            if (t.a = null, t.b = null, n) try {
                                n()
                            } catch (t) {}
                            t.h && t.execute()
                        }, 6e4)
                    }, 500))
                }, Gu.prototype.delete = function() {
                    Wu(this), this.g = !0, clearTimeout(this.a), this.a = null, $t(this.f, "click", this.i)
                }, An(Ku, "FACTOR_ID", "phone"), qu.prototype.g = function() {
                    return Pp || (Pp = new Fu), _t(Pp)
                }, qu.prototype.c = function() {};
                var xp = null,
                    Mp = new H(tl, "https://www.google.com/recaptcha/api.js?onload=%{onload}&render=explicit&hl=%{hl}"),
                    Lp = new _n(3e4, 6e4);
                zu.prototype.g = function(t) {
                    var e = this;
                    return new yt(function(n, i) {
                        var o = setTimeout(function() {
                            i(new m("network-request-failed"))
                        }, Lp.get());
                        !Nc.grecaptcha || t !== e.f && !e.b ? (Nc[e.a] = function() {
                            if (Nc.grecaptcha) {
                                e.f = t;
                                var r = Nc.grecaptcha.render;
                                Nc.grecaptcha.render = function(t, n) {
                                    return t = r(t, n), e.b++, t
                                }, clearTimeout(o), n(Nc.grecaptcha)
                            } else clearTimeout(o), i(new m("internal-error"));
                            delete Nc[e.a]
                        }, _t(xo(q(Mp, {
                            onload: e.a,
                            hl: t || ""
                        }))).o(function() {
                            clearTimeout(o), i(new m("internal-error", "Unable to load external reCAPTCHA dependencies!"))
                        })) : (clearTimeout(o), n(Nc.grecaptcha))
                    })
                }, zu.prototype.c = function() {
                    this.b--
                };
                var jp = null,
                    Dp = "callback",
                    Rp = "expired-callback",
                    Up = "sitekey",
                    Vp = "size";
                _c = Xu.prototype, _c.Ga = function() {
                    var t = this;
                    return this.f ? this.f : this.f = $u(this, _t().then(function() {
                        if (fn() && !en()) return $e();
                        throw new m("operation-not-supported-in-this-environment", "RecaptchaVerifier is only supported in a browser HTTP/HTTPS environment.")
                    }).then(function() {
                        return t.m.g(t.w())
                    }).then(function(e) {
                        return t.g = e, cr(t.s, Uf, {})
                    }).then(function(e) {
                        t.a[Up] = e.recaptchaSiteKey
                    }).o(function(e) {
                        throw t.f = null, e
                    }))
                }, _c.render = function() {
                    Zu(this);
                    var t = this;
                    return $u(this, this.Ga().then(function() {
                        if (null === t.c) {
                            var e = t.u;
                            if (!t.i) {
                                var n = st(e);
                                e = ct("DIV"), n.appendChild(e)
                            }
                            t.c = t.g.render(e, t.a)
                        }
                        return t.c
                    }))
                }, _c.verify = function() {
                    Zu(this);
                    var t = this;
                    return $u(this, this.render().then(function(e) {
                        return new yt(function(n) {
                            var i = t.g.getResponse(e);
                            if (i) n(i);
                            else {
                                var o = function(e) {
                                    e && (Yu(t, o), n(e))
                                };
                                t.l.push(o), t.i && t.g.execute(t.c)
                            }
                        })
                    }))
                }, _c.reset = function() {
                    Zu(this), null !== this.c && this.g.reset(this.c)
                }, _c.clear = function() {
                    Zu(this), this.D = !0, this.m.c();
                    for (var t = 0; this.h.length > t; t++) this.h[t].cancel("RecaptchaVerifier instance has been destroyed.");
                    if (!this.i) {
                        t = st(this.u);
                        for (var e; e = t.firstChild;) t.removeChild(e)
                    }
                }, d(Qu, Xu);
                var Fp = "First Second Third Fourth Fifth Sixth Seventh Eighth Ninth".split(" ");
                vc(wu.prototype, {
                        fb: {
                            name: "applyActionCode",
                            j: [ec("code")]
                        },
                        Pa: {
                            name: "checkActionCode",
                            j: [ec("code")]
                        },
                        jb: {
                            name: "confirmPasswordReset",
                            j: [ec("code"), ec("newPassword")]
                        },
                        cc: {
                            name: "createUserWithEmailAndPassword",
                            j: [ec("email"), ec("password")]
                        },
                        fc: {
                            name: "fetchSignInMethodsForEmail",
                            j: [ec("email")]
                        },
                        pa: {
                            name: "getRedirectResult",
                            j: []
                        },
                        zc: {
                            name: "isSignInWithEmailLink",
                            j: [ec("emailLink")]
                        },
                        Fc: {
                            name: "onAuthStateChanged",
                            j: [mc(ic(), oc(), "nextOrObserver"), oc("opt_error", !0), oc("opt_completed", !0)]
                        },
                        Gc: {
                            name: "onIdTokenChanged",
                            j: [mc(ic(), oc(), "nextOrObserver"), oc("opt_error", !0), oc("opt_completed", !0)]
                        },
                        rb: {
                            name: "sendPasswordResetEmail",
                            j: [ec("email"), mc(ic("opt_actionCodeSettings", !0), rc(null, !0), "opt_actionCodeSettings", !0)]
                        },
                        sb: {
                            name: "sendSignInLinkToEmail",
                            j: [ec("email"), ic("actionCodeSettings")]
                        },
                        tb: {
                            name: "setPersistence",
                            j: [ec("persistence")]
                        },
                        Qc: {
                            name: "signInAndRetrieveDataWithCredential",
                            j: [cc()]
                        },
                        vb: {
                            name: "signInAnonymously",
                            j: []
                        },
                        Ya: {
                            name: "signInWithCredential",
                            j: [cc()]
                        },
                        Rc: {
                            name: "signInWithCustomToken",
                            j: [ec("token")]
                        },
                        Sc: {
                            name: "signInWithEmailAndPassword",
                            j: [ec("email"), ec("password")]
                        },
                        Tc: {
                            name: "signInWithEmailLink",
                            j: [ec("email"), ec("emailLink", !0)]
                        },
                        Uc: {
                            name: "signInWithPhoneNumber",
                            j: [ec("phoneNumber"), dc()]
                        },
                        Vc: {
                            name: "signInWithPopup",
                            j: [hc()]
                        },
                        Wc: {
                            name: "signInWithRedirect",
                            j: [hc()]
                        },
                        bd: {
                            name: "updateCurrentUser",
                            j: [mc(function() {
                                return {
                                    name: "user",
                                    J: "an instance of Firebase User",
                                    optional: !1,
                                    K: function(t) {
                                        return !!(t && t instanceof Es)
                                    }
                                }
                            }(), rc(), "user")]
                        },
                        wb: {
                            name: "signOut",
                            j: []
                        },
                        toJSON: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        },
                        dd: {
                            name: "useDeviceLanguage",
                            j: []
                        },
                        fd: {
                            name: "verifyPasswordResetCode",
                            j: [ec("code")]
                        }
                    }), gc(wu.prototype, {
                        lc: {
                            name: "languageCode",
                            gb: mc(ec(), rc(), "languageCode")
                        },
                        ti: {
                            name: "tenantId",
                            gb: mc(ec(), rc(), "tenantId")
                        }
                    }), wu.Persistence = pp, wu.Persistence.LOCAL = "local", wu.Persistence.SESSION = "session", wu.Persistence.NONE = "none", vc(Es.prototype, {
                        delete: {
                            name: "delete",
                            j: []
                        },
                        mc: {
                            name: "getIdTokenResult",
                            j: [nc("opt_forceRefresh", !0)]
                        },
                        I: {
                            name: "getIdToken",
                            j: [nc("opt_forceRefresh", !0)]
                        },
                        Ac: {
                            name: "linkAndRetrieveDataWithCredential",
                            j: [cc()]
                        },
                        mb: {
                            name: "linkWithCredential",
                            j: [cc()]
                        },
                        Bc: {
                            name: "linkWithPhoneNumber",
                            j: [ec("phoneNumber"), dc()]
                        },
                        Cc: {
                            name: "linkWithPopup",
                            j: [hc()]
                        },
                        Dc: {
                            name: "linkWithRedirect",
                            j: [hc()]
                        },
                        Jc: {
                            name: "reauthenticateAndRetrieveDataWithCredential",
                            j: [cc()]
                        },
                        pb: {
                            name: "reauthenticateWithCredential",
                            j: [cc()]
                        },
                        Kc: {
                            name: "reauthenticateWithPhoneNumber",
                            j: [ec("phoneNumber"), dc()]
                        },
                        Lc: {
                            name: "reauthenticateWithPopup",
                            j: [hc()]
                        },
                        Mc: {
                            name: "reauthenticateWithRedirect",
                            j: [hc()]
                        },
                        reload: {
                            name: "reload",
                            j: []
                        },
                        qb: {
                            name: "sendEmailVerification",
                            j: [mc(ic("opt_actionCodeSettings", !0), rc(null, !0), "opt_actionCodeSettings", !0)]
                        },
                        toJSON: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        },
                        ad: {
                            name: "unlink",
                            j: [ec("provider")]
                        },
                        xb: {
                            name: "updateEmail",
                            j: [ec("email")]
                        },
                        yb: {
                            name: "updatePassword",
                            j: [ec("password")]
                        },
                        cd: {
                            name: "updatePhoneNumber",
                            j: [cc("phone")]
                        },
                        zb: {
                            name: "updateProfile",
                            j: [ic("profile")]
                        },
                        Ab: {
                            name: "verifyBeforeUpdateEmail",
                            j: [ec("email"), mc(ic("opt_actionCodeSettings", !0), rc(null, !0), "opt_actionCodeSettings", !0)]
                        }
                    }), vc(Fu.prototype, {
                        execute: {
                            name: "execute"
                        },
                        render: {
                            name: "render"
                        },
                        reset: {
                            name: "reset"
                        },
                        getResponse: {
                            name: "getResponse"
                        }
                    }), vc(Vu.prototype, {
                        execute: {
                            name: "execute"
                        },
                        render: {
                            name: "render"
                        },
                        reset: {
                            name: "reset"
                        },
                        getResponse: {
                            name: "getResponse"
                        }
                    }), vc(yt.prototype, {
                        ma: {
                            name: "finally"
                        },
                        o: {
                            name: "catch"
                        },
                        then: {
                            name: "then"
                        }
                    }), gc(ts.prototype, {
                        appVerificationDisabled: {
                            name: "appVerificationDisabledForTesting",
                            gb: nc("appVerificationDisabledForTesting")
                        }
                    }), vc(es.prototype, {
                        confirm: {
                            name: "confirm",
                            j: [ec("verificationCode")]
                        }
                    }), yc(ai, "fromJSON", function(t) {
                        t = "string" == typeof t ? JSON.parse(t) : t;
                        for (var e, n = [pi, ki, Pi, li], i = 0; n.length > i; i++)
                            if (e = n[i](t)) return e;
                        return null
                    }, [mc(ec(), ic(), "json")]), yc(Ei, "credential", function(t, e) {
                        return new Ni(t, e)
                    }, [ec("email"), ec("password")]), vc(Ni.prototype, {
                        v: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), vc(gi.prototype, {
                        Aa: {
                            name: "addScope",
                            j: [ec("scope")]
                        },
                        Ia: {
                            name: "setCustomParameters",
                            j: [ic("customOAuthParameters")]
                        }
                    }), yc(gi, "credential", yi, [mc(ec(), ic(), "token")]), yc(Ei, "credentialWithLink", Ci, [ec("email"), ec("emailLink")]), vc(bi.prototype, {
                        Aa: {
                            name: "addScope",
                            j: [ec("scope")]
                        },
                        Ia: {
                            name: "setCustomParameters",
                            j: [ic("customOAuthParameters")]
                        }
                    }), yc(bi, "credential", wi, [mc(ec(), ic(), "token")]), vc(_i.prototype, {
                        Aa: {
                            name: "addScope",
                            j: [ec("scope")]
                        },
                        Ia: {
                            name: "setCustomParameters",
                            j: [ic("customOAuthParameters")]
                        }
                    }), yc(_i, "credential", Si, [mc(ec(), mc(ic(), rc()), "idToken"), mc(ec(), rc(), "accessToken", !0)]), vc(Ii.prototype, {
                        Ia: {
                            name: "setCustomParameters",
                            j: [ic("customOAuthParameters")]
                        }
                    }), yc(Ii, "credential", Ti, [mc(ec(), ic(), "token"), ec("secret", !0)]), vc(vi.prototype, {
                        Aa: {
                            name: "addScope",
                            j: [ec("scope")]
                        },
                        credential: {
                            name: "credential",
                            j: [mc(ec(), mc(ic(), rc()), "optionsOrIdToken"), mc(ec(), rc(), "accessToken", !0)]
                        },
                        Ia: {
                            name: "setCustomParameters",
                            j: [ic("customOAuthParameters")]
                        }
                    }), vc(hi.prototype, {
                        v: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), vc(ui.prototype, {
                        v: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), yc(Mi, "credential", Li, [ec("verificationId"), ec("verificationCode")]), vc(Mi.prototype, {
                        cb: {
                            name: "verifyPhoneNumber",
                            j: [mc(ec(), function() {
                                return {
                                    name: "phoneInfoOptions",
                                    J: "valid phone info options",
                                    optional: !1,
                                    K: function(t) {
                                        return !!t && (t.session && t.phoneNumber ? fc(t.session, Xh) && "string" == typeof t.phoneNumber : t.session && t.multiFactorHint ? fc(t.session, Jh) && pc(t.multiFactorHint) : t.session && t.multiFactorUid ? fc(t.session, Jh) && "string" == typeof t.multiFactorUid : !!t.phoneNumber && "string" == typeof t.phoneNumber)
                                    }
                                }
                            }(), "phoneInfoOptions"), dc()]
                        }
                    }), vc(Oi.prototype, {
                        v: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), vc(m.prototype, {
                        toJSON: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), vc(Hi.prototype, {
                        toJSON: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), vc(Bi.prototype, {
                        toJSON: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), vc(rs.prototype, {
                        toJSON: {
                            name: "toJSON",
                            j: [ec(null, !0)]
                        }
                    }), vc(os.prototype, {
                        Pc: {
                            name: "resolveSignIn",
                            j: [lc()]
                        }
                    }), vc(ps.prototype, {
                        Ob: {
                            name: "getSession",
                            j: []
                        },
                        dc: {
                            name: "enroll",
                            j: [lc(), ec("displayName", !0)]
                        },
                        $c: {
                            name: "unenroll",
                            j: [mc({
                                name: "multiFactorInfo",
                                J: "a valid multiFactorInfo",
                                optional: !1,
                                K: pc
                            }, ec(), "multiFactorInfoIdentifier")]
                        }
                    }), vc(Qu.prototype, {
                        clear: {
                            name: "clear",
                            j: []
                        },
                        render: {
                            name: "render",
                            j: []
                        },
                        verify: {
                            name: "verify",
                            j: []
                        }
                    }), yc(Vn, "parseLink", Fn, [ec("link")]), yc(Ku, "assertion", function(t) {
                        return new hs(t)
                    }, [cc("phone")]),
                    function() {
                        if (void 0 === i.a || !i.a.INTERNAL || !i.a.INTERNAL.registerComponent) throw Error("Cannot find the firebase namespace; be sure to include firebase-app.js before this library.");
                        var t = {
                            ActionCodeInfo: {
                                Operation: {
                                    EMAIL_SIGNIN: dh,
                                    PASSWORD_RESET: "PASSWORD_RESET",
                                    RECOVER_EMAIL: "RECOVER_EMAIL",
                                    REVERT_SECOND_FACTOR_ADDITION: ph,
                                    VERIFY_AND_CHANGE_EMAIL: mh,
                                    VERIFY_EMAIL: "VERIFY_EMAIL"
                                }
                            },
                            Auth: wu,
                            AuthCredential: ai,
                            Error: m
                        };
                        yc(t, "EmailAuthProvider", Ei, []), yc(t, "FacebookAuthProvider", gi, []), yc(t, "GithubAuthProvider", bi, []), yc(t, "GoogleAuthProvider", _i, []), yc(t, "TwitterAuthProvider", Ii, []), yc(t, "OAuthProvider", vi, [ec("providerId")]), yc(t, "SAMLAuthProvider", mi, [ec("providerId")]), yc(t, "PhoneAuthProvider", Mi, [sc()]), yc(t, "RecaptchaVerifier", Qu, [mc(ec(), ac(), "recaptchaContainer"), ic("recaptchaParameters", !0), uc()]), yc(t, "ActionCodeURL", Vn, []), yc(t, "PhoneMultiFactorGenerator", Ku, []), i.a.INTERNAL.registerComponent({
                            name: "auth",
                            instanceFactory: function(t) {
                                return t = t.getProvider("app").getImmediate(), new wu(t)
                            },
                            multipleInstances: !1,
                            serviceProps: t,
                            instantiationMode: "LAZY",
                            type: "PUBLIC"
                        }), i.a.INTERNAL.registerComponent({
                            name: "auth-internal",
                            instanceFactory: function(t) {
                                return t = t.getProvider("auth").getImmediate(), {
                                    getUid: f(t.getUid, t),
                                    getToken: f(t.kc, t),
                                    addAuthTokenListener: f(t.bc, t),
                                    removeAuthTokenListener: f(t.Nc, t)
                                }
                            },
                            multipleInstances: !1,
                            instantiationMode: "LAZY",
                            type: "PRIVATE"
                        }), i.a.registerVersion("@firebase/auth", "0.14.6"), i.a.INTERNAL.extendNamespace({
                            User: Es
                        })
                    }()
            }).apply(void 0 !== t ? t : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
        }.call(e, n(12))
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t === u ? void 0 : t
    }

    function o(t) {
        return "EAGER" === t.instantiationMode
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var r = n(3),
        a = n(5),
        s = function() {
            function t(t, e, n) {
                this.name = t, this.instanceFactory = e, this.type = n, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY"
            }
            return t.prototype.setInstantiationMode = function(t) {
                return this.instantiationMode = t, this
            }, t.prototype.setMultipleInstances = function(t) {
                return this.multipleInstances = t, this
            }, t.prototype.setServiceProps = function(t) {
                return this.serviceProps = t, this
            }, t
        }(),
        u = "[DEFAULT]",
        c = function() {
            function t(t, e) {
                this.name = t, this.container = e, this.component = null, this.instances = new Map, this.instancesDeferred = new Map
            }
            return t.prototype.get = function(t) {
                void 0 === t && (t = u);
                var e = this.normalizeInstanceIdentifier(t);
                if (!this.instancesDeferred.has(e)) {
                    var n = new a.Deferred;
                    this.instancesDeferred.set(e, n);
                    try {
                        var i = this.getOrInitializeService(e);
                        i && n.resolve(i)
                    } catch (t) {}
                }
                return this.instancesDeferred.get(e).promise
            }, t.prototype.getImmediate = function(t) {
                var e = r.__assign({
                        identifier: u,
                        optional: !1
                    }, t),
                    n = e.identifier,
                    i = e.optional,
                    o = this.normalizeInstanceIdentifier(n);
                try {
                    var a = this.getOrInitializeService(o);
                    if (!a) {
                        if (i) return null;
                        throw Error("Service " + this.name + " is not available")
                    }
                    return a
                } catch (t) {
                    if (i) return null;
                    throw t
                }
            }, t.prototype.getComponent = function() {
                return this.component
            }, t.prototype.setComponent = function(t) {
                var e, n;
                if (t.name !== this.name) throw Error("Mismatching Component " + t.name + " for Provider " + this.name + ".");
                if (this.component) throw Error("Component for " + this.name + " has already been provided");
                if (this.component = t, o(t)) try {
                    this.getOrInitializeService(u)
                } catch (t) {}
                try {
                    for (var i = r.__values(this.instancesDeferred.entries()), a = i.next(); !a.done; a = i.next()) {
                        var s = r.__read(a.value, 2),
                            c = s[0],
                            l = s[1],
                            h = this.normalizeInstanceIdentifier(c);
                        try {
                            l.resolve(this.getOrInitializeService(h))
                        } catch (t) {}
                    }
                } catch (t) {
                    e = {
                        error: t
                    }
                } finally {
                    try {
                        a && !a.done && (n = i.return) && n.call(i)
                    } finally {
                        if (e) throw e.error
                    }
                }
            }, t.prototype.clearInstance = function(t) {
                void 0 === t && (t = u), this.instancesDeferred.delete(t), this.instances.delete(t)
            }, t.prototype.delete = function() {
                return r.__awaiter(this, void 0, void 0, function() {
                    var t;
                    return r.__generator(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return t = Array.from(this.instances.values()), [4, Promise.all(t.filter(function(t) {
                                    return "INTERNAL" in t
                                }).map(function(t) {
                                    return t.INTERNAL.delete()
                                }))];
                            case 1:
                                return e.sent(), [2]
                        }
                    })
                })
            }, t.prototype.isComponentSet = function() {
                return null != this.component
            }, t.prototype.getOrInitializeService = function(t) {
                var e = this.instances.get(t);
                return !e && this.component && (e = this.component.instanceFactory(this.container, i(t)), this.instances.set(t, e)), e || null
            }, t.prototype.normalizeInstanceIdentifier = function(t) {
                return this.component ? this.component.multipleInstances ? t : u : t
            }, t
        }(),
        l = function() {
            function t(t) {
                this.name = t, this.providers = new Map
            }
            return t.prototype.addComponent = function(t) {
                var e = this.getProvider(t.name);
                if (e.isComponentSet()) throw Error("Component " + t.name + " has already been registered with " + this.name);
                e.setComponent(t)
            }, t.prototype.addOrOverwriteComponent = function(t) {
                this.getProvider(t.name).isComponentSet() && this.providers.delete(t.name), this.addComponent(t)
            }, t.prototype.getProvider = function(t) {
                if (this.providers.has(t)) return this.providers.get(t);
                var e = new c(t, this);
                return this.providers.set(t, e), e
            }, t.prototype.getProviders = function() {
                return Array.from(this.providers.values())
            }, t
        }();
    e.Component = s, e.ComponentContainer = l, e.Provider = c
}, function(t, e, n) {
    "use strict";

    function i() {
        for (var t = 0, e = 0, n = arguments.length; n > e; e++) t += arguments[e].length;
        for (var i = Array(t), o = 0, e = 0; n > e; e++)
            for (var r = arguments[e], a = 0, s = r.length; s > a; a++, o++) i[o] = r[a];
        return i
    }

    function o(t) {
        var e = "string" == typeof t ? c[t] : t;
        u.forEach(function(t) {
            t.logLevel = e
        })
    }

    function r(t, e) {
        for (var n = 0, i = u; i.length > n; n++) {
            var o = i[n];
            ! function(n) {
                var i = null;
                e && e.level && (i = c[e.level]), n.userLogHandler = null === t ? null : function(e, n) {
                    for (var o = [], r = 2; arguments.length > r; r++) o[r - 2] = arguments[r];
                    var a = o.map(function(t) {
                        if (null == t) return null;
                        if ("string" == typeof t) return t;
                        if ("number" == typeof t || "boolean" == typeof t) return "" + t;
                        if (t instanceof Error) return t.message;
                        try {
                            return JSON.stringify(t)
                        } catch (t) {
                            return null
                        }
                    }).filter(function(t) {
                        return t
                    }).join(" ");
                    (null !== i && void 0 !== i ? i : e.logLevel) > n || t({
                        level: s[n].toLowerCase(),
                        message: a,
                        args: o,
                        type: e.name
                    })
                }
            }(o)
        }
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), n.d(e, "LogLevel", function() {
        return s
    }), n.d(e, "Logger", function() {
        return p
    }), n.d(e, "setLogLevel", function() {
        return o
    }), n.d(e, "setUserLogHandler", function() {
        return r
    });
    var a, s, u = [];
    ! function(t) {
        t[t.DEBUG = 0] = "DEBUG", t[t.VERBOSE = 1] = "VERBOSE", t[t.INFO = 2] = "INFO", t[t.WARN = 3] = "WARN", t[t.ERROR = 4] = "ERROR", t[t.SILENT = 5] = "SILENT"
    }(s || (s = {}));
    var c = {
            debug: s.DEBUG,
            verbose: s.VERBOSE,
            info: s.INFO,
            warn: s.WARN,
            error: s.ERROR,
            silent: s.SILENT
        },
        l = s.INFO,
        h = (a = {}, a[s.DEBUG] = "log", a[s.VERBOSE] = "log", a[s.INFO] = "info", a[s.WARN] = "warn", a[s.ERROR] = "error", a),
        f = function(t, e) {
            for (var n = [], i = 2; arguments.length > i; i++) n[i - 2] = arguments[i];
            if (e >= t.logLevel) {
                if (!((new Date).toISOString(), h[e])) throw Error("Attempted to log a message with an invalid logType (value: " + e + ")")
            }
        },
        p = function() {
            function t(t) {
                this.name = t, this._logLevel = l, this._logHandler = f, this._userLogHandler = null, u.push(this)
            }
            return Object.defineProperty(t.prototype, "logLevel", {
                get: function() {
                    return this._logLevel
                },
                set: function(t) {
                    t in s && (this._logLevel = t)
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "logHandler", {
                get: function() {
                    return this._logHandler
                },
                set: function(t) {
                    "function" == typeof t && (this._logHandler = t)
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "userLogHandler", {
                get: function() {
                    return this._userLogHandler
                },
                set: function(t) {
                    this._userLogHandler = t
                },
                enumerable: !0,
                configurable: !0
            }), t.prototype.debug = function() {
                for (var t = [], e = 0; arguments.length > e; e++) t[e] = arguments[e];
                this._userLogHandler && this._userLogHandler.apply(this, i([this, s.DEBUG], t)), this._logHandler.apply(this, i([this, s.DEBUG], t))
            }, t.prototype.log = function() {
                for (var t = [], e = 0; arguments.length > e; e++) t[e] = arguments[e];
                this._userLogHandler && this._userLogHandler.apply(this, i([this, s.VERBOSE], t)), this._logHandler.apply(this, i([this, s.VERBOSE], t))
            }, t.prototype.info = function() {
                for (var t = [], e = 0; arguments.length > e; e++) t[e] = arguments[e];
                this._userLogHandler && this._userLogHandler.apply(this, i([this, s.INFO], t)), this._logHandler.apply(this, i([this, s.INFO], t))
            }, t.prototype.warn = function() {
                for (var t = [], e = 0; arguments.length > e; e++) t[e] = arguments[e];
                this._userLogHandler && this._userLogHandler.apply(this, i([this, s.WARN], t)), this._logHandler.apply(this, i([this, s.WARN], t))
            }, t.prototype.error = function() {
                for (var t = [], e = 0; arguments.length > e; e++) t[e] = arguments[e];
                this._userLogHandler && this._userLogHandler.apply(this, i([this, s.ERROR], t)), this._logHandler.apply(this, i([this, s.ERROR], t))
            }, t
        }()
}, function(t, e, n) {
    "use strict";
    e.__esModule = !0, e.setFirebaseAuthStateChangedListener = e.checkFirebaseEmailLink = void 0;
    var i = n(10),
        o = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        }(i),
        r = function(t) {
            return !(!t || !t.expires) && !t.recurring && t.expires <= Date.now()
        },
        a = {
            pro: "p",
            expires: "e",
            source: "s",
            recurring: "r",
            subscription_plan_id: "spi",
            currency: "c",
            price: "pr",
            update_hash: "h",
            paddle_user_id: "pid",
            product_id: "pi"
        },
        s = function() {
            try {
                (0, o.default)("upgradeAccountCreated"), (0, o.default)("apiKey"), (0, o.default)("mode"), (0, o.default)("oobCode")
            } catch (t) {}
        },
        u = function(t) {
            var e = t.displayName;
            e && "" !== e || (e = "{}");
            var n = {};
            try {
                var i = JSON.parse(e);
                Object.entries(i).forEach(function(t) {
                    var e = t[0],
                        i = t[1],
                        o = Object.entries(a).filter(function(t) {
                            return t[1] === e
                        })[0][0];
                    n[o] = i
                }), n.expires = +n.expires, n.cancel_url = t.photoURL
            } catch (t) {}
            return {
                email: t.email,
                photoUrl: t.photoURL,
                emailVerified: t.emailVerified,
                uid: t.uid,
                licenseState: n
            }
        };
    e.checkFirebaseEmailLink = function(t, e, n, i, o) {
        t().isSignInWithEmailLink(window.location.href) && n({
            waitingForLogin: !0
        }, function() {
            var r = o || e.emailPendingVerification;
            r ? t().signInWithEmailLink(r, window.location.href).then(function(t) {
                var e = u(t.user),
                    i = window.location.href.indexOf("upgradeAccountCreated") > -1,
                    o = {
                        emailPendingVerification: null,
                        waitingForLogin: !1
                    };
                s(), e.licenseState.pro && (i = !1), o.upgradeDialog = i ? 3 : null, n(o)
            }).catch(function() {
                s(), n({
                    waitingForLogin: !1,
                    upgradeDialog: null,
                    showToast: "bad_link"
                })
            }) : setTimeout(function() {
                return n({
                    waitingForLogin: !1
                }, i)
            }, 1)
        })
    }, e.setFirebaseAuthStateChangedListener = function(t, e, n, i, o) {
        t().onAuthStateChanged(function(t) {
            var s = e();
            if (t) {
                window._firebaseUser = t;
                var c = u(t),
                    l = c.licenseState,
                    h = r(l);
                if ((l.pro !== s.pro || h) && (l.pro && !h ? i(l.expires) : o(), h)) {
                    var f = JSON.parse(t.displayName);
                    f[a.pro] = !1, f = JSON.stringify(f), t.updateProfile({
                        displayName: f
                    })
                }
                n({
                    user: c
                })
            } else s.user && (n({
                user: null
            }), o())
        })
    }
}, function(t, e, n) {
    "use strict";
    var i = n(11),
        o = navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom"),
        r = {
            apiKey: "AIzaSyCpvPuy_47jY5Sk-nDbIzrLPRuM3rGXqgU",
            authDomain: "a-soft-murmur.firebaseapp.com",
            databaseURL: "https://a-soft-murmur.firebaseio.com",
            projectId: "a-soft-murmur",
            storageBucket: "a-soft-murmur.appspot.com",
            messagingSenderId: "511059802943",
            appId: "1:511059802943:web:f6af491dbe904a0074318a",
            measurementId: "G-XHDJFXXR2F"
        };
    o || (0, i.initializeApp)(r)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0),
        s = n(29),
        u = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        }(s);
    n(60);
    var c = function(t) {
        if (!t || !t.expires || t.expires > Date.now()) return "None";
        var e = new Intl.DateTimeFormat("en", {
                year: "numeric",
                month: "2-digit",
                day: "2-digit"
            }),
            n = e.formatToParts(new Date(t.expires));
        return "Expired " + n[4].value + "-" + n[0].value + "-" + n[2].value
    };
    e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            if (!this.props.user) return null;
            var t = !(!this.props.user.licenseState || !this.props.user.licenseState.pro),
                e = t && this.props.user.licenseState,
                n = void 0;
            if (t) {
                var i = new Intl.DateTimeFormat("en", {
                        year: "numeric",
                        month: "2-digit",
                        day: "2-digit"
                    }),
                    o = i.formatToParts(new Date(e.expires)),
                    r = o[0].value,
                    s = o[2].value,
                    l = o[4].value;
                e.pro && e.recurring && e.expires <= Date.now() && (l = (new Date).getFullYear() + 1), n = l + "-" + r + "-" + s
            }
            return (0, a.h)(u.default, {
                addClassNames: "AccountView",
                title: "My Profile",
                onNegativeAction: this.props.onSignOut,
                negativeText: "Sign out",
                onPositiveAction: this.props.onCancel,
                positiveText: "Close"
            }, (0, a.h)("div", {
                className: "accountViewContent"
            }, (0, a.h)("table", null, (0, a.h)("tr", null, (0, a.h)("td", {
                className: "label"
            }, "Email:"), (0, a.h)("td", {
                className: "content"
            }, this.props.user.email)), (0, a.h)("tr", null, (0, a.h)("td", {
                className: "label"
            }, "License:"), (0, a.h)("td", {
                className: "content"
            }, t ? "Pro" : c(this.props.user.licenseState) + " - ", t ? "" : (0, a.h)("button", {
                className: "upgrade interactive hoverOpacity",
                onClick: this.props.upgradeToPro
            }, "Upgrade to Pro"))), t && (0, a.h)("tr", null, (0, a.h)("td", {
                className: "label"
            }, "License expiry:"), (0, a.h)("td", {
                className: "content"
            }, n)), t && (0, a.h)("tr", null, (0, a.h)("td", {
                className: "label"
            }, "License source:"), (0, a.h)("td", {
                className: "content"
            }, function() {
                var t = e.source;
                return "web" === t ? "Web" : "apple" === t ? "Apple App Store" : "android" === t ? "Google Play" : "Unknown"
            }())), t && (0, a.h)("tr", null, (0, a.h)("td", {
                className: "label"
            }, "After expiry:"), (0, a.h)("td", {
                className: "content"
            }, e.recurring ? (0, a.h)("div", {
                className: "renewalOptions"
            }, (0, a.h)("p", null, "License will renew automatically"), (0, a.h)("p", null, (0, a.h)("a", {
                href: e.cancel_url,
                target: "_blank",
                rel: "noopener noreferrer"
            }, "Cancel renewal"))) : "License will not renew automatically")))))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(61), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "AppLinks " + (this.props.hidden ? "hidden" : "")
            }, (0, a.h)("button", {
                className: "interactive hide",
                onClick: this.props.hideAppLinks
            }, "✕"), (0, a.h)("a", {
                className: "cupertino interactive",
                title: "A Soft Murmur on The App Store",
                href: "https://itunes.apple.com/app/apple-store/id1175522255?pt=118464987&ct=" + (this.props.utmCampaign ? this.props.utmCampaign : "") + "&mt=8"
            }, (0, a.h)("span", null)), (0, a.h)("a", {
                className: "mountainview interactive",
                title: "A Soft Murmur on Google Play",
                href: "https://play.google.com/store/apps/details?id=com.gabemart.asoftmurmur" + (this.props.utmSubstring ? this.props.utmSubstring : "")
            }, (0, a.h)("span", null)))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(62), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "Background"
            })
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(63), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("footer", {
                className: "Footer"
            }, (0, a.h)("div", {
                className: "container"
            }, (0, a.h)("a", {
                href: "",
                title: ""
            }, ""), (0, a.h)("a", {
                href: "",
                title: ""
            }, ""), this.props.showAppLinks && (0, a.h)("a", {
                title: "",
                href: ""
            }, ""), this.props.showAppLinks && (0, a.h)("a", {
                href: "",
                title: ""
            }, "")))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(64), e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                lastVolume: null,
                touchInProgress: !1
            }, n.handleInput = n.handleInput.bind(n), n.handleChangeVolume = n.handleChangeVolume.bind(n), n.toggleMute = n.toggleMute.bind(n), n
        }
        return r(e, t), e.prototype.shouldComponentUpdate = function(t) {
            return this.props.volume !== t.volume
        }, e.prototype.handleInput = function(t) {
            this.handleChangeVolume(parseFloat(t.target.value))
        }, e.prototype.handleChangeVolume = function(t) {
            this.props.onChangeVolume(t)
        }, e.prototype.toggleMute = function() {
            this.props.volume > 0 ? (this.setState({
                lastVolume: this.props.volume
            }), this.handleChangeVolume(0)) : this.state.lastVolume ? (this.handleChangeVolume(this.state.lastVolume), this.setState({
                lastVolume: null
            })) : this.handleChangeVolume(1)
        }, e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "GlobalVolume"
            }, (0, a.h)("span", {
                className: "sliderContainer"
            }, (0, a.h)("input", {
                min: 0,
                max: 1,
                step: .01,
                className: "slider",
                type: "range",
                value: this.props.volume,
                onInput: this.handleInput,
                onChange: this.handleChange
            })), (0, a.h)("button", {
                className: "mute interactive",
                onClick: this.toggleMute
            }, 0 === this.props.volume ? "Unmute" : "Mute"))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function o(t, e) {}

    function r(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function a(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var s = n(0),
        u = n(25),
        c = i(u),
        l = n(27),
        h = i(l);
    n(65), e.default = function(t) {
        function e() {
            o(this, e);
            var n = r(this, t.call(this));
            return n.state = {
                subscribeVisible: !1
            }, n.toggleSubscribe = n.toggleSubscribe.bind(n), n
        }
        return a(e, t), e.prototype.toggleSubscribe = function() {
            this.setState({
                subscribeVisible: !this.state.subscribeVisible
            })
        }, e.prototype.render = function() {
            return (0, s.h)("header", {
                className: "Header " + (this.state.subscribeVisible ? "subscribe" : "")
            }, (0, s.h)("div", {
                className: "container"
            }, (0, s.h)(c.default, {
                volume: this.props.volume,
                onChangeVolume: this.props.onChangeVolume
            }), (0, s.h)("nav", null, (0, s.h)("a", {
                title: "A Soft Murmur Blog",
                href: ""
            }, ""), (0, s.h)("button", {
                className: "updateButton " + (this.state.subscribeVisible ? "active" : ""),
                title: " about A Soft Murmur",
                onClick: this.toggleSubscribe
            }, ""), (0, s.h)("a", {
                href: "/about",
                title: "About A Soft Murmur"
            }, "About"), (0, s.h)("button", {
                className: "updateButton " + (this.state.user ? "loggedIn" : "loggedOut"),
                title: "Log in to your account",
                onClick: this.props.user ? this.props.toggleAccountView : this.props.toggleLoginView
            }, this.props.user ? "Profile" : ""))), this.state.subscribeVisible && (0, s.h)(h.default, {
                onClose: this.toggleSubscribe
            }))
        }, e
    }(s.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(66), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "Subscribe"
            }, (0, a.h)("div", {
                id: "dialog-content",
                class: "email"
            }, (0, a.h)("div", {
                id: "mc_embed_signup"
            }, (0, a.h)("form", {
                action: "//asoftmurmur.us7.list-manage.com/subscribe/post?u=a3f273bf0a1ee8e5678293af1&id=981104d315",
                method: "post",
                id: "mc-embedded-subscribe-form",
                name: "mc-embedded-subscribe-form",
                className: "validate",
                target: "_blank",
                novalidate: ""
            }, (0, a.h)("input", {
                className: "emailInput",
                type: "email",
                id: "mce-EMAIL",
                name: "EMAIL",
                placeholder: "your.email@address.org"
            }), (0, a.h)("div", {
                id: "mce-responses",
                class: "clear"
            }, (0, a.h)("div", {
                class: "response",
                id: "mce-error-response",
                style: "display:none"
            }), (0, a.h)("div", {
                class: "response",
                id: "mce-success-response",
                style: "display:none"
            })), (0, a.h)("div", {
                style: "position: absolute; left: -5000px;"
            }, (0, a.h)("input", {
                type: "text",
                name: "b_a3f273bf0a1ee8e5678293af1_981104d315",
                value: ""
            })), (0, a.h)("input", {
                type: "submit",
                value: "",
                name: "subscribe",
                id: "mc-embedded-subscribe",
                className: "button clickable"
            }))), (0, a.h)("div", {
                className: "text"
            }, (0, a.h)("p", {
                id: "email-caption"
            }, "Get an email every now and then about new features and sounds coming to A Soft Murmur. No spam ever and one-click unsubscribe."))))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(67), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "home"
            }, (0, a.h)("h1", null, "Home"), (0, a.h)("p", null, "This is the Home component."))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(68), e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                emailText: "",
                showErrorState: !1,
                submitted: !1
            }, n
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "Modal " + (this.props.addClassNames ? this.props.addClassNames : "")
            }, (0, a.h)("div", {
                className: "inner"
            }, (0, a.h)("div", {
                className: "header"
            }, (0, a.h)("h2", null, this.props.title), (0, a.h)("button", {
                className: "cornerClose interactive hoverOpacity",
                onClick: this.props.onPositiveAction
            }, "×")), (0, a.h)("div", {
                className: "content"
            }, this.props.children), (0, a.h)("div", {
                className: "buttonContainer"
            }, (0, a.h)("button", {
                className: "button interactive submit",
                onClick: this.props.onPositiveAction
            }, this.props.positiveText || "OK"), this.props.onNegativeAction ? (0, a.h)("button", {
                className: "button interactive cancel",
                onClick: this.props.onNegativeAction
            }, this.props.negativeText || "Cancel") : null)))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(69), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "MoreSounds"
            }, (0, a.h)("button", {
                className: "button interactive",
                onClick: this.props.onStart
            }, "Ready Some Samples"), (0, a.h)("div", {
                className: "footest"
            }))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(70), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "PlayControls"
            }, (0, a.h)("button", {
                className: "secondary interactive meander " + (this.props.meanderActive ? "active" : "inactive"),
                onClick: this.props.toggleMeander,
                title: "When meander is active, the volume of each active sound wanders up and down at random."
            }, (0, a.h)("span", {
                className: "buttonContents"
            }, (0, a.h)("span", {
                className: "image"
            }), this.props.showMeanderHelpText && (0, a.h)("div", {
                className: "meanderHelpText"
            }, "When meander is active, the volume of each active sound wanders up and down at random."))), (0, a.h)("button", {
                onClick: this.props.togglePlay
            }, (0, a.h)("div", {
                className: "pb " + (this.props.isPlaying ? "stop" : "play")
            }, (0, a.h)("div", {
                className: "first"
            }), (0, a.h)("div", {
                className: "second"
            }))), (0, a.h)("button", {
                className: "secondary interactive reset " + (this.props.canRestore ? "canRestore" : ""),
                onClick: this.props.toggleReset
            }, (0, a.h)("span", {
                className: "buttonContents"
            }, (0, a.h)("span", {
                className: "image"
            }))))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(71), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            var t = this;
            return (0, a.h)("div", {
                className: "ProHelpModal"
            }, (0, a.h)("div", {
                className: "inner"
            }, (0, a.h)("h2", null, "Thank you for upgrading to Pro"), (0, a.h)("p", null, 'Open the "sounds" manager to access your new sounds'), (0, a.h)("div", {
                className: "buttonContainer"
            }, (0, a.h)("button", {
                className: "button interactive ok",
                onClick: function() {
                    return t.props.onDismiss()
                }
            }, "OK"))))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0),
        s = n(2),
        u = n(34),
        c = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        }(u);
    n(72), e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                soundPreviewing: null
            }, n.togglePreview = n.togglePreview.bind(n), n.handleCancelledToggleAttempt = n.handleCancelledToggleAttempt.bind(n), n
        }
        return r(e, t), e.prototype.togglePreview = function(t) {
            this.props.handleStopActivity(), this.setState({
                soundPreviewing: this.state.soundPreviewing === t ? null : t
            })
        }, e.prototype.handleCancelledToggleAttempt = function() {
            var t = this;
            clearTimeout(this.timeout), this.setState({
                showSlotMessage: !0
            });
            var e = function() {
                return t.setState({
                    showSlotMessage: !1
                })
            };
            this.timeout = setTimeout(e, 2e3)
        }, e.prototype.render = function() {
            for (var t = this, e = Object.keys(this.props.sounds).map(function(e) {
                    return t.props.sounds[e]
                }).sort(function(t, e) {
                    return t.sortKey - e.sortKey
                }), n = Object.keys(this.props.library).filter(function(e) {
                    return !t.props.sounds[e]
                }).map(function(e) {
                    return t.props.library[e]
                }).sort(function(t, e) {
                    return e.sortKey - t.sortKey
                }), i = [], o = !(!this.state.soundPreviewing || -1 !== e.findIndex(function(e) {
                    return e.key === t.state.soundPreviewing
                })), r = e.length; 10 > r; r++) i.push({});
            return (0, a.h)("div", {
                className: "ManageSoundsInput"
            }, (0, a.h)("div", {
                className: "content"
            }, (0, a.h)("div", {
                className: "pane1"
            }, (0, a.h)("div", {
                className: "slots"
            }, (0, a.h)("p", null, "Active sounds")), (0, a.h)("div", {
                className: "activeList"
            }, (0, a.h)("ol", null, e.map(function(e) {
                return (0, a.h)(c.default, {
                    sound: e,
                    isActive: !0,
                    toggleSound: t.props.onToggleSoundActive,
                    isPreviewing: t.state.soundPreviewing === e.key,
                    onTogglePreview: t.togglePreview.bind(t, e.key),
                    canToggle: !0
                })
            }), i.map(function(t, e) {
                return (0, a.h)("div", {
                    className: "emptySlot",
                    key: e
                }, (0, a.h)("p", null, "- empty -"))
            }))), (0, a.h)("div", {
                className: "clearAllContainer"
            }, (0, a.h)("button", {
                className: "interactive",
                onClick: this.props.handleClearAllSounds
            }, 0 === e.length ? "Reset default sounds" : "Clear all active sounds", " ", (0, a.h)("span", {
                className: "bar"
            })))), (0, a.h)("div", {
                className: "pane2"
            }, (0, a.h)("div", {
                className: "slots"
            }, (0, a.h)("p", null, "Available sounds")), (0, a.h)("div", {
                className: "inactiveList"
            }, (0, a.h)("ol", null, n.map(function(n) {
                return (0, a.h)(c.default, {
                    sound: n,
                    isActive: !1,
                    toggleSound: t.props.onToggleSoundActive,
                    isPreviewing: t.state.soundPreviewing === n.key,
                    onTogglePreview: t.togglePreview.bind(t, n.key),
                    canToggle: 10 > e.length,
                    onCancelledToggleAttempt: t.handleCancelledToggleAttempt
                })
            }))))), this.state.showSlotMessage ? (0, a.h)("div", {
                className: "slotMessage noSelect"
            }, "Please remove an active sound first") : null, (0, a.h)("div", {
                className: "controls"
            }, (0, a.h)("button", {
                className: "close interactive",
                onClick: this.props.onClose
            }, "Close")), o ? (0, a.h)(l, {
                key: this.state.soundPreviewing,
                sound: this.props.library[this.state.soundPreviewing],
                onEnd: function() {
                    return t.setState({
                        soundPreviewing: null
                    })
                }
            }) : null)
        }, e
    }(a.Component);
    var l = function(t) {
        function e() {
            return i(this, e), o(this, t.call(this))
        }
        return r(e, t), e.prototype.componentWillUnmount = function() {
            var t = this;
            Promise.resolve(this).then(function() {
                return t.nextBase = t.__b = null
            })
        }, e.prototype.componentDidMount = function() {
            var t = this;
            setTimeout(function() {
                if (t.player) try {
                    t.player.play()
                } catch (t) {}
            }, 100)
        }, e.prototype.render = function() {
            var t = this;
            return (0, a.h)("audio", {
                ref: function(e) {
                    return t.player = e
                },
                className: "PreviewSound",
                autoplay: !0,
                preload: "auto",
                onEnded: this.props.onEnd
            }, (0, a.h)("source", {
                className: "mp4 " + this.props.sound.key,
                src: (0, s.getPrefix)(this.props.sound) + "glue-" + this.props.sound.key + ".mp4",
                type: "audio/mp4"
            }), (0, a.h)("source", {
                className: "ogg " + this.props.sound.key,
                src: (0, s.getPrefix)(this.props.sound) + "glue-" + this.props.sound.key + ".ogg",
                type: "audio/ogg"
            }))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(73), e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                active: null
            }, n.handleToggle = n.handleToggle.bind(n), n
        }
        return r(e, t), e.prototype.componentWillMount = function() {
            this.setState({
                active: this.props.isActive
            })
        }, e.prototype.componentWillReceiveProps = function(t) {
            this.setState({
                active: t.isActive
            })
        }, e.prototype.handleToggle = function() {
            var t = this;
            if (!this.props.canToggle) return this.props.onCancelledToggleAttempt();
            clearTimeout(this.timeout), this.setState({
                active: !this.state.active
            }), this.timeout = setTimeout(function() {
                return t.props.toggleSound(t.props.sound.key)
            }, 100)
        }, e.prototype.render = function() {
            var t = this.props,
                e = t.sound;
            return (0, a.h)("li", {
                className: "SoundItem " + (this.state.active ? "active" : "inactive")
            }, (0, a.h)("div", {
                className: "biggerTarget",
                onClick: this.handleToggle
            }), (0, a.h)("p", {
                className: "label"
            }, e.label), this.props.isActive ? null : (0, a.h)("div", {
                className: "previewButton " + (this.props.isPreviewing ? "previewing" : "")
            }, (0, a.h)("button", {
                className: "button interactive",
                onClick: this.props.onTogglePreview
            }, (0, a.h)("div", {
                className: "touchTarget"
            }), (0, a.h)("div", {
                className: "previewInnerContainer"
            }, (0, a.h)("div", {
                className: "previewInner"
            })))), (0, a.h)("div", {
                className: "buttonContainer " + (this.props.isActive ? "right" : "left")
            }, (0, a.h)("button", {
                className: "interactive",
                onClick: this.handleToggle
            }, (0, a.h)("div", {
                className: "buttonInner"
            }, (0, a.h)("div", {
                className: "buttonInnerContent"
            })))))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function o(t, e) {}

    function r(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function a(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var s = n(0),
        u = n(36),
        c = i(u),
        l = n(7),
        h = (i(l), n(55)),
        f = i(h);
    n(74);
    var p = function(t) {
        return Object.keys(t).sort(function(e, n) {
            return "" + t[e].name > "" + t[n].name
        }).map(function(e) {
            return t[e]
        })
    };
    e.default = function(t) {
        function e() {
            o(this, e);
            var n = r(this, t.call(this));
            return n.state = {
                name: ""
            }, n.saveMix = n.saveMix.bind(n), n.loadMix = n.loadMix.bind(n), n.loadRandomMix = n.loadRandomMix.bind(n), n.deleteMix = n.deleteMix.bind(n), n.adjustSizeForNumMixes = n.adjustSizeForNumMixes.bind(n), n
        }
        return a(e, t), e.prototype.componentWillMount = function() {
            this.adjustSizeForNumMixes(this.props)
        }, e.prototype.componentWillReceiveProps = function(t) {
            var e = this,
                n = Object.keys(t.mixes).length,
                i = Object.keys(this.props.mixes).length;
            if (n !== i && (this.adjustSizeForNumMixes(t), n > i && n > 6)) {
                var o = Object.keys(t.mixes).filter(function(t) {
                        return !Object.keys(e.props.mixes).some(function(e) {
                            return e === t
                        })
                    })[0],
                    r = p(t.mixes).findIndex(function(t) {
                        return t.id === o
                    }),
                    a = 60 * r;
                this.mixList && (this.mixList.scrollTop = a)
            }
        }, e.prototype.adjustSizeForNumMixes = function(t) {
            var e = Object.keys(t.mixes).length;
            t.handleContentClass(e > 6 ? "mixesLots" : e > 3 ? "mixes" + e : "")
        }, e.prototype.saveMix = function() {
            this.props.onAddMix(this.state.name), this.setState({
                name: ""
            })
        }, e.prototype.loadMix = function(t) {
            this.props.onLoadMix(t)
        }, e.prototype.loadRandomMix = function() {
            var t = (0, f.default)(this.props.sounds, this.props.library);
            this.props.onLoadMix(null, t.sounds), this.setState({
                name: t.name
            })
        }, e.prototype.deleteMix = function(t) {
            this.props.onDeleteMix(t)
        }, e.prototype.render = function() {
            var t = this,
                e = p(this.props.mixes);
            return (0, s.h)("div", {
                className: "MixInput"
            }, (0, s.h)("div", {
                className: "save"
            }, (0, s.h)("input", {
                ref: function(e) {
                    return t.input = e
                },
                type: "text",
                placeholder: "New mix name",
                value: this.state.name,
                onInput: function(e) {
                    return t.setState({
                        name: e.target.value
                    })
                },
                onKeyDown: function(e) {
                    13 === e.keyCode && (t.saveMix(), t.input && t.input.blur())
                },
                autofocus: 0 === e.length
            }), (0, s.h)("button", {
                className: "interactive saveMix",
                onClick: this.saveMix,
                disabled: "" === this.state.name
            }, "Save")), (0, s.h)("div", {
                className: "mixList",
                ref: function(e) {
                    return t.mixList = e
                }
            }, 0 === e.length ? (0, s.h)("span", {
                className: "noMixMessage"
            }, "No mixes yet") : (0, s.h)("ol", null, e.map(function(e) {
                return (0, s.h)(c.default, {
                    key: e.id,
                    mix: e,
                    loadMix: t.loadMix,
                    deleteMix: t.deleteMix,
                    shareMix: t.props.onShareMix
                })
            }))), (0, s.h)("div", {
                className: "controls"
            }, (0, s.h)("button", {
                className: "close interactive",
                onClick: this.props.onClose
            }, "Close"), (0, s.h)("button", {
                className: "interactive saveMix",
                onClick: this.loadRandomMix
            }, "Random mix")))
        }, e
    }(s.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(75), e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                deletePending: !1
            }, n.handleDeleteClick = n.handleDeleteClick.bind(n), n
        }
        return r(e, t), e.prototype.handleDeleteClick = function(t) {
            "cancel" === t ? this.setState({
                deletePending: !1
            }) : "confirm" === t ? this.props.deleteMix(this.props.mix.id) : this.setState({
                deletePending: !0
            })
        }, e.prototype.render = function() {
            var t = this,
                e = this.props.mix;
            return (0, a.h)("li", {
                className: "MixInputItem"
            }, (0, a.h)("span", {
                className: "wrap"
            }, this.state.deletePending && (0, a.h)("span", {
                className: "deletePending"
            }, (0, a.h)("button", {
                className: "deleteCancel interactive",
                onClick: function() {
                    return t.handleDeleteClick("cancel")
                }
            }, "Cancel"), (0, a.h)("button", {
                className: "deleteConfirm interactive",
                onClick: function() {
                    return t.handleDeleteClick("confirm")
                }
            }, "Delete Mix")), (0, a.h)("button", {
                className: "main interactive",
                onClick: function() {
                    return t.props.loadMix(e.id)
                }
            }, e.name), (0, a.h)("button", {
                className: "share interactive",
                onClick: function() {
                    return t.props.shareMix(e.id)
                }
            }, "Share"), (0, a.h)("button", {
                className: "delete interactive",
                onClick: this.handleDeleteClick
            }, "✕")))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function o(t, e) {}

    function r(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function a(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var s = n(0),
        u = n(40),
        c = i(u),
        l = n(35),
        h = i(l),
        f = n(33),
        p = i(f),
        d = n(38),
        m = i(d),
        v = n(8),
        g = i(v);
    n(76), e.default = function(t) {
        function e() {
            o(this, e);
            var n = r(this, t.call(this));
            return n.state = {
                expandedControl: null,
                selectedMix: null,
                contentClass: ""
            }, n.handleCloseTabs = n.handleCloseTabs.bind(n), n.handleTabClick = n.handleTabClick.bind(n), n.handleShareMix = n.handleShareMix.bind(n), n.handleContentClass = n.handleContentClass.bind(n), n
        }
        return a(e, t), e.prototype.handleCloseTabs = function() {
            this.setState({
                expandedControl: null,
                contentClass: ""
            })
        }, e.prototype.handleTabClick = function(t) {
            if (this.state.expandedControl === t) this.setState({
                expandedControl: null,
                selectedMix: null,
                contentClass: ""
            });
            else {
                var e = {
                    expandedControl: t,
                    selectedMix: null,
                    contentClass: ""
                };
                "manage" !== t || this.props.usedSoundManagerBefore || (e.showManagerHelpText = !0), this.setState(e)
            }
        }, e.prototype.handleShareMix = function(t) {
            this.setState({
                expandedControl: "share",
                selectedMix: t
            })
        }, e.prototype.handleContentClass = function(t) {
            this.state.contentClass !== t && this.setState({
                contentClass: t
            })
        }, e.prototype.render = function() {
            var t = this;
            return (0, s.h)("div", {
                className: "RowControls " + this.state.expandedControl
            }, (0, s.h)("div", {
                className: "container"
            }, (0, s.h)("button", {
                onClick: function() {
                    return t.handleTabClick("timers")
                },
                className: "rowControl interactive timers\n              " + ("timers" === this.state.expandedControl ? "expanded" : "initial") + "\n              " + (this.props.timer.isActive && "timers" !== this.state.expandedControl ? "timeDisplay" : "") + "\n            "
            }, this.props.timer.isActive && "timers" !== this.state.expandedControl ? (0, g.default)(this.props.timer.secondsLeft) : "Timers"), (0, s.h)("button", {
                onClick: function() {
                    return t.handleTabClick("mixes")
                },
                className: "rowControl interactive mixes " + ("mixes" === this.state.expandedControl ? "expanded" : "initial")
            }, "Mixes"), this.props.pro ? (0, s.h)("button", {
                onClick: function() {
                    return t.handleTabClick("manage")
                },
                className: "rowControl interactive sounds " + ("manage" === this.state.expandedControl ? "expanded" : "initial")
            }, "Sounds") : null, (0, s.h)("button", {
                onClick: function() {
                    return t.handleTabClick("share")
                },
                className: "rowControl interactive share " + ("share" === this.state.expandedControl ? "expanded" : "initial")
            }, "Share")), (0, s.h)("div", {
                className: "controlContent " + (this.state.expandedControl ? "expanded " + this.state.expandedControl : "initial") + " " + this.state.contentClass
            }, (0, s.h)("div", {
                className: "inner"
            }, "timers" === this.state.expandedControl ? (0, s.h)(c.default, {
                timer: this.props.timer,
                timerStart: this.props.timerStart,
                timerCancel: this.props.timerCancel,
                savedTimer: this.props.savedTimer,
                mixes: this.props.mixes,
                onClose: this.handleCloseTabs,
                handleContentClass: this.handleContentClass
            }) : null, "mixes" === this.state.expandedControl ? (0, s.h)(h.default, {
                mixes: this.props.mixes,
                sounds: this.props.sounds,
                library: this.props.library,
                onAddMix: this.props.onAddMix,
                onLoadMix: this.props.onLoadMix,
                onDeleteMix: this.props.onDeleteMix,
                onShareMix: this.handleShareMix,
                onClose: this.handleCloseTabs,
                handleContentClass: this.handleContentClass
            }) : null, "manage" === this.state.expandedControl ? (0, s.h)(p.default, {
                sounds: this.props.sounds,
                library: this.props.library,
                onClose: this.handleCloseTabs,
                handleContentClass: this.handleContentClass,
                onToggleSoundActive: this.props.onToggleSoundActive,
                handleStopActivity: this.props.handleStopActivity,
                handleClearAllSounds: this.props.handleClearAllSounds
            }) : null, "share" === this.state.expandedControl ? (0, s.h)(m.default, {
                sounds: this.props.sounds,
                mixes: this.props.mixes,
                selectedMix: this.state.selectedMix,
                onClose: this.handleCloseTabs
            }) : null, this.state.showManagerHelpText ? (0, s.h)("div", {
                className: "managerHelpText"
            }, (0, s.h)("div", {
                className: "content"
            }, (0, s.h)("p", null, "Welcome to the sound manager!"), (0, s.h)("p", null, "Up to 10 sounds can be active at one time."), (0, s.h)("p", null, "First, create some empty slots by removing sounds from the ", (0, s.h)("span", {
                className: "it"
            }, "Active sounds"), " list."), (0, s.h)("p", null, "Then, activate some new sounds from the ", (0, s.h)("span", {
                className: "it"
            }, "Available sounds"), " list."), (0, s.h)("button", {
                className: "interactive noSelect",
                onClick: function() {
                    t.props.onOpenSoundManager(), t.setState({
                        showManagerHelpText: !1
                    })
                }
            }, "OK"))) : null)))
        }, e
    }(s.Component)
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function o(t, e) {}

    function r(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function a(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var s = n(0),
        u = n(56),
        c = i(u),
        l = n(53),
        h = i(l);
    n(77);
    var f = window.encodeURIComponent("Check out this ambient noise mix I made! "),
        p = function(t) {
            return null === t ? "Copy to clipboard" : "success" === t ? "Copied!" : "Couldn't copy"
        },
        d = function(t, e, n, i) {
            return "https://junaidmultimediatask.web.app///?m=" + (0, c.default)("current" === t ? n : e[t].sounds) + (i ? "&autoplay=1" : "")
        };
    e.default = function(t) {
        function e() {
            o(this, e);
            var n = r(this, t.call(this));
            return n.state = {
                autoplay: !1,
                copyStatus: null,
                mixListOption: "current",
                highlightMixOption: !1
            }, n.handleClipboard = n.handleClipboard.bind(n), n
        }
        return a(e, t), e.prototype.componentWillMount = function() {
            var t = this;
            if (this.props.selectedMix) {
                this.setState({
                    mixListOption: this.props.selectedMix,
                    highlightMixOption: !0
                });
                var e = function() {
                    return t.setState({
                        highlightMixOption: !1
                    })
                };
                this.timeout = setTimeout(e, 500)
            }
        }, e.prototype.componentWillUnmount = function() {
            this.timeout && clearTimeout(this.timeout)
        }, e.prototype.componentWillReceiveProps = function() {
            this.setState({
                copyStatus: null
            })
        }, e.prototype.handleClipboard = function() {
            var t = this;
            (0, h.default)("#shareUrlContent", function(e) {
                t.setState(e ? {
                    copyStatus: "success"
                } : {
                    copyStatus: "error"
                })
            })
        }, e.prototype.render = function() {
            var t = this,
                e = d(this.state.mixListOption, this.props.mixes, this.props.sounds, this.state.autoplay),
                n = Object.keys(this.props.mixes).sort(function(e, n) {
                    return "" + t.props.mixes[e].name > "" + t.props.mixes[n].name
                }).map(function(e) {
                    return t.props.mixes[e]
                });
            return (0, s.h)("div", {
                className: "ShareInput"
            }, (0, s.h)("div", {
                className: "linkStuff"
            }, (0, s.h)("div", {
                className: "shareUrl"
            }, (0, s.h)("a", {
                id: "shareUrlContent",
                href: e,
                onClick: function(t) {
                    return t.preventDefault()
                }
            }, e)), (0, s.h)("div", {
                className: "options"
            }, (0, s.h)("div", {
                className: "mixListContainer " + (this.state.highlightMixOption ? "highlight" : "")
            }, (0, s.h)("label", null, "Choose a mix:"), (0, s.h)("select", {
                value: this.state.mixListOption,
                onChange: function(e) {
                    return t.setState({
                        mixListOption: e.target.value
                    })
                }
            }, (0, s.h)("option", {
                value: "current",
                label: "Current sounds"
            }), n.map(function(t) {
                return (0, s.h)("option", {
                    value: t.id,
                    label: t.name.substring(0, 32)
                })
            }))), (0, s.h)("div", {
                className: "option"
            }, (0, s.h)("label", {
                title: "With great power comes great responsibility",
                for: "autoplay"
            }, "Autoplay"), (0, s.h)("input", {
                id: "autoplay",
                type: "checkbox",
                value: this.state.autoplay,
                onChange: function() {
                    return t.setState({
                        autoplay: !t.state.autoplay,
                        copyStatus: null
                    })
                }
            })), (0, s.h)("div", {
                className: "clipboardContainer"
            }, (0, s.h)("button", {
                className: "clipboard interactive",
                onClick: this.handleClipboard
            }, p(this.state.copyStatus))))), (0, s.h)("div", {
                className: "letsGetSocial"
            }, (0, s.h)("h3", null, "↓ Share this mix ↓"), (0, s.h)("div", {
                className: "links"
            }, (0, s.h)("a", {
                className: "fb",
                title: "Share your mix on Facebook",
                href: "http://www.facebook.com/sharer/sharer.php?s=100&p[url]=" + encodeURIComponent(e) + "&p[summary]=" + f,
                target: "_blank",
                rel: "noopener"
            }, (0, s.h)("span", null), "Facebook"), (0, s.h)("a", {
                className: "tw",
                title: "Share your mix on Twitter",
                href: "http://twitter.com/home?status=" + f + encodeURIComponent(e) + window.encodeURIComponent(" @multimediataskbyjunaid"),
                target: "_blank",
                rel: "noopener"
            }, (0, s.h)("span", null), "Twitter"), (0, s.h)("a", {
                className: "re",
                title: "Share your mix on Reddit",
                href: "http://www.reddit.com/submit?url=" + encodeURIComponent(e),
                target: "_blank",
                rel: "noopener"
            }, (0, s.h)("span", null), "Reddit"), (0, s.h)("a", {
                className: "tu",
                title: "Share your mix on Tumblr",
                href: "",
                target: "_blank",
                rel: "noopener"
            }, (0, s.h)("span", null), "Tumblr"))))
        }, e
    }(s.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0),
        s = n(8),
        u = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        }(s);
    n(78);
    var c = function(t) {
        var e = "";
        return "start" === t.mode ? e = "Sounds will start in" : "stop" === t.mode ? e = "Sounds will stop in" : "fade" === t.mode && (e = t.destinationMessage), e
    };
    e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            var t = c(this.props.timer);
            return (0, a.h)("div", {
                className: "ActiveTimerDisplay"
            }, (0, a.h)("div", {
                className: "wrap"
            }, (0, a.h)("div", {
                className: "msg"
            }, t), (0, a.h)("div", {
                className: "timeLeft"
            }, (0, u.default)(this.props.timer.secondsLeft))), (0, a.h)("div", {
                className: "controls"
            }, (0, a.h)("button", {
                className: "close interactive",
                onClick: this.props.onClose
            }, "Close"), (0, a.h)("button", {
                className: "cancelTimer interactive",
                onClick: this.props.onCancel
            }, "Stop timer")))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0),
        s = n(39),
        u = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        }(s);
    n(79);
    var c = function(t, e) {
        return 60 * (60 * t + e)
    };
    e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                mode: null,
                hours: null,
                minutes: null,
                fadeOrigin: "current",
                fadeDestination: "silence"
            }, n.handleChangeMode = n.handleChangeMode.bind(n), n.handleStartTimer = n.handleStartTimer.bind(n), n.handleSetFadeOrigin = n.handleSetFadeOrigin.bind(n), n.handleSetFadeDestination = n.handleSetFadeDestination.bind(n), n
        }
        return r(e, t), e.prototype.componentWillMount = function() {
            var t = this.props.savedTimer.lastUsedMode,
                e = this.props.savedTimer[t].seconds,
                n = Math.floor(e / 60),
                i = 0;
            n > 59 && (i = Math.floor(n / 60), n -= 60 * i), this.setState({
                mode: t,
                hours: i,
                minutes: n
            }), "fade" === t && this.props.handleContentClass("fade")
        }, e.prototype.shouldComponentUpdate = function(t, e) {
            var n = this,
                i = this.props,
                o = !1;
            return Object.keys(e).forEach(function(t) {
                e[t] !== n.state[t] && (o = !0)
            }), Object.keys(t.savedTimer).forEach(function(e) {
                t.savedTimer[e] !== i.savedTimer[e] && (o = !0)
            }), Object.keys(t.timer).forEach(function(e) {
                t.timer[e] !== i.timer[e] && (o = !0)
            }), Object.keys(t.mixes).length !== Object.keys(i.mixes).length && (o = !0), o
        }, e.prototype.handleChangeMode = function(t) {
            "fade" === t ? (this.props.handleContentClass("fade"), this.setState({
                mode: "fade"
            })) : (this.props.handleContentClass(""), this.setState({
                mode: t
            }))
        }, e.prototype.handleStartTimer = function() {
            var t = {
                isActive: !0,
                mode: this.state.mode,
                secondsLeft: c(this.state.hours, this.state.minutes)
            };
            if ("fade" === this.state.mode) {
                var e = this.state.fadeOrigin,
                    n = this.state.fadeDestination;
                t.origin = e, t.destination = n
            }
            this.props.timerStart(t)
        }, e.prototype.handleSetFadeOrigin = function(t) {
            var e = {
                fadeOrigin: t.target.value
            };
            this.state.fadeDestination === t.target.value && (e.fadeDestination = "silence" !== t.target.value ? "silence" : "current"), this.setState(e)
        }, e.prototype.handleSetFadeDestination = function(t) {
            var e = {
                fadeDestination: t.target.value
            };
            this.state.fadeOrigin === t.target.value && (e.fadeOrigin = "current" !== t.target.value ? "current" : "silence"), this.setState(e)
        }, e.prototype.render = function() {
            var t = this,
                e = this.props.timer,
                n = Object.keys(this.props.mixes).sort(function(e, n) {
                    return "" + t.props.mixes[e].name > "" + t.props.mixes[n].name
                }).map(function(e) {
                    return t.props.mixes[e]
                });
            return (0, a.h)("div", {
                className: "TimerInput " + ("fade" === this.state.mode ? "extraHeight" : "")
            }, e.isActive ? (0, a.h)(u.default, {
                timer: e,
                onCancel: this.props.timerCancel,
                onClose: this.props.onClose
            }) : (0, a.h)("div", {
                className: "input"
            }, (0, a.h)("div", {
                className: "step1 " + (null === this.state.mode ? "noSelection" : "haveSelection")
            }, (0, a.h)("button", {
                className: "interactive " + ("stop" === this.state.mode ? "selected" : "deselected"),
                onClick: function() {
                    return t.handleChangeMode("stop")
                }
            }, "Stop playing after"), (0, a.h)("button", {
                className: "interactive " + ("start" === this.state.mode ? "selected" : "deselected"),
                onClick: function() {
                    return t.handleChangeMode("start")
                }
            }, "Start playing after"), (0, a.h)("button", {
                className: "interactive " + ("fade" === this.state.mode ? "selected" : "deselected"),
                onClick: function() {
                    return t.handleChangeMode("fade")
                }
            }, "Fade")), (0, a.h)("div", {
                className: "step2 " + ("fade" === this.state.mode ? "" : "empty")
            }, "fade" === this.state.mode && (0, a.h)("div", {
                className: "wrap"
            }, (0, a.h)("div", {
                className: "origin"
            }, (0, a.h)("label", null, "Start point:"), (0, a.h)("select", {
                onChange: this.handleSetFadeOrigin,
                value: this.state.fadeOrigin
            }, (0, a.h)("option", {
                value: "current",
                label: "Current volume"
            }), (0, a.h)("option", {
                value: "silence",
                label: "Silence"
            }), n.map(function(t) {
                return (0, a.h)("option", {
                    value: "mix:" + t.id,
                    label: t.name.substring(0, 32)
                })
            }))), (0, a.h)("div", {
                className: "to"
            }, (0, a.h)("span", null, "fade to"), (0, a.h)("span", null, "➝")), (0, a.h)("div", {
                className: "destination"
            }, (0, a.h)("label", null, "End point:"), (0, a.h)("select", {
                onChange: this.handleSetFadeDestination,
                value: this.state.fadeDestination
            }, (0, a.h)("option", {
                value: "silence",
                label: "Silence"
            }), (0, a.h)("option", {
                value: "current",
                label: "Current volume"
            }), n.map(function(t) {
                return (0, a.h)("option", {
                    value: "mix:" + t.id,
                    label: t.name.substring(0, 32)
                })
            }))))), (0, a.h)("div", {
                className: "step3"
            }, (0, a.h)("div", {
                className: "wrap"
            }, (0, a.h)("input", {
                type: "number",
                value: this.state.hours,
                onChange: function(e) {
                    return t.setState({
                        hours: e.target.value
                    })
                },
                min: 0,
                max: 24
            }), "hours and", (0, a.h)("input", {
                type: "number",
                value: this.state.minutes,
                onChange: function(e) {
                    return t.setState({
                        minutes: e.target.value
                    })
                },
                min: 0,
                max: 59
            }), "minutes")), (0, a.h)("div", {
                className: "step4"
            }, (0, a.h)("button", {
                className: "interactive",
                onClick: this.props.onClose
            }, "Cancel"), (0, a.h)("button", {
                className: "interactive",
                onClick: this.handleStartTimer
            }, "Start timer"))))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function o(t, e) {}

    function r(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function a(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var s = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        u = n(0),
        c = n(42),
        l = i(c),
        h = n(43),
        f = i(h);
    n(80), e.default = function(t) {
        function e() {
            o(this, e);
            var n = r(this, t.call(this));
            return n.state = {
                loadingGlue: !1,
                loadingMain: !1
            }, n.updateLoading = n.updateLoading.bind(n), n
        }
        return a(e, t), e.prototype.updateLoading = function(t, e) {
            this.setState(s({}, this.state, t)), e && this.props.onSoundLoaded(this.props.sound.key)
        }, e.prototype.render = function(t) {
            var e = this,
                n = t.sound,
                i = t.onTapSoundImage,
                o = t.isPlaying,
                r = t.meanderActive,
                a = window && window.IOS,
                s = "loadingIndicator";
            return this.props.alreadyLoaded || (s = s + "\n        " + (this.state.loadingGlue ? "loadingGlue" : "") + "\n        " + (this.state.loadingMain ? "loadingMain" : "") + "\n      "), (0, u.h)("div", {
                className: "SoundContainer"
            }, (0, u.h)("div", {
                className: "inner"
            }, (0, u.h)("button", {
                onClick: function() {
                    return i(e.props.sound.key)
                },
                className: "imageContainer interactive " + this.props.sound.key + " " + (this.props.sound.pro ? "pro" : "")
            }, (0, u.h)("div", {
                className: s
            }, (0, u.h)("img", {
                src: "/assets/img/spinner.gif",
                height: "32",
                width: "30",
                alt: "Loading icon"
            })), (0, u.h)("div", {
                className: "image outline " + this.props.sound.key
            }), (0, u.h)("div", {
                className: "image fill " + this.props.sound.key,
                style: {
                    opacity: n.volume
                }
            })), (0, u.h)("h3", null, n.label, o && n.volume > .02 && r && (0, u.h)("span", {
                className: "meanderIndicator"
            })), this.props.children), a ? (0, u.h)(f.default, {
                isPlaying: o,
                sound: n
            }) : (0, u.h)(l.default, {
                key: n.key,
                isPlaying: o,
                sound: n,
                globalVolume: this.props.globalVolume,
                onUpdateLoading: this.updateLoading
            }))
        }, e
    }(u.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        },
        s = n(0),
        u = n(2);
    e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                loading: !1,
                loadAudio: !1,
                canBeginPlay: !1,
                glueDuration: 10
            }, n.handleCanBeginPlay = n.handleCanBeginPlay.bind(n), n.handleGlueTimeUpdate = n.handleGlueTimeUpdate.bind(n), n.handleMainTimeUpdate = n.handleMainTimeUpdate.bind(n), n.playMain = n.playMain.bind(n), n.playGlue = n.playGlue.bind(n), n.stop = n.stop.bind(n), n.handleError = n.handleError.bind(n), n
        }
        return r(e, t), e.prototype.componentWillMount = function() {
            this.props.sound.volume > .02 && this.setState({
                loadAudio: !0
            })
        }, e.prototype.componentWillReceiveProps = function(t) {
            var e = this.props;
            if (!this.state.loadAudio && t.sound.volume > .02) return this.setState({
                loadAudio: !0,
                loading: !0
            }), void this.props.onUpdateLoading({
                loadingGlue: !0,
                loadingMain: !0
            });
            t.isPlaying && !this.props.isPlaying ? this.playMain(t) : !t.isPlaying && this.props.isPlaying && this.stop(t), t.globalVolume === e.globalVolume && t.sound.volume === e.sound.volume || this.setVolume(t, this.props)
        }, e.prototype.setVolume = function(t, e) {
            if ("Object" === !(void 0 === t ? "undefined" : a(t))) throw Error();
            var n = t.globalVolume,
                i = t.isPlaying,
                o = t.sound,
                r = o.volume * n;
            if (this.audioPlayerMain && (this.audioPlayerMain.volume = r), this.audioPlayerGlue && (this.audioPlayerGlue.volume = r), i && e) {
                var s = o.volume,
                    u = e.sound.volume;
                .02 >= s && u > .02 ? this.stop() : s > .02 && .02 >= u && this.playMain(t)
            }
        }, e.prototype.playMain = function(t) {
            if ("Object" === !(void 0 === t ? "undefined" : a(t))) throw Error("ERROR");
            if (this.glueShouldPlay && this.audioPlayerMain && this.audioPlayerMain.paused && (this.glueShouldPlay = !1, this.audioPlayerGlue)) {
                this.audioPlayerGlue.currentTime = 0;
                try {
                    this.audioPlayerMain.currentTime = 5
                } catch (t) {}
            }
            t.sound.volume > .02 && t.isPlaying && this.state.loadAudio && this.audioPlayerMain && (this.audioPlayerMain.volume = t.sound.volume * t.globalVolume, 3 > this.audioPlayerMain.networkState ? this.audioPlayerMain.play().catch(function() {}) : this.handleError())
        }, e.prototype.playGlue = function(t) {
            if ("Object" === !(void 0 === t ? "undefined" : a(t))) throw Error("ERROR");
            t.sound.volume > .02 && t.isPlaying && this.state.loadAudio && this.audioPlayerGlue && (this.audioPlayerGlue.volume = t.sound.volume * t.globalVolume, 3 > this.audioPlayerGlue.networkState ? this.glueShouldPlay && this.audioPlayerGlue.play().catch(function() {}) : this.handleError())
        }, e.prototype.stop = function() {
            this.audioPlayerMain && this.audioPlayerMain.pause(), this.audioPlayerGlue && this.audioPlayerGlue.pause()
        }, e.prototype.handleCanBeginPlay = function(t) {
            var e = this,
                n = this.props,
                i = n.sound;
            if (!this.haveDoneHandleCanBeginPlay && (this.haveDoneHandleCanBeginPlay = !0, this.setState({
                    canBeginPlay: !0
                }), this.props.onUpdateLoading({
                    loadingGlue: !1
                }, !0), !this.state.glueDuration && t && t.target && t.target.duration && this.setState({
                    glueDuration: t.target.duration
                }), n.isPlaying && i.volume > .02)) try {
                this.audioPlayerGlue.volume = i.volume * n.globalVolume, this.audioPlayerGlue.play().catch(function() {
                    e.handleError()
                })
            } catch (t) {}
        }, e.prototype.handleError = function() {
            var t = this;
            this.haveDoneHandleCanBeginPlay = !1, this.audioPlayerMain = null, this.audioPlayerGlue = null, this.setState({
                loading: !1,
                loadAudio: !1,
                canBeginPlay: !1
            }), this.timeout = setTimeout(function() {
                return t.setState({
                    loadAudio: !0
                })
            }, 5e3)
        }, e.prototype.handleGlueTimeUpdate = function(t) {
            t.target.currentTime > t.target.duration / 2 && (this.playMain(this.props), this.glueShouldPlay = !1)
        }, e.prototype.handleMainTimeUpdate = function(t) {
            var e = t.target.duration,
                n = t.target.currentTime,
                i = this.state.glueDuration;
            !this.glueShouldPlay && n > e - i / 2 && (this.audioPlayerGlue && (this.audioPlayerGlue.currentTime = 0), this.glueShouldPlay = !0, this.playGlue(this.props))
        }, e.prototype.componentWillUnmount = function() {
            this.audioPlayerMain = null, this.audioPlayerGlue = null, this.haveDoneHandleCanBeginPlay = !1, clearTimeout(this.timeout)
        }, e.prototype.render = function(t) {
            var e = this,
                n = t.sound;
            return (0, s.h)("div", {
                className: "SoundPlayer",
                key: n.key
            }, this.state.loadAudio && (0, s.h)("div", null, (0, s.h)(c, {
                sound: n,
                handleMainTimeUpdate: this.handleMainTimeUpdate,
                handleError: this.handleError,
                onReceiveRef: function(t) {
                    return e.audioPlayerMain = t
                },
                playerType: "main"
            }), (0, s.h)(l, {
                sound: n,
                onReceiveRef: function(t) {
                    e.audioPlayerGlue = t
                },
                handleCanBeginPlay: this.handleCanBeginPlay,
                handleGlueTimeUpdate: this.handleGlueTimeUpdate,
                onError: this.handleError,
                onAbort: this.handleError,
                playerType: "glue"
            })))
        }, e
    }(s.Component);
    var c = function(t) {
            function e() {
                return i(this, e), o(this, t.apply(this, arguments))
            }
            return r(e, t), e.prototype.componentDidMount = function() {
                try {
                    var t = this.player.play();
                    t && t.catch(function() {
                        return null
                    }), this.player.pause()
                } catch (t) {}
            }, e.prototype.componentWillUnmount = function() {
                var t = this;
                Promise.resolve(this).then(function() {
                    return t.nextBase = t.__b = null
                }).catch(function() {})
            }, e.prototype.render = function() {
                var t = this,
                    e = this.props;
                return (0, s.h)("audio", {
                    ref: function(e) {
                        t.props.onReceiveRef(e), t.player = e
                    },
                    preload: "auto",
                    loop: !0,
                    controls: !!u.DEBUG,
                    onTimeUpdate: e.handleMainTimeUpdate,
                    onError: function(t) {
                        return e.handleError(t, "error")
                    },
                    onAbort: function(n) {
                        return t.ignoreErrors ? null : e.handleError(n, "abort")
                    }
                }, (0, s.h)("source", {
                    ref: function(e) {
                        return t.source1 = e
                    },
                    className: "mp4 " + e.sound.key,
                    src: "" + (0, u.getPrefix)(e.sound) + e.playerType + "-" + e.sound.key + ".mp4" + (0, u.getSuffix)(),
                    type: "audio/mp4"
                }), (0, s.h)("source", {
                    ref: function(e) {
                        return t.source2 = e
                    },
                    className: "ogg " + e.sound.key,
                    src: "" + (0, u.getPrefix)(e.sound) + e.playerType + "-" + e.sound.key + ".ogg" + (0, u.getSuffix)(),
                    type: "audio/ogg"
                }))
            }, e
        }(s.Component),
        l = function(t) {
            function e() {
                return i(this, e), o(this, t.apply(this, arguments))
            }
            return r(e, t), e.prototype.componentDidMount = function() {}, e.prototype.componentWillUnmount = function() {
                var t = this;
                Promise.resolve(this).then(function() {
                    return t.nextBase = t.__b = null
                })
            }, e.prototype.render = function() {
                var t = this,
                    e = this.props;
                return (0, s.h)("audio", {
                    ref: function(n) {
                        e.onReceiveRef(n), t.player = n
                    },
                    preload: "auto",
                    onLoadStart: function() {
                        return t.haveLoadStart = !0
                    },
                    onCanPlayThrough: function(n) {
                        t.firedCanPlayThrough = !0, e.handleCanBeginPlay(n)
                    },
                    onTimeUpdate: e.handleGlueTimeUpdate,
                    onError: function(n) {
                        return t.ignoreErrors ? null : e.onError(n)
                    },
                    onAbort: function(n) {
                        return t.ignoreErrors ? null : e.onError(n)
                    },
                    controls: !!u.DEBUG,
                    style: {
                        marginTop: "-40px"
                    }
                }, (0, s.h)("source", {
                    ref: function(e) {
                        return t.source1 = e
                    },
                    class: "gluemp4",
                    src: "" + (0, u.getPrefix)(e.sound, e.playerType) + e.playerType + "-" + e.sound.key + ".mp4" + (0, u.getSuffix)(),
                    type: "audio/mp4"
                }), (0, s.h)("source", {
                    ref: function(e) {
                        return t.source2 = e
                    },
                    class: "glueogg",
                    src: "" + (0, u.getPrefix)(e.sound, e.playerType) + e.playerType + "-" + e.sound.key + ".ogg" + (0, u.getSuffix)(),
                    type: "audio/ogg"
                }))
            }, e
        }(s.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0),
        s = n(2);
    e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.playMain = n.playMain.bind(n), n
        }
        return r(e, t), e.prototype.componentWillReceiveProps = function(t) {
            var e = this.props,
                n = t.isPlaying,
                i = e.isPlaying,
                o = t.sound.volume > .02,
                r = e.sound.volume > .02;
            n && !i && o ? this.playMain() : n && i ? o && !r ? this.playMain() : !o && r && this.stop() : !n && i && r && this.stop()
        }, e.prototype.playMain = function() {
            this.player && this.player.play()
        }, e.prototype.stop = function() {
            this.player && this.player.pause()
        }, e.prototype.render = function() {
            var t = this,
                e = this.props;
            return (0, a.h)("div", {
                className: "SoundPlayerIos"
            }, (0, a.h)("audio", {
                ref: function(e) {
                    t.player = e
                },
                preload: "auto",
                loop: !0,
                controls: !!s.DEBUG,
                onError: function(t) {
                    return e.handleError(t, "error")
                },
                onAbort: function(t) {
                    return e.handleError(t, "abort")
                }
            }, (0, a.h)("source", {
                class: "mp4",
                src: (0, s.getPrefix)(e.sound, !1, !1) + "ios-web-" + e.sound.key + ".mp4" + (0, s.getSuffix)(),
                type: "audio/mp4"
            })))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function o(t, e) {}

    function r(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function a(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var s = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        u = n(0),
        c = n(41),
        l = i(c),
        h = n(45),
        f = i(h);
    n(81), e.default = function(t) {
        function e() {
            o(this, e);
            var n = r(this, t.call(this));
            return n.state = {
                soundsLoaded: {}
            }, n.handleSoundLoaded = n.handleSoundLoaded.bind(n), n
        }
        return a(e, t), e.prototype.handleSoundLoaded = function(t) {
            if (!this.state.soundsLoaded[t]) {
                var e = s({}, this.state.soundsLoaded);
                e[t] = !0, this.setState({
                    soundsLoaded: e
                })
            }
        }, e.prototype.render = function() {
            var t = this,
                e = this.props.sounds,
                n = Object.keys(e).map(function(t) {
                    return e[t]
                }).sort(function(t, e) {
                    return t.sortKey - e.sortKey
                });
            return (0, u.h)("div", {
                className: "SoundList"
            }, n.map(function(e) {
                return (0, u.h)(l.default, {
                    key: e.key,
                    globalVolume: t.props.globalVolume,
                    isPlaying: t.props.isPlaying,
                    sound: s({}, e),
                    onTapSoundImage: t.props.onTapSoundImage,
                    meanderActive: t.props.meanderActive,
                    onSoundLoaded: t.handleSoundLoaded,
                    alreadyLoaded: !!t.state.soundsLoaded[e.key]
                }, (0, u.h)(f.default, {
                    key: e.key,
                    soundKey: e.key,
                    volume: e.volume,
                    updateSoundVolume: t.props.updateSoundVolume,
                    forceUpdateIndex: t.props.forceUpdateIndex,
                    onTouchStart: t.props.onTouchStart,
                    onTouchEnd: t.props.onTouchEnd
                }))
            }))
        }, e
    }(u.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        s = n(0);
    n(82), e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                forceSlider: !1,
                forceSliderValue: 0
            }, n.updateSoundVolume = n.updateSoundVolume.bind(n), n.handleTouchStart = n.handleTouchStart.bind(n), n.handleTouchEnd = n.handleTouchEnd.bind(n), n
        }
        return r(e, t), e.prototype.componentWillReceiveProps = function(t) {
            this.setState(t.forceUpdateIndex !== this.props.forceUpdateIndex ? {
                forceSlider: !0,
                forceSliderValue: t.volume
            } : {
                forceSlider: !1
            })
        }, e.prototype.shouldComponentUpdate = function(t) {
            return !this.touchInProgress && t.forceUpdateIndex !== this.props.forceUpdateIndex
        }, e.prototype.updateSoundVolume = function(t) {
            this.props.updateSoundVolume(this.props.soundKey, parseFloat(t.target.value))
        }, e.prototype.handleTouchStart = function() {
            this.touchInProgress = !0, this.props.onTouchStart()
        }, e.prototype.handleTouchEnd = function() {
            this.touchInProgress = !1, this.props.onTouchEnd()
        }, e.prototype.componentWillUnmount = function() {
            var t = this;
            this.state.forceSliderValue = 0, this.state.forceSlider = !1, Promise.resolve(this).then(function() {
                return t.nextBase = t.__b = null
            })
        }, e.prototype.render = function() {
            var t = this;
            return (0, s.h)("div", {
                className: "SoundSlider"
            }, (0, s.h)("span", null, (0, s.h)("input", a({
                key: "" + this.props.soundKey + this.props.forceUpdateIndex,
                type: "range",
                min: "0",
                max: "1",
                step: "0.02"
            }, this.state.forceSlider ? {
                value: this.state.forceSliderValue + .001 * Math.random()
            } : {}, {
                defaultValue: this.props.volume,
                onInput: this.updateSoundVolume,
                onChange: function() {
                    return t.setState({
                        touchInProgress: !1
                    })
                },
                onMouseDown: this.handleTouchStart,
                onTouchStart: this.handleTouchStart,
                onMouseUp: this.handleTouchEnd,
                onTouchEnd: this.handleTouchEnd
            }))))
        }, e
    }(s.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(83), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "StaticSiteDescription"
            }, (0, a.h)("div", {
                className: "borderTop"
            }, (0, a.h)("div", {
                className: "left"
            }), (0, a.h)("div", {
                className: "right"
            }), (0, a.h)("div", {
                className: "hideButton"
            }, (0, a.h)("button", {
                className: "button interactive hoverOpacity",
                onClick: this.props.onHide
            }, "×"))), (0, a.h)("div", {
                className: "inner"
            }, (0, a.h)("div", {
                className: "content"
            }, (0, a.h)("p", null, " ", (0, a.h)("a", {
                href: "mailto:info.fatehapplication@gmail.com"
            }, "info.fatehapplication@gmail.com")), (0, a.h)("p", null, "I hope you have a relaxing day!"), (0, a.h)("p", null, "-- Fateh Application"))))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(84), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "Title"
            }, (0, a.h)("h1", null, "A Soft Murmur"), (0, a.h)("p", null, "Ambient sounds to wash away distraction."))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(85), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.componentDidMount = function() {
            this.timeout = setTimeout(this.props.onClose, 15e3)
        }, e.prototype.componentWillUnmount = function() {
            clearTimeout(this.timeout)
        }, e.prototype.getMessage = function() {
            return "pro_timeout" === this.props.variety ? (0, a.h)("div", {
                className: "message"
            }, (0, a.h)("p", null, "Whoops - no reply from license server!"), (0, a.h)("p", null, "To access your Pro account, please wait a few minutes and reload the page."), (0, a.h)("p", null, "For help, you can contact ", (0, a.h)("a", {
                href: "mailto:info.fatehapplication@gmail.com"
            }, "info.fatehapplication@gmail.com"))) : "bad_link" === this.props.variety ? (0, a.h)("div", {
                className: "message"
            }, (0, a.h)("p", null, "Whoops - it looks like your login link has expired."), (0, a.h)("p", null, "Please try to log in again."), (0, a.h)("p", null, "For help, you can contact ", (0, a.h)("a", {
                href: "mailto:info.fatehapplication@gmail.com"
            }, "info.fatehapplication@gmail.com"))) : "welcome" === this.props.variety ? (0, a.h)("div", {
                className: "message"
            }, (0, a.h)("p", null, "Thank you for upgrading to Pro!"), (0, a.h)("p", null, 'To get started, click the "Sounds" button to begin using your new sounds.')) : void 0
        }, e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "Toast"
            }, (0, a.h)("div", {
                className: "inner"
            }, this.getMessage(), (0, a.h)("button", {
                className: "button interactive close",
                onClick: this.props.onClose
            }, "OK")))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        s = n(0),
        u = n(2);
    n(86), e.default = function(t) {
        function e() {
            i(this, e);
            var n = o(this, t.call(this));
            return n.state = {
                autorenew: !0,
                externalScriptLoaded: !1
            }, n.toggleAutorenew = n.toggleAutorenew.bind(n), n
        }
        return r(e, t), e.prototype.toggleAutorenew = function() {
            this.setState({
                autorenew: !this.state.autorenew
            })
        }, e.prototype.componentDidMount = function() {
            var t = this;
            try {
                if (document.getElementById("paddleScript")) this.setState({
                    externalScriptLoaded: !0
                });
                else {
                    var e = document.createElement("script");
                    e.src = "https://cdn.paddle.com/paddle/paddle.js", e.onload = function() {
                        t.setState({
                            externalScriptLoaded: !0
                        })
                    }, e.id = "paddleScript", document.body.appendChild(e)
                }
            } catch (t) {}
            this.escListener = function(e) {
                27 === e.keyCode && (e.stopPropagation(), t.props.onSetStage(null))
            }, window.addEventListener("keyup", this.escListener)
        }, e.prototype.componentWillUnmount = function() {
            window.removeEventListener("keyup", this.escListener)
        }, e.prototype.render = function() {
            var t = this,
                e = Math.abs(this.props.stage);
            return (0, s.h)("div", {
                className: "UpgradeModal"
            }, (0, s.h)(c, {
                onSetLogin: function() {
                    return t.props.onSetStage(2)
                },
                showLoginLink: 1 === e && !this.props.user
            }), (0, s.h)("div", {
                className: "container"
            }, 1 === e ? (0, s.h)(h, {
                extraSounds: this.props.extraSounds,
                onSetStage: this.props.onSetStage,
                user: this.props.user
            }) : null, 2 === e ? (0, s.h)(p, {
                onSetStage: this.props.onSetStage,
                onSetEmail: this.props.onSetEmail,
                user: this.props.user,
                inSignupFlow: 2 === this.props.stage,
                firebaseAuth: this.props.firebaseAuth
            }) : null, 3 === e ? (0, s.h)(m, {
                autorenew: this.state.autorenew,
                onToggleAutorenew: this.toggleAutorenew,
                onSetStage: this.props.onSetStage,
                user: this.props.user,
                externalScriptLoaded: this.state.externalScriptLoaded
            }) : null, 4 === e ? (0, s.h)(p, {
                onSetStage: this.props.onSetStage,
                onSetEmail: this.props.onSetEmail,
                user: this.props.user,
                justPrompting: !0,
                finishEmailPrompt: this.props.finishEmailPrompt,
                firebaseAuth: this.props.firebaseAuth
            }) : null))
        }, e
    }(s.Component);
    var c = function(t) {
            function e() {
                return i(this, e), o(this, t.apply(this, arguments))
            }
            return r(e, t), e.prototype.render = function() {
                return (0, s.h)("div", {
                    className: "UpgradeHeader"
                }, (0, s.h)("div", {
                    className: "content"
                }, (0, s.h)("img", {
                    className: "icon",
                    src: "/assets/favicon.png"
                }), (0, s.h)("h2", {
                    className: "title"
                }, (0, s.h)("a", {
                    className: "interactive",
                    href: "/"
                }, "A Soft Murmur")), (0, s.h)("div", {
                    className: "signIn"
                }, this.props.showLoginLink ? (0, s.h)("button", {
                    className: "interactive",
                    onClick: this.props.onSetLogin
                }, "") : null)))
            }, e
        }(s.Component),
        l = function(t) {
            function e() {
                return i(this, e), o(this, t.call(this))
            }
            return r(e, t), e.prototype.componentWillUnmount = function() {
                var t = this;
                Promise.resolve(this).then(function() {
                    return t.nextBase = t.__b = null
                })
            }, e.prototype.componentDidMount = function() {
                var t = this;
                setTimeout(function() {
                    if (t.player) try {
                        t.player.play()
                    } catch (t) {}
                }, 100)
            }, e.prototype.render = function() {
                var t = this;
                return (0, s.h)("audio", {
                    ref: function(e) {
                        return t.player = e
                    },
                    className: "PreviewSound",
                    autoplay: !0,
                    preload: "auto",
                    onEnded: this.props.onEnd
                }, (0, s.h)("source", {
                    className: "mp4 " + this.props.sound.key,
                    src: (0, u.getPrefix)(this.props.sound) + "glue-" + this.props.sound.key + ".mp4",
                    type: "audio/mp4"
                }), (0, s.h)("source", {
                    className: "ogg " + this.props.sound.key,
                    src: (0, u.getPrefix)(this.props.sound) + "glue-" + this.props.sound.key + ".ogg",
                    type: "audio/ogg"
                }))
            }, e
        }(s.Component),
        h = function(t) {
            function e() {
                i(this, e);
                var n = o(this, t.call(this));
                return n.state = {
                    soundPreviewing: null
                }, n.togglePreview = n.togglePreview.bind(n), n
            }
            return r(e, t), e.prototype.togglePreview = function(t) {
                this.setState({
                    soundPreviewing: this.state.soundPreviewing === t ? null : t
                })
            }, e.prototype.render = function() {
                var t = this,
                    e = Object.keys(this.props.extraSounds).map(function(e) {
                        return t.props.extraSounds[e]
                    }).sort(function(t, e) {
                        return t.sortKey - e.sortKey
                    });
                return (0, s.h)("div", {
                    className: "Stage1"
                }, (0, s.h)("p", null, "", (0, s.h)("span", {
                    className: "numSounds"
                }, " " + e.length + " "), "extra web sounds."), (0, s.h)("p", null, "You'll also get access to any new web sounds released in the future."), (0, s.h)("div", {
                    className: "previewSounds"
                }, (0, s.h)("ul", null, e.map(function(e) {
                    return (0, s.h)(d, {
                        sound: e,
                        isActive: !0,
                        toggleSound: function() {
                            return null
                        },
                        isPreviewing: t.state.soundPreviewing === e.key,
                        onTogglePreview: t.togglePreview.bind(t, e.key)
                    })
                })), this.state.soundPreviewing ? (0, s.h)(l, {
                    key: this.state.soundPreviewing,
                    sound: this.props.extraSounds[this.state.soundPreviewing],
                    onEnd: function() {
                        return t.setState({
                            soundPreviewing: null
                        })
                    }
                }) : null), (0, s.h)("div", {
                    className: ""
                }, (0, s.h)("button", {
                    className: "interactive cancel button",
                    onClick: function() {
                        t.props.onSetStage(null)
                    }
                }, "Close"), (0, s.h)("button", {
                    className: "",
                    onClick: function() {
                        t.props.onSetStage(t.props.user ? 3 : 2)
                    }
                }, "")))
            }, e
        }(s.Component),
        f = function(t) {
            return !(!t || 5 > t.lengh) && -1 !== t.indexOf("@") && -1 !== t.indexOf(".")
        },
        p = function(t) {
            function e() {
                var n, r, a;
                i(this, e);
                for (var s = arguments.length, u = Array(s), c = 0; s > c; c++) u[c] = arguments[c];
                return n = r = o(this, t.call.apply(t, [this].concat(u))), r.state = {
                    emailText: "",
                    emailValidationError: null
                }, a = n, o(r, a)
            }
            return r(e, t), e.prototype.render = function() {
                var t = this,
                    e = ["localhost", "beta.asoftmurmur.com", "asoftmurmur.com"],
                    n = window.location.hostname;
                n = e.includes(n) ? n : "asoftmurmur.com";
                var i = window.location.protocol + "//" + window.location.hostname;
                window.location.port && 80 !== window.location.port && (i = i + ":" + window.location.port);
                var o = {
                    url: this.props.inSignupFlow ? i + "/?upgradeAccountCreated=1" : i + "/",
                    handleCodeInApp: !0
                };
                return this.sendSignInLink = function() {
                    t.setState({
                        loading: !0
                    }), t.props.firebaseAuth().sendSignInLinkToEmail(t.state.emailText, o).then(function() {
                        t.props.onSetEmail(t.state.emailText), t.setState({
                            awaitingEmailValidation: !0,
                            loading: !1
                        })
                    }).catch(function() {
                        t.setState({
                            emailValidationError: "remote",
                            loading: !1
                        })
                    })
                }, this.finishEmailPrompt = function(e) {
                    t.props.finishEmailPrompt(e)
                }, this.state.awaitingEmailValidation ? (0, s.h)("div", {
                    className: "Stage2"
                }, (0, s.h)("p", null, "Sign-in email sent to ", (0, s.h)("span", {
                    className: "userEnteredEmail"
                }, this.state.emailText)), (0, s.h)("p", null, "An email with a sign-in link should arrive in a few minutes. Please remember to check your junk folder."), (0, s.h)("div", {
                    className: "continueContainer"
                }, (0, s.h)("button", {
                    className: "interactive cancel button",
                    onClick: function() {
                        t.setState({
                            awaitingEmailValidation: !1
                        })
                    }
                }, "Wrong email address?"), (0, s.h)("button", {
                    className: "interactive continue button",
                    onClick: function() {
                        t.props.onSetStage(null)
                    }
                }, "Close"))) : (0, s.h)("div", {
                    className: "Stage2"
                }, this.state.loading && (0, s.h)("div", {
                    className: "loadingContainer"
                }, (0, s.h)("div", {
                    className: "loading"
                })), (0, s.h)("h3", null, this.props.justPrompting ? "Enter your email address to finish signing in" : " or register"), (0, s.h)("label", {
                    for: "upgradeEmail",
                    className: "emailLabel"
                }, "Email address"), (0, s.h)("input", {
                    type: "email",
                    id: "upgradeEmail",
                    className: this.state.emailValidationError ? "invalid" : "",
                    onInput: function() {
                        t.state.emailValidationError && t.setState({
                            emailValidationError: null
                        })
                    },
                    onChange: function(e) {
                        t.setState({
                            emailText: e.target.value
                        })
                    },
                    value: this.state.emailText
                }), this.state.emailValidationError ? (0, s.h)("p", {
                    className: "validationWarning"
                }, "Oops, something went wrong - please double check your email address") : null, (0, s.h)("div", {
                    className: "continueContainer"
                }, (0, s.h)("button", {
                    className: "interactive cancel button",
                    onClick: function() {
                        t.props.onSetStage(null)
                    }
                }, "Cancel"), (0, s.h)("button", {
                    className: "interactive continue button",
                    onClick: function() {
                        if (!f(t.state.emailText)) return void t.setState({
                            emailValidationError: "local"
                        });
                        t.props.justPrompting ? t.finishEmailPrompt(t.state.emailText) : t.sendSignInLink()
                    }
                }, "Continue")))
            }, e
        }(s.Component),
        d = function(t) {
            function e() {
                return i(this, e), o(this, t.call(this))
            }
            return r(e, t), e.prototype.render = function() {
                var t = this.props,
                    e = t.sound;
                return (0, s.h)("li", {
                    className: "SoundItem " + (this.props.isPreviewing ? "active" : "inactive") + " interactive noSelect",
                    onClick: this.props.onTogglePreview
                }, (0, s.h)("p", {
                    className: "label"
                }, e.label), (0, s.h)("div", {
                    className: "previewButton " + (this.props.isPreviewing ? "previewing" : "")
                }, (0, s.h)("button", {
                    className: "button interactive"
                }, (0, s.h)("div", {
                    className: "previewInnerContainer"
                }, (0, s.h)("div", {
                    className: "previewInner"
                })))))
            }, e
        }(s.Component),
        m = function(t) {
            function e() {
                return i(this, e), o(this, t.call(this))
            }
            return r(e, t), e.prototype.componentWillMount = function() {
                this.setupPaddle()
            }, e.prototype.setupPaddle = function() {
                var t = this,
                    e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                this.props.externalScriptLoaded ? Paddle.Setup({
                    vendor: 32551
                }) : 30 > e && setTimeout(function() {
                    return t.setupPaddle(e + 1)
                }, 100)
            }, e.prototype.render = function() {
                var t = this,
                    e = {
                        success: "/?waitingForLicense=1",
                        email: this.props.user.email,
                        passthrough: '{"uid": "' + this.props.user.uid + '"}',
                        allowQuantity: !1,
                        disableLogout: !0
                    },
                    n = function() {
                        t.props.autorenew ? Paddle.Checkout.open(a({
                            product: 555858
                        }, e)) : Paddle.Checkout.open(a({
                            product: 549697
                        }, e))
                    };
                return (0, s.h)("div", {
                    className: "Stage3"
                }, (0, s.h)("p", null, "A Soft Murmur Pro costs"), (0, s.h)("p", {
                    className: "price"
                }, "$9.00"), (0, s.h)("p", {
                    className: "currencyMessage"
                }, "(or local currency equivalent)"), (0, s.h)("p", null, "per year"), (0, s.h)("p", {
                    className: "webOnlyMessage"
                }, "ⓘ Extra sounds can be accessed in the web version only"), (0, s.h)("div", {
                    className: "renewInput noSelect interactive",
                    onClick: this.props.onToggleAutorenew
                }, (0, s.h)("div", {
                    className: "toggle " + (this.props.autorenew ? "on" : "off")
                }, (0, s.h)("div", {
                    className: "inner"
                })), (0, s.h)("label", {
                    className: " renewLabel " + (this.props.autorenew ? "active" : "inactive")
                }, "Renew automatically after each year")), (0, s.h)("div", {
                    className: "continueContainer"
                }, (0, s.h)("button", {
                    className: "interactive cancel button",
                    onClick: function() {
                        t.props.onSetStage(null)
                    }
                }, "Close"), (0, s.h)("button", {
                    className: "interactive continue button",
                    onClick: n,
                    disabled: !this.props.externalScriptLoaded
                }, "Continue")))
            }, e
        }(s.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(87), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "WaitingForLicense"
            }, (0, a.h)("div", {
                className: "inner"
            }, (0, a.h)("p", {
                className: "message"
            }, "Loading license..."), (0, a.h)("span", {
                className: "loading"
            })))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";

    function i(t, e) {}

    function o(t, e) {
        if (t) return !e || "object" != typeof e && "function" != typeof e ? t : e
    }

    function r(t, e) {
        "function" != typeof e && null !== e || (t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e))
    }
    e.__esModule = !0, e.default = void 0;
    var a = n(0);
    n(88), e.default = function(t) {
        function e() {
            return i(this, e), o(this, t.apply(this, arguments))
        }
        return r(e, t), e.prototype.render = function() {
            return (0, a.h)("div", {
                className: "WaitingForLicense"
            }, (0, a.h)("div", {
                className: "inner"
            }, (0, a.h)("p", {
                className: "message"
            }, "Checking login link..."), (0, a.h)("span", {
                className: "loading"
            })))
        }, e
    }(a.Component)
}, function(t, e, n) {
    "use strict";
    var i = n(0);
    n(15), n(14);
    var o = void 0;
    ! function() {
        var t = n(13).default;
        o = (0, i.render)((0, i.h)(t, null), document.getElementById("root"), document.getElementById("root").firstElementChild)
    }()
}, function(t, e) {
    "use strict";
    e.__esModule = !0, e.default = function(t, e) {
        var n = document.querySelector(t),
            i = document.createRange();
        i.selectNode(n), window.getSelection().addRange(i);
        try {
            var o = document.execCommand("copy");
            e(o)
        } catch (t) {
            e(!1)
        }
        try {
            window.getSelection().removeAllRanges()
        } catch (t) {}
    }
}, function(t, e) {
    "use strict";
    e.__esModule = !0, e.default = function() {
        return "" + Date.now() + Math.round(Math.random() * Math.pow(10, 16))
    }
}, function(t, e) {
    "use strict";
    e.__esModule = !0;
    var n = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        i = function(t, e) {
            for (var i = Object.keys(e).map(function(t) {
                    return e[t]
                }), o = [2, 3], r = o[Math.floor(2 * Math.random())], a = [], s = 100, u = ["whitenoise", "pinknoise"], c = 0; r > c; c++) {
                var l = Math.floor(Math.random() * i.length);
                u.indexOf(i[l].key) > -1 && (l = Math.floor(Math.random() * i.length));
                var f = void 0;
                c + 1 === r ? f = s : (f = Math.floor(Math.random() * s), s -= f);
                var p = i[l];
                p.volume = f / 100, a.push(p), i.splice(l, 1)
            }
            var d = {};
            a.forEach(function(t) {
                return d[t.key] = t
            });
            for (var m = Object.keys(t).filter(function(t) {
                    return !d[t]
                }).map(function(e) {
                    return t[e]
                }).sort(function(t, e) {
                    return t.sortKey - e.sortKey
                }), v = Math.min(10 - Object.keys(d).length, m.length), g = 0; v > g; g++) d[m[g].key] = n({}, m[g], {
                volume: 0
            });
            return {
                name: h(a),
                sounds: d
            }
        },
        o = function(t) {
            return t[Math.floor(Math.random() * t.length)]
        },
        r = function(t) {
            return t.adjectives[Math.floor(Math.random() * t.adjectives.length)]
        },
        a = function(t) {
            return t.nouns[Math.floor(Math.random() * t.nouns.length)]
        },
        s = function(t) {
            return t.places[Math.floor(Math.random() * t.places.length)]
        },
        u = function() {
            return o(["day", "night", "morning", "afternoon", "evening", "sunset", "sunrise"])
        },
        c = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            return "" + t.substring(0, 1).toUpperCase() + t.substring(1, t.length)
        },
        l = [{
            sounds: 1,
            template: function(t) {
                return "A " + r(t[0]) + " " + u()
            }
        }, {
            sounds: 1,
            template: function(t) {
                return c(r(t[0])) + " " + a(t[0])
            }
        }, {
            sounds: 2,
            template: function(t) {
                return c(r(t[0])) + " " + a(t[1])
            }
        }, {
            sounds: 2,
            template: function(t) {
                return "A " + r(t[0]) + ", " + r(t[1]) + " " + u()
            }
        }, {
            sounds: 2,
            template: function(t) {
                return c(r(t[0])) + " " + u() + " at " + s(t[1])
            }
        }, {
            sounds: 2,
            template: function(t) {
                return c(a(t[0])) + " at " + s(t[1])
            }
        }, {
            sounds: 2,
            template: function(t) {
                return c(r(t[0])) + " at " + s(t[1])
            }
        }, {
            sounds: 2,
            template: function(t) {
                return c(a(t[0])) + " at " + s(t[1])
            }
        }, {
            sounds: 3,
            template: function(t) {
                return "A " + r(t[0]) + ", " + r(t[1]) + ", " + r(t[2]) + " " + u()
            }
        }, {
            sounds: 3,
            template: function(t) {
                return "A " + r(t[0]) + ", " + r(t[1]) + " " + u() + " at " + s(t[2])
            }
        }, {
            sounds: 3,
            template: function(t) {
                return c(r(t[0])) + " " + a(t[1]) + " at " + s(t[2])
            }
        }],
        h = function(t) {
            var e = t.filter(function(t) {
                    return t.volume >= .02
                }).sort(function(t, e) {
                    return e.volume - t.volume
                }),
                n = l.filter(function(t) {
                    return t.sounds === e.length
                });
            if (0 === e.length) return "Silence";
            var i = o(n).template;
            return f(i(e))
        },
        f = function(t) {
            for (var e = ["a", "e", "i", "o", "u"], n = t.split(" "), i = 0; n.length > i; i++) {
                var o = n[i];
                "a" !== o && "A" !== o || e.indexOf(((n[i + 1] || "").substring(0, 1) || "").toLowerCase()) > -1 && ("a" === o && (n[i] = "an"), "A" === o && (n[i] = "An"))
            }
            return n.join(" ")
        };
    e.default = i
}, function(t, e) {
    "use strict";
    e.__esModule = !0, e.default = function(t) {
        var e = "";
        return Object.keys(t).sort(function(e, n) {
            return t[e].sortKey - t[n].sortKey
        }).forEach(function(n) {
            var i = "" + Math.round(100 * t[n].volume);
            "0" !== i && (1 === i.length && (i = "0" + i), "100" === i && (i = "99"), i = "" + t[n].shortcode + i, e += i)
        }), e
    }
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    e.__esModule = !0;
    var o = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        r = n(1),
        a = i(r);
    e.default = {
        globalVolume: 1,
        isPlaying: !1,
        timesLaunched: 0,
        checkedUrl: !1,
        checkedStorage: !1,
        availableSounds: o({}, a.default, i(n(6)).default),
        library: o({}, a.default),
        sounds: o({}, a.default),
        timer: {
            isActive: !1,
            secondsLeft: null,
            mode: null
        },
        savedTimer: {
            lastUsedMode: "stop",
            stop: {
                seconds: 300
            }
        },
        meander: {
            isActive: !1,
            sounds: null
        },
        savedMixes: {},
        usedMeanderBefore: !1,
        usedSoundManagerBefore: !1,
        appLinkshidden: !1,
        forceUpdateIndex: 0,
        stateToReset: null,
        utmSubstring: null,
        utmCampaign: null,
        pro: !1,
        proExpires: null,
        proLastChecked: null,
        inLoginView: !1
    }
}, function(t, e, n) {
    "use strict";
    e.__esModule = !0;
    var i = Object.assign || function(t) {
            for (var e = 1; arguments.length > e; e++) {
                var n = arguments[e];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
            }
            return t
        },
        o = n(1),
        r = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        }(o);
    e.default = {
        get: function() {
            if (window.localStorage) {
                var t = window.localStorage.getItem("asm-stored-state"),
                    e = t ? JSON.parse(t) : null;
                if (e && e.sounds) {
                    Object.keys(e.sounds).every(function(t) {
                        return 0 === parseFloat(e.sounds[t].volume)
                    }), e.upgradeDialog && (e.upgradeDialog = null);
                    var n = !1;
                    try {
                        var o = +e.proExpires;
                        o > Date.now() && 22090104e5 > o && (n = !0)
                    } catch (t) {}
                    return e.pro && n ? e.library = i({}, e.availableSounds) : (e.pro = !1, e.proExpires = null, e.library = i({}, r.default), Object.keys(e.sounds).some(function(t) {
                        return !Object.keys(e.library).find(function(e) {
                            return e === t
                        })
                    }) && (e.sounds = i({}, r.default))), e
                }
                return {}
            }
            return {}
        },
        set: function(t) {
            if (window.localStorage) {
                var e = i({}, t);
                e.storeDate = Date.now(), e.isPlaying = !1, e.stateToReset = null, e.meander = {
                    isActive: !1,
                    sounds: null
                }, e.timer = {
                    isActive: !1
                }, e.forceUpdateIndex = 0;
                var n = JSON.stringify(e);
                window.localStorage.setItem("asm-stored-state", n)
            }
        }
    }
}, function(t, e) {
    "use strict";
    e.__esModule = !0;
    var n = Object.assign || function(t) {
        for (var e = 1; arguments.length > e; e++) {
            var n = arguments[e];
            for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
        }
        return t
    };
    e.default = function(t) {
        var e = t.timer,
            i = e.secondsLeft,
            o = n({}, t),
            r = t.meander.isActive,
            a = t.touchInProgress || !t.isPlaying || e.isActive && "fade" === e.mode && e.secondsLeft > 180;
        if (e.isActive && 1 >= i ? (o.timer = {
                isActive: !1,
                secondsLeft: 0,
                mode: null
            }, "stop" !== e.mode && "fadeOut" !== e.mode || (o.isPlaying = !1), "start" === e.mode && (o.isPlaying = !0), o.meander.isActive = !1) : e.isActive && i > 1 && (o.timer.secondsLeft = o.timer.secondsLeft - 1), r && !t.meander.sounds) {
            var s = {};
            Object.keys(t.sounds).forEach(function(e) {
                var n = t.sounds[e],
                    i = {};
                i.baseVolume = n.volume, i.tickOffset = 0, i.direction = Math.random() > .5 ? "right" : "left", s[e] = i
            });
            var u = n({}, t.meander, {
                sounds: s,
                tickCount: 0
            });
            o.meander = u
        }
        if (r && !a) {
            var c = n({}, o.meander);
            c.sounds = n({}, o.meander.sounds), Object.keys(c.sounds).forEach(function(t) {
                c.sounds[t] = n({}, c.sounds[t])
            });
            var l = c.tickCount;
            c.tickCount = l + 1;
            var h = n({}, o.sounds);
            Object.keys(c.sounds).forEach(function(t) {
                var e = c.sounds[t],
                    i = e.baseVolume;
                if (i > .02) {
                    var o = e.tickOffset,
                        r = l - o,
                        a = r % 60;
                    0 === a && (e.direction = Math.random() > .5 ? "right" : "left");
                    var s = e.direction,
                        u = void 0;
                    u = "right" === s ? i + (1 - i) / 3 : i / 1.5;
                    var f = Math.abs(i - u),
                        p = f / 30,
                        d = a > 30 ? 30 - (a - 30) : a,
                        m = d * p,
                        v = void 0;
                    v = "right" === s ? i + m : i - m, h[t] = n({}, h[t], {
                        volume: v
                    })
                }
            }), o.meander = c, o.sounds = h, o.forceUpdateIndex = o.forceUpdateIndex + 1 || 1
        }
        return e.isActive && i > 0 && "fade" === e.mode && (Object.keys(o.sounds).forEach(function(t) {
            var r = o.sounds[t],
                a = r.volume,
                s = e.destination[t].volume,
                u = a - s;
            Math.abs(u) > 0 && (r.volume = u > 0 ? r.volume - r.volume / i : r.volume + Math.abs(u) / i), r = n({}, r), o.sounds[t] = r
        }), o.sounds = n({}, o.sounds), o.forceUpdateIndex = o.forceUpdateIndex + 1), o
    }
}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}, function() {}]);